import "./App.css";
import { useState } from "react";
import "react-toastify/dist/ReactToastify.css";
import GeneralRouter from "./components/general/generalRouter";
import { Context } from "./context/context.js";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

function App() {
  const [sessionId, setSessionId] = useState(null);
  return (
    <div className="App">
      <Context.Provider value={{ sessionId, setSessionId }}>
        <ToastContainer />
        <GeneralRouter />
      </Context.Provider>
    </div>
  );
}

export default App;
