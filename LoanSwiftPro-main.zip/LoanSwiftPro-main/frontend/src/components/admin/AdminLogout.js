/* eslint-disable react-hooks/exhaustive-deps */
import React, { useContext, useEffect } from "react";
import "./style.css";
import { useNavigate } from "react-router-dom";
import { Context } from "../../context/context";

export default function AdminLogout() {
  const navigate = useNavigate();
  const { setSessionId } = useContext(Context);
  useEffect(() => {
    setSessionId(localStorage.getItem("sessionId"));
  }, []);
  const logout = () => {
    setSessionId(null);
    localStorage.removeItem("sessionId");
    localStorage.removeItem("password");
    localStorage.removeItem("department");
    localStorage.removeItem("designation");
    navigate("/");
  };
  const login = () => {
    navigate("/");
  };
  return (
    <div>
      {localStorage.getItem("sessionId") === null ? (
        <button class="login_btnnn" type="button" onClick={login}>
          {" "}
          Home{" "}
        </button>
      ) : (
        <button class="login_btnnn " type="button" onClick={logout}>
          Logout{" "}
        </button>
      )}
    </div>
  );
}
