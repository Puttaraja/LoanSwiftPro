/* eslint-disable react-hooks/exhaustive-deps */
import axios from "axios";
import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import AdminNavbar from "./AdminNavbar";
import "./style.css";
import { toast } from "react-toastify";

export default function ViewCustomers() {
  const baseURL = "http://localhost:8080/fetchEmployees";
  const [customers, setCustomers] = useState([]);
  var deleteUrl = "http://localhost:8080/deleteEmployee/";
  const navigate = useNavigate();
  const data = [
    ["/Admin/CustomerDataManagement", "AddCustomer"],
    ["/Admin", "CustomerDataManagement"],
    ["/Admin", "ItemDataManagement"],
    ["/Admin", "LoanCardManagement"],
  ];
  const getSetCustomerData = () => {
    axios
      .get(baseURL)
      .then((response) => {
        setCustomers(response.data);
      })
      .catch((error) => {
        const data = {
          heading: error.response.data,
          url: "/Admin/CustomerDataManagement/AddCustomer",
          content:
            "Customers are not present in the database, Add Customers in the database. Go back to add Customer!",
        };
        toast.error(error.response.data, {
          position: toast.POSITION.TOP_CENTER,
        });

        navigate("/ResourceNotFound", { state: { stateData: data } });
      });
  };
  const deleteEmployee = (id) => {
    deleteUrl = deleteUrl + id;
    axios
      .delete(deleteUrl)
      .then((response) => {
        // alert(response.data);
        toast.success(response.data, { position: toast.POSITION.TOP_CENTER });
        getSetCustomerData();
      })
      .catch((error) => {
        const data = {
          heading: error.response.data,
          url: "/Admin/CustomerDataManagement/ViewCustomers",
          content:
            "You are trying to delete the Invalid Customer, Go back to View Customers for deleting Valid Customer!",
        };
        toast.error(error.response.data, {
          position: toast.POSITION.TOP_CENTER,
        });
        navigate("/ResourceNotFound", { state: { stateData: data } });
      });
  };

  useEffect(() => {
    getSetCustomerData();
  }, []);

  return (
    <div className="custom-gradient ">
      <AdminNavbar data={data} />
      <br></br>
      <h2 className="boxed-text bg-light-blue">Customers Table </h2>
      <br></br>
      <div className="custom-table">
        <table className="table-container gradient-custom">
          <thead>
            <tr>
              <th>Employee Id</th>
              <th>Employee Name</th>
              <th>Designation</th>
              <th>Department</th>
              <th>Gender</th>
              <th>Date_0f_Birth </th>
              <th>Date_of_Join </th>
              <th scope="col">Action</th>
            </tr>
          </thead>

          <tbody>
            {customers.map((obj, index) => (
              <tr>
                <th scope="row">{obj.employee_id}</th>
                <td>{obj.employee_name}</td>
                <td>{obj.designation}</td>
                <td>{obj.department}</td>
                <td>{obj.gender}</td>
                <td>{obj.date_of_birth}</td>
                <td>{obj.date_of_join}</td>
                <td>
                  <Link
                    className="styled-link"
                    to={
                      "/Admin/CustomerDataManagement/ViewCustomers/Edit/" +
                      obj.employee_id
                    }
                  >
                    Edit
                  </Link>

                  <button
                    type="button"
                    className="btn btn-danger"
                    onClick={() => deleteEmployee(obj.employee_id)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
