/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable no-unused-vars */
import axios from "axios";
import React, { useState, useContext, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Context } from "../../context/context";
import AdminNavbar from "./AdminNavbar";
import { toast } from "react-toastify";

export default function AddLoan() {
  const [loanId, setLoanId] = useState();
  const [loanType, setLoanType] = useState();
  const [duration_in_years, setDuration] = useState();
  const saveUrl = "http://localhost:8080/saveLoan";
  const navigate = useNavigate();
  const data = [
    ["/Admin/LoanCardManagement", "ViewLoans"],
    ["/Admin", "CustomerDataManagement"],
    ["/Admin", "ItemDataManagement"],
    ["/Admin", "LoanCardManagement"],
  ];
  const { sessionId, setSessionId } = useContext(Context);
  useEffect(() => {
    setSessionId(localStorage.getItem("sessionId"));
  }, []);
  const lidHandler = (event) => {
    setLoanId(event.target.value);
  };

  const lTypeHandler = (event) => {
    setLoanType(event.target.value);
  };

  const durationHandler = (event) => {
    setDuration(event.target.value);
  };

  const ErrorHandler = () => {
    setDuration("");
    setLoanId("");
    setLoanType("");
  };

  const submitHandler = (event) => {
    event.preventDefault();
    axios
      .post(saveUrl, {
        loan_id: loanId,
        loan_type: loanType,
        duration_in_years: duration_in_years,
      })
      .then((response) => {
        // alert(response.data);
        toast.success(response.data, { position: toast.POSITION.TOP_CENTER });
        navigate("/Admin/LoanCardManagement/ViewLoans");
      })
      .catch((error) => {
        const data = {
          heading: error.response.data,
          url: "/Admin/LoanCardManagement/AddLoan",
          content:
            "Loan Id you entered is already exists in the database. Add a Loan with different Id. Go back to add Loan!",
        };
        toast.error(error.response.data, {
          position: toast.POSITION.TOP_CENTER,
        });
        navigate("/ResourceNotFound", { state: { stateData: data } });
      });
  };

  return (
    <div className="custom-gradient">
      <AdminNavbar data={data} />
      <br></br>
      <h2 className="boxed-text bg-light-blue">Add Loan</h2>
      <br></br>
      <form class="form-container gradient-custom" onSubmit={submitHandler}>
        <label for="loanId" class="form-label">
          Loan Id
        </label>
        <input
          class="inputField"
          type="text"
          value={loanId}
          onChange={lidHandler}
          required
        />{" "}
        <br></br>
        <label for="loanType" class="form-label">
          Loan Type
        </label>
        <input
          class="inputField"
          type="text"
          value={loanType}
          onChange={lTypeHandler}
          required
        />{" "}
        <br></br>
        <label for="duration_in_years" class="form-label">
          Duration
        </label>
        <input
          class="inputField"
          type="text"
          value={duration_in_years}
          onChange={durationHandler}
          required
        />{" "}
        <br></br>
        <button class="buttonField" type="submit">
          {" "}
          Add Loan{" "}
        </button>
        <button class="buttonField" type="reset" onClick={() => ErrorHandler}>
          {" "}
          Reset{" "}
        </button>
      </form>
    </div>
  );
}
