/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable no-unused-vars */
import axios from "axios";
import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import "./style.css";
import AdminNavbar from "./AdminNavbar";

import { toast } from "react-toastify";
export default function EditItems() {
  const param = useParams();
  const [item_id, setItem_id] = useState(param.id);
  const [item_description, setItem_description] = useState("");
  const [item_make, setItem_make] = useState("");
  const [item_valuation, setItem_valuation] = useState("");
  const [item_category, setItem_Category] = useState("");
  const [issue_status, setIssue_status] = useState("");
  const data = [
    ["/Admin/ItemDataManagement", "AddItem"],
    ["/Admin/ItemDataManagement", "ViewItems"],
    ["/Admin", "CustomerDataManagement"],
    ["/Admin", "ItemDataManagement"],
    ["/Admin", "LoanCardManagement"],
  ];
  var fetchUrl = "http://localhost:8080/fetchItem/" + item_id;
  var baseURL = "http://localhost:8080/editItem/" + item_id;

  const navigate = useNavigate();

  const fetchItem = () => {
    axios.get(fetchUrl).then((response) => {
      const e = response.data;
      setItem_description(e.item_description);
      setItem_make(e.item_make);
      setIssue_status(e.issue_status);
      setItem_Category(e.item_category);
      setItem_valuation(e.item_valuation);
    });
  };

  useEffect(() => {
    fetchItem();
  }, []);

  const itemMakeHandler = (event) => {
    setItem_make(event.target.value);
  };

  const itemCategoryHandler = (event) => {
    setItem_Category(event.target.value);
  };

  const itemDescriptionrHandler = (event) => {
    setItem_description(event.target.value);
  };

  const itemValueHandler = (event) => {
    setItem_valuation(event.target.value);
  };

  const issueStatusHandler = (event) => {
    setIssue_status(event.target.value);
  };

  const ErrorHandler = () => {
    setItem_Category("");
    setItem_description("");
    setItem_make("");
    setItem_valuation("");
    setIssue_status("");
  };

  const submitHandler = (event) => {
    event.preventDefault();
    axios
      .put(baseURL, {
        item_id: item_id,
        item_category: item_category,
        item_description: item_description,
        item_make: item_make,
        item_valuation: item_valuation,
        issue_status: issue_status,
      })
      .then((response) => {
        // alert(response.data);
        toast.success(response.data, { position: toast.POSITION.TOP_CENTER });
        navigate("/Admin/ItemDataManagement/ViewItems");
      })
      .catch((error) => {
        const data = {
          heading: error.response.data,
          url: "/Admin/ItemDataManagement/ViewItems",
          content:
            "You are trying to update the Invalid Item, Go back to View Items for editing Valid Item!",
        };
        toast.error(error.response.data, {
          position: toast.POSITION.TOP_CENTER,
        });
        navigate("/ResourceNotFound", { state: { stateData: data } });
      });
  };

  return (
    <div className="custom-gradient">
      <AdminNavbar data={data} />
      <br></br>
      <h3 className="boxed-text bg-light-blur=e">
        Edit Item : Item Id - {item_id}{" "}
      </h3>{" "}
      <br></br>
      <form class="form-container gradient-custom" onSubmit={submitHandler}>
        <label for="Item_name" class="form-label">
          Item Category
        </label>
        <input
          class="inputField"
          type="text"
          defaultValue={item_category}
          onChange={itemCategoryHandler}
          required
        />{" "}
        <br></br>
        <label for="password" class="form-label">
          Item Make
        </label>
        <input
          class="inputField"
          type="text"
          defaultValue={item_make}
          onChange={itemMakeHandler}
          required
        />{" "}
        <br></br>
        <label for="gender" class="form-label">
          Item Description{" "}
        </label>
        <input
          class="inputField"
          type="text"
          defaultValue={item_description}
          onChange={itemDescriptionrHandler}
          required
        />{" "}
        <br></br>
        <label for="date_of_birth" class="form-label">
          Item Valuation{" "}
        </label>
        <input
          class="inputField"
          type="text"
          defaultValue={item_valuation}
          onChange={itemValueHandler}
          required
        />{" "}
        <br></br>
        <label for="date_of_join" class="form-label">
          Issue Status
        </label>
        <input
          class="inputField"
          type="text"
          defaultValue={issue_status}
          onChange={issueStatusHandler}
          required
        />{" "}
        <br></br>
        <button class="buttonField" type="submit" onClick={() => submitHandler}>
          {" "}
          Update{" "}
        </button>
        <button class="buttonField" type="reset" onClick={() => ErrorHandler}>
          {" "}
          Reset{" "}
        </button>
      </form>
    </div>
  );
}
