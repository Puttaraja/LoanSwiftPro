/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable no-unused-vars */
import axios from "axios";
import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import "./style.css";
import AdminNavbar from "./AdminNavbar";
import { toast } from "react-toastify";

export default function EditLoans() {
  const param = useParams();
  const [loan_id, setloan_id] = useState(param.id);
  const [loan_type, setloan_type] = useState("");
  const [duration_in_years, setDuration_in_years] = useState("");
  const data = [
    ["/Admin/LoanCardManagement", "AddLoan"],
    ["/Admin/LoanCardManagement", "ViewLoans"],
    ["/Admin", "CustomerDataManagement"],
    ["/Admin", "LoanCardManagement"],
    ["/Admin", "LoanCardManagement"],
  ];
  var fetchUrl = "http://localhost:8080/fetchLoan/" + loan_id;
  var baseURL = "http://localhost:8080/editLoan/" + loan_id;

  const navigate = useNavigate();

  const fetchloan = () => {
    axios.get(fetchUrl).then((response) => {
      const e = response.data;
      setloan_type(e.loan_type);
      setDuration_in_years(e.duration_in_years);
    });
  };

  useEffect(() => {
    fetchloan();
  }, []);

  const loanTypeHandler = (event) => {
    setloan_type(event.target.value);
  };

  const loanDurationHandler = (event) => {
    setDuration_in_years(event.target.value);
  };

  const ErrorHandler = () => {
    setloan_type("");
    setDuration_in_years("");
  };

  const submitHandler = (event) => {
    event.preventDefault();
    axios
      .put(baseURL, {
        loan_id: loan_id,
        loan_type: loan_type,
        duration_in_years: duration_in_years,
      })
      .then((response) => {
        toast.success(response.data, { position: toast.POSITION.TOP_CENTER });
        // alert(response.data);
        navigate("/Admin/LoanCardManagement/ViewLoans");
      })
      .catch((error) => {
        const data = {
          heading: error.response.data,
          url: "/Admin/LoanCardManagement/ViewLoans",
          content:
            "You are trying to update the Invalid Loan, Go back to View Loans for editing Valid Loan!",
        };
        toast.error(error.response.data, {
          position: toast.POSITION.TOP_CENTER,
        });
        navigate("/ResourceNotFound", { state: { stateData: data } });
      });
  };

  return (
    <div className="custom-gradient">
      <AdminNavbar data={data} />
      <br></br>
      <h3 className="boxed-text bg-light-blue">
        Edit Loan : Loan Id - {loan_id}{" "}
      </h3>
      <br></br>
      <form class="form-container gradient-custom" onSubmit={submitHandler}>
        <br></br>
        <label for="loan_name" class="form-label">
          Loan Type
        </label>
        <input
          class="inputField"
          type="text"
          defaultValue={loan_type}
          onChange={loanTypeHandler}
          required
        />{" "}
        <br></br>
        <label for="password" class="form-label">
          Duration in Years
        </label>
        <input
          class="inputField"
          type="text"
          defaultValue={duration_in_years}
          onChange={loanDurationHandler}
          required
        />{" "}
        <br></br>
        <button class="buttonField" type="submit" onClick={() => submitHandler}>
          {" "}
          Update{" "}
        </button>
        <button class="buttonField" type="reset" onClick={() => ErrorHandler}>
          {" "}
          Reset{" "}
        </button>
      </form>
    </div>
  );
}
