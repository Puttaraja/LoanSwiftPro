/* eslint-disable react-hooks/exhaustive-deps */
import axios from "axios";
import React, { useState, useContext, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Context } from "../../context/context";
import AdminNavbar from "./AdminNavbar";
import { toast } from "react-toastify";

export default function AddItem() {
  const [itemId, setItemId] = useState();
  const [itemCategory, setItemCategory] = useState();
  const [itemDescr, setItemDescr] = useState();
  const [status, setStatus] = useState();
  const [itemMake, setItemMake] = useState();
  const [itemValue, setItemValue] = useState();
  const data = [
    ["/Admin/ItemDataManagement", "ViewItems"],
    ["/Admin", "CustomerDataManagement"],
    ["/Admin", "ItemDataManagement"],
    ["/Admin", "LoanCardManagement"],
  ];
  const saveUrl = "http://localhost:8080/saveItem";
  const navigate = useNavigate();
  // eslint-disable-next-line no-unused-vars
  const { sessionId, setSessionId } = useContext(Context);
  useEffect(() => {
    setSessionId(localStorage.getItem("sessionId"));
  }, []);

  const iidHandler = (event) => {
    setItemId(event.target.value);
  };

  const itemMakeHandler = (event) => {
    setItemMake(event.target.value);
  };
  const itemDescrHandler = (event) => {
    setItemDescr(event.target.value);
  };
  const itemCategoryHandler = (event) => {
    setItemCategory(event.target.value);
  };
  const itemValueHandler = (event) => {
    setItemValue(event.target.value);
  };

  const statusHandler = (event) => {
    setStatus(event.target.value);
  };

  const ErrorHandler = () => {
    setItemCategory("");
    setItemDescr("");
    setItemId("");
    setItemMake("");
    setItemValue("");
    setStatus("");
  };

  const submitHandler = (event) => {
    event.preventDefault();
    axios
      .post(saveUrl, {
        item_id: itemId,
        item_category: itemCategory,
        item_make: itemMake,
        item_description: itemDescr,
        item_valuation: itemValue,
        issue_status: status,
      })
      .then((response) => {
        // alert(response.data);
        toast.success(response.data, { position: toast.POSITION.TOP_CENTER });
        navigate("/Admin/ItemDataManagement/ViewItems");
      })
      .catch((error) => {
        const data = {
          heading: error.response.data,
          url: "/Admin/ItemDataManagement/AddItem",
          content:
            "Item Id you entered is already exists in the database. Add a item with different Id. Go back to add Item!",
        };
        toast.error(error.response.data, {
          position: toast.POSITION.TOP_CENTER,
        });
        navigate("/ResourceNotFound", { state: { stateData: data } });
      });
  };

  return (
    <div className="custom-gradient">
      <AdminNavbar data={data} />
      <br></br>
      <h3 className="boxed-text bg-light-blue">Add Item</h3>
      <br></br>
      <form class="form-container gradient-custom" onSubmit={submitHandler}>
        <label for="itemId" class="form-label">
          Item ID
        </label>
        <input
          class="inputField"
          type="text"
          value={itemId}
          onChange={iidHandler}
          required
        />{" "}
        <br></br>
        <label for="itemCategory" class="form-label">
          Item Category
        </label>
        <input
          class="inputField"
          type="text"
          value={itemCategory}
          onChange={itemCategoryHandler}
          required
        />{" "}
        <br></br>
        <label for="itemMake" class="form-label">
          Item Make
        </label>
        <input
          class="inputField"
          type="text"
          value={itemMake}
          onChange={itemMakeHandler}
          required
        />{" "}
        <br></br>
        <label for="itemDescr" class="form-label">
          Item Description
        </label>
        <input
          class="inputField"
          type="text"
          value={itemDescr}
          onChange={itemDescrHandler}
          required
        />{" "}
        <br></br>
        <label for="itemValue" class="form-label">
          Item Valuation
        </label>
        <input
          class="inputField"
          type="text"
          value={itemValue}
          onChange={itemValueHandler}
          required
        />{" "}
        <br></br>
        <label for="itemCategory" class="form-label">
          Issue Status
        </label>
        <input
          class="inputField"
          type="text"
          value={status}
          onChange={statusHandler}
          required
        />{" "}
        <button class="buttonField" type="submit">
          {" "}
          Add Item{" "}
        </button>
        <button class="buttonField" type="reset" onClick={() => ErrorHandler}>
          {" "}
          Reset{" "}
        </button>
      </form>
    </div>
  );
}
