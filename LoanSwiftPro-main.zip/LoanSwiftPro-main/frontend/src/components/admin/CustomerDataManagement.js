import React from "react";
import "./style.css";
import AdminNavbar from "./AdminNavbar";
import AdminDetails from "./AdminDetails";

export default function CustomerDataManagement() {
  const data = [
    ["/Admin", "ItemDataManagement"],
    ["/Admin", "LoanCardManagement"],
  ];
  const linksData = [
    ["/Admin/CustomerDataManagement/AddCustomer", "Add Customer"],
    ["/Admin/CustomerDataManagement/ViewCustomers", "View Customer Data"],
  ];
  return (
    <div className="custom-gradient">
      <AdminNavbar data={data} />
      <AdminDetails linksData={linksData} />
    </div>
  );
}
