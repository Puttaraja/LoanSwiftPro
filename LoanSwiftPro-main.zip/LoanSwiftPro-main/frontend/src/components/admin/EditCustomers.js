/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable no-unused-vars */
import axios from "axios";
import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import "./style.css";
import AdminNavbar from "./AdminNavbar";

import { toast } from "react-toastify";
export default function EditCustomers() {
  const param = useParams();
  const [employee_id, setEmployee_id] = useState(param.id);
  const [employee_name, setEmployee_name] = useState("");
  const [password, setPassword] = useState("");
  const [gender, setGender] = useState("");
  const [date_of_join, setDate_of_join] = useState("");
  const [date_of_birth, setDate_of_birth] = useState("");
  const [department, setDepartment] = useState("");
  const [designation, setDesignation] = useState("");
  const [error, setError] = useState("");
  const data = [
    ["/Admin/CustomerDataManagement", "AddCustomer"],
    ["/Admin/CustomerDataManagement", "ViewCustomers"],
    ["/Admin", "CustomerDataManagement"],
    ["/Admin", "ItemDataManagement"],
    ["/Admin", "LoanCardManagement"],
  ];
  var fetchUrl = "http://localhost:8080/fetchEmployee/" + employee_id;
  var baseURL = "http://localhost:8080/editEmployee/" + employee_id;

  const navigate = useNavigate();

  const fetchEmployee = () => {
    axios
      .get(fetchUrl)
      .then((response) => {
        const e = response.data;
        setEmployee_name(e.employee_name);
        setDate_of_birth(e.date_of_birth);
        setDate_of_join(e.date_of_join);
        setDepartment(e.department);
        setDesignation(e.designation);
        setGender(e.gender);
        setPassword(e.password);
      })
      .catch((error) => {
        const data = {
          heading: error.response.data,
          url: "/Admin/CustomerDataManagement/ViewCustomers",
          content:
            "You are trying to update the Invalid Customer, Go back to View Customers for editing Valid Customer!",
        };
        toast.error(error.response.data, {
          position: toast.POSITION.TOP_CENTER,
        });
        navigate("/ResourceNotFound", { state: { stateData: data } });
      });
  };

  useEffect(() => {
    fetchEmployee();
  }, []);

  const enameHandler = (event) => {
    setEmployee_name(event.target.value);
  };

  const genderHandler = (event) => {
    setGender(event.target.value);
  };

  const dojHandler = (event) => {
    const selectedDate = new Date(event.target.value);
    let currentDate = new Date(date_of_birth);
    currentDate.setFullYear(currentDate.getFullYear() + 15);

    if (selectedDate < currentDate) {
      setError("Date of Joining must be at least 15 years greater than DOB");
    } else {
      setError("");
      setDate_of_join(event.target.value);
    }
  };

  const dojHandler1 = () => {
    const selectedDate = new Date(date_of_join);
    let currentDate = new Date(date_of_birth);
    currentDate.setFullYear(currentDate.getFullYear() + 15);

    if (selectedDate < currentDate) {
      setError("Date of Joining must be at least 15 years greater than DOB");
      setDate_of_join("");
    } else {
      setError("");
      setDate_of_join(date_of_join);
    }
  };

  useEffect(() => {
    dojHandler1();
  }, []);

  const dobHandler = (event) => {
    setDate_of_birth(event.target.value);
    const selectedDate = new Date(date_of_join);
    let currentDate = new Date(date_of_birth);
    currentDate.setFullYear(currentDate.getFullYear() + 15);

    if (selectedDate < currentDate) {
      setError("Date of Joining must be at least 15 years greater than DOB");
      setDate_of_join("");
    } else {
      setError("");
      setDate_of_join(date_of_join);
    }
  };

  const deptHandler = (event) => {
    setDepartment(event.target.value);
  };

  const designationHandler = (event) => {
    setDesignation(event.target.value);
  };

  const ErrorHandler = () => {
    setEmployee_name("");
    setGender("");
    setDate_of_birth("");
    setDate_of_join("");
    setDesignation("");
    setDepartment("");
  };

  const submitHandler = (event) => {
    event.preventDefault();
    axios
      .put(baseURL, {
        employee_id: employee_id,
        employee_name: employee_name,
        password: password,
        gender: gender,
        date_of_join: date_of_join,
        date_of_birth: date_of_birth,
        department: department,
        designation: designation,
      })
      .then((response) => {
        // alert(response.data);
        if (response.data === "Employee updated Succefully") {
          ErrorHandler();
          toast.success(response.data, { position: toast.POSITION.TOP_CENTER });
          navigate("/Admin/CustomerDataManagement/ViewCustomers");
        }
      })
      .catch((error) => {
        const data = {
          heading: error.response.data,
          url: "/Admin/CustomerDataManagement/ViewCustomers",
          content:
            "You are trying to update the Invalid Customer, Go back to View Customers for editing Valid customer!",
        };
        toast.error(error.response.data, {
          position: toast.POSITION.TOP_CENTER,
        });
        navigate("/ResourceNotFound", { state: { stateData: data } });
      });
  };

  return (
    <div className="custom-gradient">
      <AdminNavbar data={data} />
      <br></br>
      <h3 className="boxed-text bg-light-blue">
        Edit Customer : Employee Id - {employee_id}{" "}
      </h3>
      <br></br>
      <form class="form-container gradient-custom" onSubmit={submitHandler}>
        <br></br>
        <label for="employee_name" class="form-label">
          Name
        </label>
        <input
          class="inputField"
          type="text"
          defaultValue={employee_name}
          onChange={enameHandler}
          required
        />{" "}
        <br></br>
        <label for="gender" class="form-label">
          Gender{" "}
        </label>
        <input
          class="inputField"
          type="text"
          defaultValue={gender}
          onChange={genderHandler}
          required
        />{" "}
        <br></br>
        <label for="date_of_birth" class="form-label">
          Date of Birth{" "}
        </label>
        <input
          class="inputField"
          type="date"
          defaultValue={date_of_birth}
          onChange={dobHandler}
          required
        />{" "}
        <br></br>
        <label for="date_of_join" class="form-label">
          Date of Join
        </label>
        <input
          class="inputField"
          type="date"
          value={date_of_join}
          onChange={dojHandler}
          required
        />{" "}
        {error && <div className="error">{error}</div>}
        <br></br>
        <label for="department" class="form-label">
          Department
        </label>
        <input
          class="inputField"
          type="text"
          defaultValue={department}
          onChange={deptHandler}
          required
        />{" "}
        <br></br>
        <label for="designation" class="form-label">
          Designation
        </label>
        <input
          class="inputField"
          type="text"
          defaultValue={designation}
          onChange={designationHandler}
          required
        />{" "}
        <br></br>
        <button class="buttonField" type="submit">
          {" "}
          Update{" "}
        </button>
        <button class="buttonField" type="reset" onClick={() => ErrorHandler}>
          {" "}
          Reset{" "}
        </button>
      </form>
    </div>
  );
}
