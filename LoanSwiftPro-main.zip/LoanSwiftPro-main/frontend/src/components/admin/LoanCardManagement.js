import React from "react";
import "./style.css";
import AdminNavbar from "./AdminNavbar";
import AdminDetails from "./AdminDetails";

export default function LoanCardManagement() {
  const data = [
    ["/Admin", "CustomerDataManagement"],
    ["/Admin", "ItemDataManagement"],
  ];
  const linksData = [
    ["/Admin/LoanCardManagement/AddLoan", "Add Loan"],
    ["/Admin/LoanCardManagement/ViewLoans", "View Loans"],
  ];
  return (
    <div className="custom-gradient">
      <AdminNavbar data={data} />
      <AdminDetails linksData={linksData} />
    </div>
  );
}
