import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import "./style.css";
import Select from "@mui/material/Select";
import { InputLabel, MenuItem } from "@mui/material";
import FormControl from "@mui/material/FormControl";
import AdminNavbar from "./AdminNavbar";
import { toast } from "react-toastify";

export default function AdminRegister() {
  const baseURL = "http://localhost:8080/saveAdmin"; //insertion of url corresponding to eclipses url(backend)
  const [employee_id, setEmployee_id] = useState("");
  const [employee_name, setEmployee_name] = useState("");
  const [password, setPassword] = useState("");
  const [gender, setGender] = useState("");
  const [date_of_join, setDate_of_join] = useState("");
  const [date_of_birth, setDate_of_birth] = useState("");
  const [department, setDepartment] = useState("");
  const [designation, setDesignation] = useState("");
  const [popUp, setPopUp] = useState(false);
  const [popUp1, setPopUp1] = useState(false);
  const data = [];
  const [error, setError] = useState("");

  const navigate = useNavigate();
  const eidHandler = (event) => {
    setEmployee_id(event.target.value);
  };

  const enameHandler = (event) => {
    setEmployee_name(event.target.value);
  };

  const passwordHandler = (event) => {
    setPassword(event.target.value);
  };

  const genderHandler = (event) => {
    setGender(event.target.value);
  };

  const dojHandler = (event) => {
    const selectedDate = new Date(event.target.value);
    let currentDate = new Date(date_of_birth);
    currentDate.setFullYear(currentDate.getFullYear() + 15);

    if (selectedDate < currentDate) {
      setError("Date of Joining must be at least 15 years greater than DOB");
    } else {
      setError("");
      setDate_of_join(event.target.value);
    }
  };

  const dobHandler = (event) => {
    setDate_of_birth(event.target.value);
  };

  const deptHandler = (event) => {
    setDepartment(event.target.value);
  };

  const designationHandler = (event) => {
    setDesignation(event.target.value);
  };

  const ErrorHandler = () => {
    setEmployee_id("");
    setEmployee_name("");
    setPassword("");
    setGender("");
    setDate_of_birth("");
    setDate_of_join("");
    setDesignation("");
    setDepartment("");
  };

  const storeItems = () => {
    localStorage.setItem("sessionId", employee_id);
    localStorage.setItem("password", password);
    localStorage.setItem("department", department);
    localStorage.setItem("designation", designation);
  };

  const submitHandler = (event) => {
    event.preventDefault();
    axios
      .post(baseURL, {
        admin_id: employee_id,
        admin_name: employee_name,
        password: password,
        gender: gender,
        date_of_join: date_of_join,
        date_of_birth: date_of_birth,
        department: department,
        designation: designation,
      })
      .then((response) => {
        const isSuccess = response.data;

        if (isSuccess === "Admin Registered Successfully") {
          ErrorHandler();
          storeItems();
          toast.success(response.data, { position: toast.POSITION.TOP_CENTER });
          navigate("/Admin");
        }
      })
      .catch((error) => {
        const data = {
          heading: error.response.data,
          url: "/adminRegister",
          content:
            "You are registering with existing Admin Id, Go back and register with different Id!",
        };
        toast.error(error.response.data, {
          position: toast.POSITION.TOP_CENTER,
        });
        navigate("/ResourceNotFound", { state: { stateData: data } });
      });
  };

  const PassPopupTrue = (event) => {
    setPopUp(true);
  };

  const PassPopupFalse = () => {
    setPopUp(false);
  };

  const PassPopupTrue1 = (event) => {
    setPopUp1(true);
  };

  const PassPopupFalse1 = () => {
    setPopUp1(false);
  };

  return (
    <div className="background-image-register">
      <AdminNavbar data={data} />
      <br></br>
      <h2> ADMIN REGISTER </h2>
      <br></br>
      <form class="form-container gradient-custom" onSubmit={submitHandler}>
        <label for="employee_id" class="form-label">
          Admin ID
        </label>
        <input
          class="inputField"
          type="text"
          value={employee_id}
          onChange={eidHandler}
          onFocus={PassPopupTrue1}
          onBlur={PassPopupFalse1}
          required
          pattern="^[A-Z0-9]{8}$"
        />{" "}
        {popUp1 && (
          <div className="PopUp">
            <ul class="requirement-list">
              <li>
                <i class="fa-solid fa-circle"></i>
                <span>Id must be of 8 characters length</span>
              </li>
              <li>
                <i class="fa-solid fa-circle"></i>
                <span>Only Capital Letters and Numbers are allowed</span>
              </li>
            </ul>
          </div>
        )}
        <br></br>
        <label for="employee_name" class="form-label">
          Name
        </label>
        <input
          class="inputField"
          type="text"
          value={employee_name}
          onChange={enameHandler}
          required
        />{" "}
        <br></br>
        <label for="password" class="form-label">
          Password
        </label>
        <input
          class="inputField"
          type="password"
          value={password}
          onChange={passwordHandler}
          onFocus={PassPopupTrue}
          onBlur={PassPopupFalse}
          required
          pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}"
        />{" "}
        {popUp && (
          <div className="PopUp">
            <p>Password must contain</p>
            <ul class="requirement-list">
              <li>
                <i class="fa-solid fa-circle"></i>
                <span>At least 8 characters length</span>
              </li>
              <li>
                <i class="fa-solid fa-circle"></i>
                <span>At least 1 number (0...9)</span>
              </li>
              <li>
                <i class="fa-solid fa-circle"></i>
                <span>At least 1 lowercase letter (a...z)</span>
              </li>
              <li>
                <i class="fa-solid fa-circle"></i>
                <span>At least 1 uppercase letter (A...Z)</span>
              </li>
              <li>
                <i class="fa-solid fa-circle"></i>
                <span>At least 1 special symbol</span>
              </li>
            </ul>
          </div>
        )}
        <br></br>
        <label for="gender" class="form-label">
          Gender
        </label>
        <FormControl sx={{ m: 1, minWidth: 322 }} size="small">
          <InputLabel id="demo-simple-small-label">M / F</InputLabel>
          <Select
            labelId="demo-simple-small-label"
            id="demo-simple-small"
            value={gender}
            label="Gender"
            onChange={genderHandler}
          >
            <MenuItem value={"M"}>Male</MenuItem>
            <MenuItem value={"F"}>Female</MenuItem>
          </Select>
        </FormControl>
        <br />
        <label for="date_of_birth" class="form-label">
          Date of Birth{" "}
        </label>
        <input
          class="inputField"
          type="date"
          value={date_of_birth}
          onChange={dobHandler}
          required
        />{" "}
        <br></br>
        <label for="date_of_join" class="form-label">
          Date of Join
        </label>
        <input
          class="inputField"
          type="date"
          value={date_of_join}
          onChange={dojHandler}
          required
        />{" "}
        {error && <div className="error">{error}</div>}
        <br></br>
        <label for="department" class="form-label">
          Department
        </label>
        <input
          class="inputField"
          type="text"
          value={department}
          onChange={deptHandler}
          required
        />{" "}
        <br></br>
        <label for="designation" class="form-label">
          Designation
        </label>
        <input
          class="inputField"
          type="text"
          value={designation}
          onChange={designationHandler}
          required
        />{" "}
        <br></br>
        <button class="buttonField" type="submit">
          {" "}
          Register{" "}
        </button>
        <button class="buttonField" type="reset" onClick={() => ErrorHandler}>
          {" "}
          Reset{" "}
        </button>
      </form>
    </div>
  );
}
