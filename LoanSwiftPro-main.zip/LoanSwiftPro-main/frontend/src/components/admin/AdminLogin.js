import React, { useState, useEffect } from "react";
import axios from "axios";
import "./style.css";
import { useNavigate } from "react-router-dom";
import AdminNavbar from "./AdminNavbar";
import { toast } from "react-toastify";

export default function AdminLogin() {
  const baseURL = "http://localhost:8080/loginAdmin";
  var fetchURL = "http://localhost:8080/fetchAdmin/";
  const [admin_id, setAdmin_id] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();
  var isSuccess = "";
  const data = [];
  const aidHandler = (event) => {
    setAdmin_id(event.target.value);
  };

  const passwordHandler = (event) => {
    setPassword(event.target.value);
  };

  const fetchEmployee = () => {
    //console.log(fetchURL);
    axios.get(fetchURL).then((response) => {
      const e = response.data;
      console.log(e.designation);
      console.log(e.department);
      localStorage.setItem("department", e.department);
      localStorage.setItem("designation", e.designation);
    });
  };

  const storeItems = () => {
    localStorage.setItem("sessionId", admin_id);
    localStorage.setItem("password", password);
  };

  const submitHandler = (event) => {
    event.preventDefault();
    axios
      .post(baseURL, {
        employee_id: admin_id,
        password: password,
      })
      .then((response) => {
        isSuccess = response.data;

        if (isSuccess === "Login Successful") {
          fetchURL = fetchURL + admin_id;
          fetchEmployee();
          storeItems();
          toast.success(response.data, { position: toast.POSITION.TOP_CENTER });
          localStorage.setItem("sessionId", admin_id);
          localStorage.setItem("password", password);
          navigate("/Admin");
        }
      })
      .catch((error) => {
        const data = {
          heading: error.response.data,
          url: "/adminLogin",
          content: "Login with valid credentials, Go back to Login!",
        };
        toast.error(error.response.data, {
          position: toast.POSITION.TOP_CENTER,
        });
        navigate("/ResourceNotFound", { state: { stateData: data } });
      });
  };

  useEffect(() => {
    if (localStorage.getItem("sessionId")) navigate("/Admin");
  });

  return (
    <div className="background-image-login">
      <AdminNavbar data={data} />
      <div class="form-table">
        <br></br>
        <br />
        <br />
        <h2>ADMIN LOGIN</h2>
        <br></br>
        <form class="form-container gradient-custom" onSubmit={submitHandler}>
          <label for="admin_id" class="form-label">
            Admin ID
          </label>
          <input
            class="inputField"
            type="text"
            value={admin_id}
            onChange={aidHandler}
            required
          />{" "}
          <br></br>
          <label for="password" class="form-label">
            Password
          </label>
          <input
            class="inputField"
            type="password"
            value={password}
            onChange={passwordHandler}
            required
          />{" "}
          <br></br>
          <button class="buttonField" type="submit">
            {" "}
            Login{" "}
          </button>
        </form>
      </div>
    </div>
  );
}
