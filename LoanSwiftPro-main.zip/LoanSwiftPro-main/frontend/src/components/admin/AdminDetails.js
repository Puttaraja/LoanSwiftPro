import React, { useState, useEffect } from "react";
import "./style.css";
import AppLogo from "../../assets/lsp-logo.png";
import { Link } from "react-router-dom";

export default function AdminDetails(props) {
  const [admin_id, setAdmin_id] = useState("");
  const [department, setDepartment] = useState("");
  const [designation, setDesignation] = useState("");

  const setItems = () => {
    setAdmin_id(localStorage.getItem("sessionId"));
    setDepartment(localStorage.getItem("department"));
    setDesignation(localStorage.getItem("designation"));
  };

  useEffect(() => {
    setItems();
  }, []);

  return (
    <div>
      <br></br>
      <div className="row mx-auto">
        <div className="col-md-1"></div>
        <div className="col-md-3 boxed-text">
          <h3>Admin Id: {admin_id}</h3>
        </div>
        <div className="col-md-3 boxed-text">
          <h3>Designation: {designation}</h3>
          {console.log(localStorage.getItem("designation"))}
        </div>
        <div className="col-md-3 boxed-text">
          <h3>Department: {department} </h3>
          {console.log(localStorage.getItem("department"))}
        </div>
      </div>
      <br></br>
      <div className="row mx-auto">
        <div className="col-md-2"></div>
        <div className="col-md-4">
          <img
            className="app-logo"
            src={AppLogo}
            alt="LoanSwiftPro-Logo"
            height="100%"
            width="80%"
          ></img>
        </div>
        {
          <div class="col-md-3 border link-container d-flex flex-column align-items-center">
            {props.linksData.map((element) => (
              <Link class="styled-link" to={element[0]}>
                {element[1]}
              </Link>
            ))}
          </div>
        }
        <div className="col-md-3"></div>
      </div>
    </div>
  );
}
