/* eslint-disable react-hooks/exhaustive-deps */
import axios from "axios";
import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "./style.css";
import AdminNavbar from "./AdminNavbar";
import { toast } from "react-toastify";

export default function ViewLoans() {
  const baseURL = "http://localhost:8080/fetchLoans";
  const [loans, setLoans] = useState([]);
  var deleteUrl = "http://localhost:8080/deleteLoan/";
  const navigate = useNavigate();
  const data = [
    ["/Admin/LoanCardManagement", "AddLoan"],
    ["/Admin", "CustomerDataManagement"],
    ["/Admin", "ItemDataManagement"],
    ["/Admin", "LoanCardManagement"],
  ];
  const getSetLoanData = () => {
    axios
      .get(baseURL)
      .then((response) => {
        setLoans(response.data);
      })
      .catch((error) => {
        const data = {
          heading: error.response.data,
          url: "/Admin/LoanCardManagement/AddLoan",
          content:
            "Loans are not present in the database, Add loans in the database. Go back to add Loans!",
        };
        toast.error(error.response.data, {
          position: toast.POSITION.TOP_CENTER,
        });
        navigate("/ResourceNotFound", { state: { stateData: data } });
      });
  };

  const deleteLoan = (id) => {
    deleteUrl = deleteUrl + id;
    axios
      .delete(deleteUrl)
      .then((response) => {
        console.log(response.data);
        // alert(response.data);
        toast.success(response.data, { position: toast.POSITION.TOP_CENTER });
        getSetLoanData();
      })
      .catch((error) => {
        const data = {
          heading: error.response.data,
          url: "/Admin/LoanCardManagement/ViewLoans",
          content:
            "You are trying to delete the Invalid Loan, Go back to View Loans for deleting Valid Loan!",
        };
        toast.error(error.response.data, {
          position: toast.POSITION.TOP_CENTER,
        });
        navigate("/ResourceNotFound", { state: { stateData: data } });
      });
  };

  useEffect(() => {
    getSetLoanData();
  }, []);

  return (
    <div className="custom-gradient">
      <AdminNavbar data={data} />
      <br></br>
      <h2 className="boxed-text bg-light-blue">Loans Table </h2>
      <br></br>
      <div className="custom-table">
        <table className=" table-container gradient-custom">
          <thead>
            <tr>
              <th>LOAN ID</th>
              <th>LOAN TYPE</th>
              <th>DURATION (in years)</th>
              <th scope="col">ACTION (EDIT or DELETE)</th>
            </tr>
          </thead>
          <tbody>
            {loans.map((obj, index) => (
              <tr>
                <th scope="row">{obj.loan_id}</th>
                <td>{obj.loan_type}</td>
                <td>{obj.duration_in_years}</td>
                <td>
                  <Link
                    className="styled-link"
                    to={
                      "/Admin/LoanCardManagement/ViewLoans/Edit/" + obj.loan_id
                    }
                  >
                    Edit
                  </Link>
                  <button
                    type="button"
                    className="btn btn-danger"
                    onClick={() => deleteLoan(obj.loan_id)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
