import React from "react";
import Applogo from "../../assets/logo.png";
import AdminLogout from "./AdminLogout";
import "./style.css";
import { Link } from "react-router-dom";

export default function AdminNavbar(props) {
  return (
    <div className="custom-navbar">
      <nav class="gradient-custom navbar navbar-expand-lg navbar-light bg-light">
        <div className="p-1 mb-1">
          <Link class="navbar-brand" to={"/Admin"}>
            <img src={Applogo} width="50" height="50" alt="" />
          </Link>
        </div>
        <Link class="navbar-brand " to={"/Admin"}>
          <h1>LoanSwiftPro</h1>
        </Link>

        <button
          class="navbar-toggler"
          type="button"
          data-toggle="collapse"
          data-target="#navbarNavDropdown"
          aria-controls="navbarNavDropdown"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span class="navbar-toggler-icon"></span>
        </button>

        <div
          class="collapse navbar-collapse justify-content-end"
          id="navbarNavDropdown"
        >
          <ul class="navbar-nav">
            {props.data.length > 0 ? (
              <>
                <div className="">
                  <li class="nav-item dropdown">
                    <button
                      type="button"
                      class="nav-item login_btnnn dropdown-toggle "
                      id="navbarDropdownMenuLink"
                      data-toggle="dropdown"
                      aria-haspopup="true"
                      aria-expanded="false"
                    >
                      More
                    </button>

                    {
                      <div
                        class="dropdown-menu "
                        aria-labelledby="navbarDropdownMenuLink"
                      >
                        {props.data.map((element) => (
                          <Link
                            class="dropdown-item"
                            to={element[0] + "/" + element[1]}
                          >
                            {element[1]}
                          </Link>
                        ))}
                      </div>
                    }
                  </li>
                </div>
                <div class="">
                  <li class="nav-item">
                    <AdminLogout />
                  </li>
                </div>
              </>
            ) : (
              <div class="">
                <AdminLogout />
              </div>
            )}
          </ul>
        </div>
      </nav>
    </div>
  );
}
