/* eslint-disable react-hooks/exhaustive-deps */
import axios from "axios";
import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import AdminNavbar from "./AdminNavbar";
import "./style.css";
import { toast } from "react-toastify";

export default function ViewItems() {
  const baseURL = "http://localhost:8080/fetchItems";
  const [items, setItems] = useState([]);
  var deleteUrl = "http://localhost:8080/deleteItem/";
  const data = [
    ["/Admin/ItemDataManagement", "AddItem"],
    ["/Admin", "CustomerDataManagement"],
    ["/Admin", "ItemDataManagement"],
    ["/Admin", "LoanCardManagement"],
  ];
  const navigate = useNavigate();
  const getSetItemData = () => {
    axios
      .get(baseURL)
      .then((response) => {
        setItems(response.data);
      })
      .catch((error) => {
        const data = {
          heading: error.response.data,
          url: "/Admin/ItemDataManagement/AddItem",
          content:
            "Items are not present in the database, Add items in the database. Go back to add Items!",
        };
        toast.error(error.response.data, {
          position: toast.POSITION.TOP_CENTER,
        });
        navigate("/ResourceNotFound", { state: { stateData: data } });
      });
  };

  const deleteItem = (Id) => {
    deleteUrl = deleteUrl + Id;
    axios
      .delete(deleteUrl)
      .then((response) => {
        console.log(response.data);
        // alert(response.data);
        toast.success(response.data, { position: toast.POSITION.TOP_CENTER });
        getSetItemData();
      })
      .catch((error) => {
        const data = {
          heading: error.response.data,
          url: "/Admin/ItemDataManagement/ViewItems",
          content:
            "You are trying to delete the Invalid Item, Go back to View Items for deleting Valid Item!",
        };
        toast.error(error.response.data, {
          position: toast.POSITION.TOP_CENTER,
        });
        navigate("/ResourceNotFound", { state: { stateData: data } });
      });
  };

  useEffect(() => {
    getSetItemData();
  }, []);

  return (
    <div className="custom-gradient">
      <AdminNavbar data={data} />
      <br></br>
      <h2 className="boxed-text bg-light-blue">Items Table </h2>
      <br></br>
      <div className="custom-table">
        <table className=" table-container gradient-custom">
          <thead>
            <tr>
              <th>ITEM ID</th>
              <th>ITEM DESCRIPTION</th>
              <th>ITEM CATEGORY</th>
              <th>ITEM VALUATION</th>
              <th>ITEM STATUS</th>
              <th>ITEM MAKE</th>
              <th scope="col">Action</th>
            </tr>
          </thead>

          <tbody>
            {items.map((obj, index) => (
              <tr>
                <th scope="row">{obj.item_id}</th>
                <td>{obj.item_description}</td>
                <td>{obj.item_category}</td>
                <td>{obj.item_valuation}</td>
                <td>{obj.issue_status}</td>
                <td>{obj.item_make}</td>
                <td>
                  <Link
                    className="styled-link"
                    to={
                      "/Admin/ItemDataManagement/ViewItems/Edit/" + obj.item_id
                    }
                  >
                    Edit
                  </Link>
                  <button
                    type="button"
                    className="btn btn-danger"
                    onClick={() => deleteItem(obj.item_id)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
