/* eslint-disable react-hooks/exhaustive-deps */
import React from "react";
import { useState } from "react";
import axios from "axios";
import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "./style.css";
import TextField from "@mui/material/TextField";
import Select from "@mui/material/Select";
import { InputLabel, MenuItem } from "@mui/material";
import FormControl from "@mui/material/FormControl";
import UserNavbar from "./UserNavbar";
import { toast } from "react-toastify";

export default function ApplyLoans() {
  const itemMakeUrl = "http://localhost:8080/fetchItemMake";
  const itemCategoryUrl = "http://localhost:8080/fetchItemCategory";
  const itemDescUrl = "http://localhost:8080/fetchItemDescs";
  var itemMakeByCategoryUrl = "http://localhost:8080/fetchItemMakesByCategory/";
  var itemDescByCategoryMakeUrl =
    "http://localhost:8080/fetchItemDescsByCategoryMake/";
  var itemValueByCategoryMakeDescUrl =
    "http://localhost:8080/fetchItemValueByCategoryMakeDesc/";
  var applyLoanUrl = "http://localhost:8080/applyLoans";
  var [itemMakes, setItemMakes] = useState([]);
  var [itemCategories, setItemCategories] = useState([]);

  const data = ["ViewLoans", "ViewItems"];

  var [itemDescs, setItemDescs] = useState([]);

  var [make, setMake] = useState();
  var [category, setCategory] = useState();
  var [desc, setDesc] = useState();
  var [value, setValue] = useState();

  const navigate = useNavigate();

  const getSetItemCategories = () => {
    axios
      .get(itemCategoryUrl)
      .then((response) => {
        setItemCategories(response.data);
      })
      .catch((error) => {
        const data = {
          heading: error.response.data,
          url: "/Employees/employee",
          content:
            "Item categories are not present in the database. Go back to dashboard!",
        };
        toast.error(error.response.data, {
          position: toast.POSITION.TOP_CENTER,
        });
        navigate("/ResourceNotFound", { state: { stateData: data } });
      });
  };

  const getSetItemMakes = () => {
    axios
      .get(itemMakeUrl)
      .then((response) => {
        setItemMakes(response.data);
      })
      .catch((error) => {
        const data = {
          heading: error.response.data,
          url: "/Employees/employee",
          content:
            "Item makes are not present in the database. Go back to dashboard!",
        };
        toast.error(error.response.data, {
          position: toast.POSITION.TOP_CENTER,
        });
        navigate("/ResourceNotFound", { state: { stateData: data } });
      });
  };

  const getSetItemDescs = () => {
    axios
      .get(itemDescUrl)
      .then((response) => {
        setItemDescs(response.data);
      })
      .catch((error) => {
        const data = {
          heading: error.response.data,
          url: "/Employees/employee",
          content:
            "Item descriptions are not present in the database. Go back to dashboard!",
        };
        toast.error(error.response.data, {
          position: toast.POSITION.TOP_CENTER,
        });
        navigate("/ResourceNotFound", { state: { stateData: data } });
      });
  };

  const getSetItemMakesByCategory = () => {
    axios
      .get(itemMakeByCategoryUrl)
      .then((response) => {
        setItemMakes(response.data);
      })
      .catch((error) => {
        const data = {
          heading: error.response.data,
          url: "/Employees/employee",
          content:
            "Item makes are not present for this category in the database. Go back to dashboard!",
        };
        toast.error(error.response.data, {
          position: toast.POSITION.TOP_CENTER,
        });
        navigate("/ResourceNotFound", { state: { stateData: data } });
      });
  };

  const getSetItemDescsByCategoryMake = () => {
    axios
      .get(itemDescByCategoryMakeUrl)
      .then((response) => {
        setItemDescs(response.data);
      })
      .catch((error) => {
        const data = {
          heading: error.response.data,
          url: "/Employees/employee",
          content:
            "Item desciptions are not present for these item details in the database. Go back to dashboard!",
        };
        toast.error(error.response.data, {
          position: toast.POSITION.TOP_CENTER,
        });
        navigate("/ResourceNotFound", { state: { stateData: data } });
      });
  };

  const getSetItemValueByCategoryMakeDesc = () => {
    axios
      .get(itemValueByCategoryMakeDescUrl)
      .then((response) => {
        console.log(response.data);
        setValue(response.data);
      })
      .catch((error) => {
        const data = {
          heading: error.response.data,
          url: "/Employees/employee",
          content:
            "Item value for this item details is not present in the database. Go back to dashboard!",
        };
        toast.error(error.response.data, {
          position: toast.POSITION.TOP_CENTER,
        });
        navigate("/ResourceNotFound", { state: { stateData: data } });
      });
  };

  useEffect(() => {
    getSetItemCategories();
  }, []);

  useEffect(() => {
    getSetItemMakes();
  }, []);

  useEffect(() => {
    getSetItemDescs();
  }, []);

  const handleCategoryChange = (event) => {
    setCategory(event.target.value);
    itemMakeByCategoryUrl = itemMakeByCategoryUrl + event.target.value;
    getSetItemMakesByCategory();
  };

  const handleMakeChange = (event) => {
    setMake(event.target.value);
    itemDescByCategoryMakeUrl =
      itemDescByCategoryMakeUrl + category + "&" + event.target.value;
    console.log(itemDescByCategoryMakeUrl);
    getSetItemDescsByCategoryMake();
  };

  const handleDescChange = (event) => {
    setDesc(event.target.value);
    itemValueByCategoryMakeDescUrl =
      itemValueByCategoryMakeDescUrl +
      category +
      "&" +
      make +
      "&" +
      event.target.value;
    getSetItemValueByCategoryMakeDesc();
  };

  const handleApplyLoans = (event) => {
    event.preventDefault();
    console.log(desc);
    console.log(make);
    console.log(category);
    console.log(value);
    axios
      .post(applyLoanUrl, {
        employee_id: localStorage.getItem("sessionId"),
        item_description: desc,
        item_make: make,
        item_category: category,
        item_valuation: value,
      })
      .then((response) => {
        toast.success(response.data, { position: toast.POSITION.TOP_CENTER });
        navigate("/Employees/employee");
      })
      .catch((error) => {
        console.log("error");
        toast.error(error.response.data, {
          position: toast.POSITION.TOP_CENTER,
        });
      });
  };
  return (
    <div className="custom-gradient">
      <UserNavbar data={data} />
      <br />
      <h2 className="boxed-text bg-ligh-blue"> {"APPLY  FOR  A  LOAN"} </h2>
      <br />
      <form class="form-container gradient-custom">
        <label class="form-label">Employee ID</label>

        <TextField
          id="filled-read-only-input"
          label="Read Only"
          defaultValue={localStorage.getItem("sessionId")}
          value={localStorage.getItem("sessionId")}
          InputProps={{
            readOnly: true,
          }}
          variant="filled"
        />
        <br />
        <br />

        <label class="form-label">Item Category</label>

        <FormControl sx={{ m: 1, minWidth: 322 }}>
          <InputLabel id="demo-simple-small-label">Item Category</InputLabel>
          <Select
            labelId="demo-simple-small-label"
            id="demo-simple-small"
            label="ItemCategory"
            onChange={handleCategoryChange}
          >
            {itemCategories.map((s, index) => (
              <MenuItem key={s} value={s}>
                {s}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
        <br />
        <br />

        <label class="form-label">Item Make</label>

        <FormControl sx={{ m: 1, minWidth: 322 }}>
          <InputLabel id="demo-simple-small-label">Item Make</InputLabel>
          <Select
            labelId="demo-simple-small-label"
            id="demo-simple-small"
            label="ItemMake"
            onChange={handleMakeChange}
          >
            {itemMakes.map((s, index) => (
              <MenuItem key={s} value={s}>
                {s}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
        <br />
        <br />

        <label class="form-label">Item Description</label>

        <FormControl sx={{ m: 1, minWidth: 322 }}>
          <InputLabel id="demo-simple-small-label">Item Description</InputLabel>
          <Select
            labelId="demo-simple-small-label"
            id="demo-simple-small"
            label="ItemDescription"
            onChange={handleDescChange}
          >
            {itemDescs.map((s, index) => (
              <MenuItem key={s} value={s}>
                {s}
              </MenuItem>
            ))}
          </Select>
        </FormControl>

        <br />
        <br />

        <label class="form-label">Item Value</label>

        <FormControl sx={{ m: 1, minWidth: 322 }}>
          <TextField
            id="outlined-read-only-input"
            label="Item Value"
            defaultValue="null"
            value={value}
            InputProps={{
              readOnly: true,
            }}
          />
        </FormControl>
        <br />
        <br />

        <button class="buttonField" type="submit" onClick={handleApplyLoans}>
          Apply
        </button>
      </form>
    </div>
  );
}
