/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState, useContext } from "react";
import "./style.css";
import axios from "axios";
import { Context } from "../../context/context";
import UserNavbar from "./UserNavbar";
import { useNavigate } from "react-router-dom";

export default function EmployeeViewItems() {
  const [items, setItems] = useState([]);
  const { setSessionId } = useContext(Context);
  const data = ["ViewLoans", "ApplyLoans"];
  const navigate = useNavigate();
  const baseURL =
    "http://localhost:8080/fetchItemsById/" + localStorage.getItem("sessionId");

  const getSetItemData = () => {
    axios
      .get(baseURL)
      .then((response) => {
        console.log(response.data);
        setItems(response.data);
      })
      .catch((error) => {
        const data = {
          heading: error.response.data,
          url: "/Employees/employee",
          content:
            "You have not purchased any items, Go back to dashboard and Apply for Loans !",
        };
        navigate("/ResourceNotFound", { state: { stateData: data } });
      });
  };

  useEffect(() => {
    setSessionId(localStorage.getItem("sessionId"));
    getSetItemData();
  }, []);

  return (
    <div className="custom-gradient">
      <UserNavbar data={data} />
      <br />
      <h3 className="boxed-text bg-light-blue">
        {" "}
        View Items - {"   Employee Id :  "}
        {localStorage.getItem("sessionId")}
      </h3>
      <br />
      <div className="custom-table">
        <table className=" table-container gradient-custom">
          <thead>
            <tr>
              <th scope="col">ISSUE ID</th>
              <th>ITEM CATEGORY</th>
              <th>ITEM MAKE</th>
              <th>ITEM DESCRIPTION</th>
              <th>ITEM VALUATION</th>
            </tr>
          </thead>

          <tbody>
            {items.map((obj, index) => (
              <tr>
                <th scope="row">{obj.issue_id}</th>
                <td>{obj.item.item_category}</td>
                <td>{obj.item.item_make}</td>
                <td>{obj.item.item_description}</td>
                <td>{obj.item.item_valuation}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
