import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import "./style.css";
import MaleAvatarLogo from "../../assets/Male-Avatar.png";
import UserNavbar from "./UserNavbar";

const EmployeeDashboard = () => {
  const data = [];
  const [employee_id, setEmployee_id] = useState("");
  const [department, setDepartment] = useState("");
  const [designation, setDesignation] = useState("");

  const setItems = () => {
    setEmployee_id(localStorage.getItem("sessionId"));
    setDepartment(localStorage.getItem("department"));
    setDesignation(localStorage.getItem("designation"));
  };

  useEffect(() => {
    setItems();
  }, []);

  return (
    <div className="custom-gradient">
      <UserNavbar data={data} />
      <br></br>
      <div className="row mx-auto">
        <div className="col-md-1"></div>
        <div className="col-md-3 boxed-text">
          <h3>Employee Id: {employee_id}</h3>
        </div>
        <div className="col-md-3 boxed-text">
          <h3>Designation: {designation}</h3>
        </div>
        <div className="col-md-3 boxed-text">
          <h3>Department: {department}</h3>
        </div>
      </div>
      <br></br>
      <div className="row">
        <div className="col-md-2"></div>
        <div className="col-md-4">
          <img
            className="app-logo"
            src={MaleAvatarLogo}
            alt="Male-Avatar-Logo"
            height="100%"
            width="80%"
          ></img>
        </div>
        <div className="col-md-3 border link-container d-flex flex-column align-items-center">
          <Link className="styled-link" to="/Employees/employee/ViewLoans">
            {" "}
            View Loans{" "}
          </Link>
          <Link className="styled-link" to="/Employees/employee/ViewItems">
            {" "}
            View Items{" "}
          </Link>
          <Link className="styled-link" to="/Employees/employee/ApplyLoans">
            Apply Loans
          </Link>
        </div>
        <div className="col-md-3"></div>
      </div>
    </div>
  );
};

export default EmployeeDashboard;
