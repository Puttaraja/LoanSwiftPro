import React, { useState, useEffect } from "react";
import axios from "axios";
import "./style.css";
import { useNavigate } from "react-router-dom";
import UserNavbar from "./UserNavbar";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

export default function Login() {
  const baseURL = "http://localhost:8080/loginEmployee"; //insertion of url corresponding to eclipses url(backen
  var fetchURL = "http://localhost:8080/fetchEmployee/";
  const [employee_id, setEmployee_id] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();
  var isSuccess = "";

  const data = [];
  const eidHandler = (event) => {
    setEmployee_id(event.target.value);
  };

  const passwordHandler = (event) => {
    setPassword(event.target.value);
  };

  const fetchEmployee = () => {
    fetchURL = fetchURL + employee_id;
    axios.get(fetchURL).then((response) => {
      const e = response.data;
      localStorage.setItem("department", e.department);
      localStorage.setItem("designation", e.designation);
    });
  };

  const storeItems = () => {
    localStorage.setItem("sessionId", employee_id);
    localStorage.setItem("password", password);
  };

  const submitHandler = (event) => {
    event.preventDefault();
    axios
      .post(baseURL, {
        employee_id: employee_id,
        password: password,
      })
      .then((response) => {
        isSuccess = response.data;
        if (isSuccess === "Login Successful") {
          fetchEmployee();
          storeItems();
          toast.success(response.data, { position: toast.POSITION.TOP_CENTER });
          navigate("/Employees/employee");
        }
      })
      .catch((error) => {
        const data = {
          heading: error.response.data,
          url: "/userLogin",
          content: "Login with valid credentials, Go back to Login!",
        };
        toast.error(error.response.data, {
          position: toast.POSITION.TOP_CENTER,
        });
        navigate("/ResourceNotFound", { state: { stateData: data } });
      });
  };

  useEffect(() => {
    if (localStorage.getItem("sessionId")) navigate("/Employees/employee");
  });

  return (
    <div className="background-image-login">
      <UserNavbar data={data} />
      <div class="form-table">
        <br></br>
        <br />
        <h2>USER LOGIN</h2>
        <br />
        <form class="form-container gradient-custom" onSubmit={submitHandler}>
          <label for="employee_id" class="form-label">
            User ID
          </label>
          <input
            class="inputField"
            type="text"
            value={employee_id}
            onChange={eidHandler}
            required
          />{" "}
          <br></br>
          <label for="password" class="form-label">
            Password
          </label>
          <input
            class="inputField"
            type="password"
            value={password}
            onChange={passwordHandler}
            required
          />{" "}
          <br></br>
          <button class="buttonField" type="submit">
            {" "}
            Login{" "}
          </button>
        </form>
      </div>
    </div>
  );
}
