import React, { useState, useContext } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import "./style.css";
import Select from "@mui/material/Select";
import { Context } from "../../context/context.js";
import { InputLabel, MenuItem } from "@mui/material";
import FormControl from "@mui/material/FormControl";
import UserNavbar from "./UserNavbar";
import { toast } from "react-toastify";

export default function Register() {
  const baseURL = "http://localhost:8080/saveEmployee"; //insertion of url corresponding to eclipses url(backend)
  const [employee_id, setEmployee_id] = useState("");
  const [employee_name, setEmployee_name] = useState("");
  const [password, setPassword] = useState("");
  const [gender, setGender] = useState("");
  const [date_of_join, setDate_of_join] = useState("");
  const [date_of_birth, setDate_of_birth] = useState("");
  const [department, setDepartment] = useState("");
  const [designation, setDesignation] = useState("");
  const [popUp, setPopUp] = useState(false);
  const [popUp1, setPopUp1] = useState(false);
  const [error, setError] = useState("");
  const data = [];
  const navigate = useNavigate();
  const eidHandler = (event) => {
    setEmployee_id(event.target.value);
  };

  const enameHandler = (event) => {
    setEmployee_name(event.target.value);
  };

  const passwordHandler = (event) => {
    setPassword(event.target.value);
  };

  const genderHandler = (event) => {
    setGender(event.target.value);
  };

  const dojHandler = (event) => {
    const selectedDate = new Date(event.target.value);
    let currentDate = new Date(date_of_birth);
    currentDate.setFullYear(currentDate.getFullYear() + 15);

    if (selectedDate < currentDate) {
      setError("Date of Joining must be at least 15 years greater than DOB");
    } else {
      setError("");
      setDate_of_join(event.target.value);
    }
  };

  const dobHandler = (event) => {
    setDate_of_birth(event.target.value);
  };

  const deptHandler = (event) => {
    setDepartment(event.target.value);
  };

  const designationHandler = (event) => {
    setDesignation(event.target.value);
  };

  const ErrorHandler = () => {
    setEmployee_id("");
    setEmployee_name("");
    setPassword("");
    setGender("");
    setDate_of_birth("");
    setDate_of_join("");
    setDesignation("");
    setDepartment("");
  };

  const storeItems = () => {
    localStorage.setItem("sessionId", employee_id);
    localStorage.setItem("password", password);
    localStorage.setItem("department", department);
    //console.log(department);
    localStorage.setItem("designation", designation);
  };

  const submitHandler = (event) => {
    event.preventDefault();
    // validate();
    axios
      .post(baseURL, {
        employee_id: employee_id,
        employee_name: employee_name,
        password: password,
        gender: gender,
        date_of_join: date_of_join,
        date_of_birth: date_of_birth,
        department: department,
        designation: designation,
      })
      .then((response) => {
        if (response.data === "User Registered Successfully") {
          ErrorHandler();
          storeItems();
          // setSessionId(employee_id);
          // localStorage.setItem("sessionId", employee_id);
          // localStorage.setItem("password", password);
          toast.success(response.data, { position: toast.POSITION.TOP_CENTER });
          navigate("/Employees/employee");
        }
      })
      .catch((error) => {
        const data = {
          heading: error.response.data,
          url: "/userReister",
          content:
            "You are registering with existing user Id, Go back and register with different Id!",
        };
        toast.error(error.response.data, {
          position: toast.POSITION.TOP_CENTER,
        });
        navigate("/ResourceNotFound", { state: { stateData: data } });
      });
  };

  const PassPopupTrue = (event) => {
    setPopUp(true);
  };

  const PassPopupFalse = () => {
    setPopUp(false);
  };

  const PassPopupTrue1 = (event) => {
    setPopUp1(true);
  };

  const PassPopupFalse1 = () => {
    setPopUp1(false);
  };

  return (
    <div className="background-image-register">
      <UserNavbar data={data} />
      <br></br>
      <h2>USER REGISTER</h2>
      <br></br>
      <form class="form-container gradient-custom" onSubmit={submitHandler}>
        <label for="employee_id" class="form-label">
          Employee ID
        </label>
        <input
          class="inputField"
          type="text"
          value={employee_id}
          onChange={eidHandler}
          onFocus={PassPopupTrue1}
          onBlur={PassPopupFalse1}
          required
          pattern="^[A-Z0-9]{8}$"
        />{" "}
        {popUp1 && (
          <div className="PopUp">
            <ul class="requirement-list">
              <li>
                <i class="fa-solid fa-circle"></i>
                <span>Id must be of 8 characters length</span>
              </li>
              <li>
                <i class="fa-solid fa-circle"></i>
                <span>Only Capital Letters and Numbers are allowed</span>
              </li>
            </ul>
          </div>
        )}
        <br></br>
        <label for="employee_name" class="form-label">
          Employee Name
        </label>
        <input
          class="inputField"
          type="text"
          value={employee_name}
          onChange={enameHandler}
          required
          minLength={3}
          maxlength={50}
        />{" "}
        <br></br>
        <div>
          <label for="password" className="form-label">
            Password
          </label>
          <input
            class="inputField"
            type="password"
            value={password}
            onChange={passwordHandler}
            onFocus={PassPopupTrue}
            onBlur={PassPopupFalse}
            required
            pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9]).{8,}"
          />{" "}
          {popUp && (
            <div className="PopUp">
              <p>Password must contain</p>
              <ul class="requirement-list">
                <li>
                  <i class="fa-solid fa-circle"></i>
                  <span>At least 8 characters length</span>
                </li>
                <li>
                  <i class="fa-solid fa-circle"></i>
                  <span>At least 1 number (0...9)</span>
                </li>
                <li>
                  <i class="fa-solid fa-circle"></i>
                  <span>At least 1 lowercase letter (a...z)</span>
                </li>
                <li>
                  <i class="fa-solid fa-circle"></i>
                  <span>At least 1 uppercase letter (A...Z)</span>
                </li>
                <li>
                  <i class="fa-solid fa-circle"></i>
                  <span>At least 1 special symbol</span>
                </li>
              </ul>
            </div>
          )}
        </div>
        <label for="gender" class="form-label">
          Gender
        </label>
        <FormControl sx={{ m: 1, minWidth: 322 }} size="small">
          <InputLabel id="demo-simple-small-label">M/F</InputLabel>
          <Select
            labelId="demo-simple-small-label"
            id="demo-simple-small"
            value={gender}
            label="Gender"
            onChange={genderHandler}
          >
            <MenuItem value={"M"}>Male</MenuItem>
            <MenuItem value={"F"}>Female</MenuItem>
          </Select>
        </FormControl>
        <br></br>
        <label for="date_of_birth" class="form-label">
          Date of Birth{" "}
        </label>
        <input
          class="inputField"
          type="date"
          value={date_of_birth}
          onChange={dobHandler}
          required
        />{" "}
        <br></br>
        <label for="date_of_join" className="form-label">
          Date of Join
        </label>
        <input
          className="inputField"
          type="date"
          value={date_of_join}
          onChange={dojHandler}
          required
        />
        {error && <div className="error">{error}</div>}
        <br></br>
        <label for="department" class="form-label">
          Department:
        </label>
        <input
          class="inputField"
          type="text"
          value={department}
          onChange={deptHandler}
          required
        />{" "}
        <br></br>
        <label for="designation" class="form-label">
          Designation
        </label>
        <input
          class="inputField"
          type="text"
          value={designation}
          onChange={designationHandler}
          required
        />{" "}
        <br></br>
        <button class="buttonField" type="submit">
          {" "}
          Register{" "}
        </button>
        <button class="buttonField" type="reset" onClick={() => ErrorHandler}>
          {" "}
          Reset{" "}
        </button>
      </form>
    </div>
  );
}
