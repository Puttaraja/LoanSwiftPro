/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState, useContext } from "react";
import "./style.css";
import axios from "axios";
import { Context } from "../../context/context";
import UserNavbar from "./UserNavbar";
import { useNavigate } from "react-router-dom";
import { styled } from "@mui/material/styles";
import TableCell, { tableCellClasses } from "@mui/material/TableCell";
import TableRow from "@mui/material/TableRow";

export default function EmployeeViewLoans() {
  const [loans, setLoans] = useState([]);
  const { setSessionId } = useContext(Context);
  const data = ["ViewItems", "ApplyLoans"];
  const navigate = useNavigate();
  const baseURL =
    "http://localhost:8080/fetchLoansById/" + localStorage.getItem("sessionId");
  const getSetILoanData = () => {
    axios
      .get(baseURL)
      .then((response) => {
        setLoans(response.data);
      })
      .catch((error) => {
        const data = {
          heading: error.response.data,
          url: "/Employees/employee",
          content:
            "You have not purchased any loans, Go back to dashboard and Apply for Loans !",
        };
        navigate("/ResourceNotFound", { state: { stateData: data } });
      });
  };

  useEffect(() => {
    setSessionId(localStorage.getItem("sessionId"));
    getSetILoanData();
  }, []);

  return (
    <div className="custom-gradient">
      <UserNavbar data={data} />
      <br />
      <h3 className="boxed-text bg-light-blue">
        {" "}
        Loan Cards Availed - {"   Employee Id :  "}
        {localStorage.getItem("sessionId")}
      </h3>
      <br />
      <div className="custom-table">
        <table className=" table-container gradient-custom">
          <thead>
            <tr>
              <th scope="col">LOAN ID</th>
              <th>LOAN TYPE</th>
              <th>DURATION (in years)</th>
              <th>ISSUE DATE</th>
            </tr>
          </thead>
          <tbody>
            {loans.map((obj, index) => (
              <tr>
                <th scope="row">{obj.loans.loan_id}</th>
                <td key={index}>{obj.loans.loan_type}</td>
                <td>{obj.loans.duration_in_years}</td>
                <td>{obj.issue_date}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
