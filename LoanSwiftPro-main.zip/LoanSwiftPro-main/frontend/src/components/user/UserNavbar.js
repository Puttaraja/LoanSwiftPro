import React from "react";
import { Link } from "react-router-dom";
import Applogo from "../../assets/logo.png";
import LogoutUser from "./logoutUser.js";
export default function UserNavbar(prop) {
  return (
    <div className="custom-navbar">
      <div class="justify-content-start">
        <nav class="navbar navbar-expand-lg navbar-light bg-light gradient-custom">
          <div className="">
            <Link class="navbar-brand" to={"/Employees/employee"}>
              <img src={Applogo} width="50" height="50" alt="" />
            </Link>
          </div>
          <Link class="navbar-brand text-center" to={"/Employees/employee"}>
            <h1>LoanSwiftPro</h1>
          </Link>
          <button
            class="navbar-toggler"
            type="button"
            data-toggle="collapse"
            data-target="#navbarNavDropdown"
            aria-controls="navbarNavDropdown"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span class="navbar-toggler-icon"></span>
          </button>

          <div
            class="collapse navbar-collapse justify-content-end"
            id="navbarNavDropdown"
          >
            <ul class="navbar-nav">
              {prop.data.map((element) => (
                <li>
                  <Link
                    class="nav-link h4 text-dark"
                    to={"/Employees/employee/" + element}
                  >
                    {element}{" "}
                  </Link>
                </li>
              ))}
              <li class="nav-item">
                <LogoutUser />
              </li>
            </ul>
          </div>
        </nav>
      </div>
    </div>
  );
}
