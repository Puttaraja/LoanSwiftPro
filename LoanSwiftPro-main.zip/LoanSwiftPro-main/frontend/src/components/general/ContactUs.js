import React from "react";
import MentorLogo from "../../assets/Female-Avatar.png";
import FemaleLogo1 from "../../assets/female-avatar-1.png";
import MaleLogo1 from "../../assets/male-avatar-1.png";
import MaleLogo2 from "../../assets/male-avatar-2.png";
import MaleLogo3 from "../../assets/male-avatar-3.png";
import MaleLogo4 from "../../assets/male-avatar-4.png";
import AppLogo from "../../assets/lsp-logo-transparent.png";
import "./style.css";

function ContactUs() {
  const contacts = [
    {
      id: 1,
      name: "Parvahy M (Lead)",
      email: "Parvathy.M@wellsfargo.com",
      mobile: "987-654-3210",
      image: MentorLogo,
    },
    {
      id: 2,
      name: "Akash Bose",
      email: "Akash.Bose@wellsfargo.com",
      mobile: "987-654-3211",
      image: MaleLogo1,
    },
    {
      id: 3,
      name: "Anjali Kumari",
      email: "Anjali.Kumari@wellsfargo.com",
      mobile: "987-654-3212",
      image: FemaleLogo1,
    },
    {
      id: 4,
      name: "Anshuman Singh",
      email: "Anshuman.Singh@wellsfargo.com",
      mobile: "987-654-3213",
      image: MaleLogo2,
    },
    {
      id: 5,
      name: "Bhagya Rana",
      email: "Bhagya.Rana@wellsfargo.com",
      mobile: "987-654-3214",
      image: MaleLogo3,
    },
    {
      id: 6,
      name: "Puttaraja H",
      email: "Puttaraja.H@wellsfargo.com",
      mobile: "987-654-3215",
      image: MaleLogo4,
    },
  ];

  return (
    <div className="custom-gradient">
      <div>
        <nav class="navbar navbar-expand-lg navbar-light bg-light gradient-custom">
          <a class="navbar-brand" href="/">
            <img src={AppLogo} width="60" height="50" alt="App Logo" />
          </a>
          <a class="navbar-brand " href="/">
            <h4>LoanSwiftPro</h4>
          </a>
          <div class=" mx-auto">
            <h1>
              <u>Contact Us</u>
            </h1>
          </div>

          <a class="navbar-brand " href="/">
            <div className="">
              <h6>Home</h6>
            </div>
          </a>

          <a class="navbar-brand " href="/aboutUs">
            <div className="">
              <h6>About Us</h6>
            </div>
          </a>
        </nav>
      </div>

      <div className="container mt-5 ">
        <div className="row justify-content-center">
          {/* Contact 1 */}
          <div className="col-md-4 mb-4 mx-auto">
            <div className="card">
              <img
                src={contacts[0].image}
                className="card-img-top rounded-circle"
                // height={250}
                alt={contacts[0].name}
              />
              <div className="card-body">
                <h5 className="card-title">{contacts[0].name}</h5>
                <p className="card-text">
                  <strong>Email:</strong> {contacts[0].email}
                  <br />
                  <strong>Mobile:</strong> {contacts[0].mobile}
                </p>
              </div>
            </div>
          </div>
        </div>
        <div className="row">
          {/* Contact 2 */}
          <div className="col-md-4 mb-4">
            <div className="card">
              <img
                src={contacts[1].image}
                className="card-img-top"
                alt={contacts[1].name}
              />
              <div className="card-body">
                <h5 className="card-title">{contacts[1].name}</h5>
                <p className="card-text">
                  <strong>Email:</strong> {contacts[1].email}
                  <br />
                  <strong>Mobile:</strong> {contacts[1].mobile}
                </p>
              </div>
            </div>
          </div>

          {/* Contact 3 */}
          <div className="col-md-4 mb-4">
            <div className="card">
              <img
                src={contacts[2].image}
                className="card-img-top"
                alt={contacts[2].name}
              />
              <div className="card-body">
                <h5 className="card-title">{contacts[2].name}</h5>
                <p className="card-text">
                  <strong>Email:</strong> {contacts[2].email}
                  <br />
                  <strong>Mobile:</strong> {contacts[2].mobile}
                </p>
              </div>
            </div>
          </div>

          {/* Contact 4 */}
          <div className="col-md-4 mb-4">
            <div className="card">
              <img
                src={contacts[3].image}
                className="card-img-top"
                alt={contacts[3].name}
              />
              <div className="card-body">
                <h5 className="card-title">{contacts[3].name}</h5>
                <p className="card-text">
                  <strong>Email:</strong> {contacts[3].email}
                  <br />
                  <strong>Mobile:</strong> {contacts[3].mobile}
                </p>
              </div>
            </div>
          </div>
        </div>
        {/* Contact 5 */}
        <div className="row">
          <div className="col-md-2" mb-2></div>
          <div className="col-md-4 mb-4">
            <div className="card">
              <img
                src={contacts[4].image}
                className="card-img-top"
                alt={contacts[4].name}
              />
              <div className="card-body">
                <h5 className="card-title">{contacts[4].name}</h5>
                <p className="card-text">
                  <strong>Email:</strong> {contacts[4].email}
                  <br />
                  <strong>Mobile:</strong> {contacts[4].mobile}
                </p>
              </div>
            </div>
          </div>

          {/* Contact 6 */}
          <div className="col-md-4 mb-4">
            <div className="card">
              <img
                src={contacts[5].image}
                className="card-img-top"
                alt={contacts[5].name}
              />
              <div className="card-body">
                <h5 className="card-title">{contacts[5].name}</h5>
                <p className="card-text">
                  <strong>Email:</strong> {contacts[5].email}
                  <br />
                  <strong>Mobile:</strong> {contacts[5].mobile}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ContactUs;
