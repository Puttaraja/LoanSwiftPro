/* eslint-disable jsx-a11y/anchor-is-valid */
import React from "react";
import Applogo from "../../assets/logo.png";
import "../user/style.css";
import { useNavigate } from "react-router-dom";
export default function PageNotFoundNavbar() {
  const navigate = useNavigate();
  return (
    <div className="custom-navbar">
      <nav class="navbar navbar-expand-lg navbar-light ">
        <div className="border p-1 mb-1 ">
          <a class="navbar-brand">
            <img src={Applogo} width="50" height="50" alt="" />
          </a>
        </div>
        <a class="navbar-brand text-center">
          <h1>LoanSwiftPro</h1>
        </a>
        <div class="collapse navbar-collapse justify-content-end">
          <button class="login_btnn" type="button" onClick={() => navigate(-1)}>
            Go Back{" "}
          </button>
        </div>
      </nav>
    </div>
  );
}
