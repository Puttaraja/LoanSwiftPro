import React from "react";
// import { useContext } from "react";
import { Routes, Route, BrowserRouter } from "react-router-dom";
import Home2 from "./home2.js";
import Login from "../user/loginUser.js";
import UserRegister from "../user/UserRegister.js";
import EmployeeViewLoans from "../user/EmployeeViewLoans.js";
import EmployeeViewItems from "../user/EmployeeViewItems.js";
import EmployeeDashboard from "../user/employeeDashboard.js";
import ApplyLoans from "../user/applyLoans.js";
import AdminRegister from "../admin/AdminRegister.js";
import AdminDashboard from "../admin/AdminDashboard.js";
import AddCustomer from "../admin/AddCustomer.js";
import CustomerDataManagement from "../admin/CustomerDataManagement.js";
import ViewCustomers from "../admin/ViewCustomers.js";
import EditCustomers from "../admin/EditCustomers.js";
import AdminLogin from "../admin/AdminLogin.js";
import ItemDataManagement from "../admin/ItemDataManagement.js";
import AddItem from "../admin/AddItem.js";
import ViewItems from "../admin/ViewItems.js";
import EditItems from "../admin/EditItems.js";
import LoanCardManagement from "../admin/LoanCardManagement.js";
import AddLoan from "../admin/AddLoan.js";
import ViewLoans from "../admin/ViewLoans.js";
import EditLoans from "../admin/EditLoans.js";
import Navbar from "./homeNavbar.js";
import PageNotFound from "./PageNotFound.js";
import ContactUs from "./ContactUs.js";
import AboutUs from "./AboutUs.js";
import ResourceNotFound from "./ResourceNotFound.js";

export default function GeneralRouter() {
  return (
    <div>
      {" "}
      <BrowserRouter>
        <Routes>
          <Route exact path="*" element={<PageNotFound />} />
          <Route exact path="/" element={<Home2 />} />
          <Route exact path="/contactUs" element={<ContactUs />} />
          <Route exact path="/aboutUs" element={<AboutUs />} />
          <Route exact path="/userLogin" element={<Login />} />
          <Route exact path="/userRegister" element={<UserRegister />} />
          <Route exact path="/adminRegister" element={<AdminRegister />} />
          <Route exact path="/Admin" element={<AdminDashboard />} />
          <Route exact path="/adminLogin" element={<AdminLogin />} />
          <Route exact path="/navbar" element={<Navbar />}></Route>
          <Route
            exact
            path="/Admin/CustomerDataManagement"
            element={<CustomerDataManagement />}
          />
          <Route
            exact
            path="/Admin/CustomerDataManagement/AddCustomer"
            element={<AddCustomer />}
          />
          <Route
            exact
            path="/Admin/CustomerDataManagement/ViewCustomers"
            element={<ViewCustomers />}
          />
          <Route
            exact
            path="/Admin/CustomerDataManagement/ViewCustomers/Edit/:id"
            element={<EditCustomers />}
          />

          <Route
            exact
            path="/Admin/ItemDataManagement"
            element={<ItemDataManagement />}
          />
          <Route
            exact
            path="/Admin/ItemDataManagement/AddItem"
            element={<AddItem />}
          />
          <Route
            exact
            path="/Admin/ItemDataManagement/ViewItems"
            element={<ViewItems />}
          />
          <Route
            exact
            path="/Admin/ItemDataManagement/ViewItems/Edit/:id"
            element={<EditItems />}
          />

          <Route
            exact
            path="/Admin/LoanCardManagement"
            element={<LoanCardManagement />}
          />
          <Route
            exact
            path="/Admin/LoanCardManagement/AddLoan"
            element={<AddLoan />}
          />
          <Route
            exact
            path="/Admin/LoanCardManagement/ViewLoans"
            element={<ViewLoans />}
          />
          <Route
            exact
            path="/Admin/LoanCardManagement/ViewLoans/Edit/:id"
            element={<EditLoans />}
          />

          <Route exact path="/applyLoans" element={<ApplyLoans />} />
          <Route
            exact
            path="/Employees/employee"
            element={<EmployeeDashboard />}
          />
          <Route
            exact
            path="/Employees/employee/ViewLoans"
            element={<EmployeeViewLoans />}
          />
          <Route
            exact
            path="/Employees/employee/ViewItems"
            element={<EmployeeViewItems />}
          />
          <Route
            exact
            path="/Employees/employee/ApplyLoans"
            element={<ApplyLoans />}
          />
          <Route
            exact
            path="/ResourceNotFound"
            element={<ResourceNotFound />}
          />
        </Routes>
      </BrowserRouter>
    </div>
  );
}
