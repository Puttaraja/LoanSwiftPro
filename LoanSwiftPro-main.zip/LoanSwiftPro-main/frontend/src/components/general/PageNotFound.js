import React from "react";
import Logo404 from "../../assets/Logo404.svg";
import PageNotFoundNavbar from "./PageNotFoundNavbar";

export default function PageNotFound() {
  return (
    <div>
      <PageNotFoundNavbar />
      <img
        src={Logo404}
        alt="Page Not Found"
        style={{ height: 550, width: 550 }}
      />
    </div>
  );
}
