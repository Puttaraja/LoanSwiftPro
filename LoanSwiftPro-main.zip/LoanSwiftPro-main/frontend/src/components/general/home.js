import Homenavbar from "./homeNavbar";
import "./style.css";
export default function Home() {
  return (
    <div className="home">
      <Homenavbar />
      <br></br>
      <div className="container">
        <div className="row">
          <div className="col-md-8"></div>
        </div>
      </div>
    </div>
  );
}
