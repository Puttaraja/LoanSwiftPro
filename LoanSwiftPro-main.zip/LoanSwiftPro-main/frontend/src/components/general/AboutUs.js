import React from "react";
import AppLogo from "../../assets/lsp-logo-transparent.png";
import "./style.css";
import { Box } from "@mui/material";
import ListItem from "@mui/material/ListItem";
import ListItemText from "@mui/material/ListItemText";
import Typography from "@mui/material/Typography";
import Grid from "@mui/material/Grid";

function AboutUs() {
  return (
    <div>
      <div>
        {/*~~~~~~~~~~~~~~Custom Navbar Started~~~~~~~~~~~~~~*/}
        <div className="custom-navbar  gradient-custom">
          <nav class="navbar navbar-expand-lg navbar-light ">
            <a class="navbar-brand" href="/">
              <img src={AppLogo} width="60" height="50" alt="" />
            </a>
            <a class="navbar-brand " href="/">
              <h4>LoanSwiftPro</h4>
            </a>

            <div class="mx-auto">
              <h1>
                <u>About Us</u>
              </h1>
            </div>

            <a class="navbar-brand" href="/">
              <div className="">
                <h6>Home</h6>
              </div>
            </a>

            <a class="navbar-brand " href="/contactUs">
              <div className="">
                <h6>Contact Us</h6>
              </div>
            </a>
          </nav>
        </div>
      </div>
      {/*~~~~~~~~~~~~~~Custom Navbar Ended~~~~~~~~~~~~~~*/}

      <div className="custom-gradient">
        <br></br>
        <Box
          sx={{
            flex: "1",
            // display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <Typography
            variant="body2"
            sx={{
              fontSize: "22px",
              fontWeight: "500",
              color: "#5A6473",
              textAlign: "center",
            }}
          >
            Introducing Loan Swift Pro, your passport to financial ease and
            speed! 🚀
          </Typography>

          <Typography
            variant="h3"
            sx={{
              fontSize: "38px",
              fontWeight: "bold",
              color: "#000339",
              my: 3,
            }}
          >
            Why LoanSwift Pro?
          </Typography>

          <Box sx={{ width: "100%" }}>
            <Grid
              container
              rowSpacing={2}
              columnSpacing={{ xs: 2, sm: 4, md: 6 }}
            >
              <Grid item xs={6}>
                <ListItem alignItems="flex-start">
                  <ListItemText
                    primaryTypographyProps={{ fontSize: "24px" }}
                    primary="🌟 Swift Solutions, Swift Success"
                    secondaryTypographyProps={{ fontSize: "18px" }}
                    secondary={
                      <React.Fragment>
                        {
                          "Say goodbye to the waiting game! Loan Swift Pro connects you with the perfect loan in record time, ensuring your dreams are never on hold."
                        }
                      </React.Fragment>
                    }
                  />
                </ListItem>
              </Grid>

              <Grid item xs={6}>
                <ListItem alignItems="flex-start">
                  <ListItemText
                    primaryTypographyProps={{ fontSize: "24px" }}
                    primary="💡 Your Financial GPS"
                    secondaryTypographyProps={{ fontSize: "18px" }}
                    secondary={
                      <React.Fragment>
                        {
                          "Navigate the loan landscape effortlessly with our user-friendly app. No more tedious forms or jargon-filled contracts - we simplify the process so you can focus on what matters most."
                        }
                      </React.Fragment>
                    }
                  />
                </ListItem>
              </Grid>
              <Grid item xs={6}>
                <ListItem alignItems="flex-start">
                  <ListItemText
                    primaryTypographyProps={{ fontSize: "24px" }}
                    primary="💰 Loans Made Simple"
                    secondaryTypographyProps={{ fontSize: "18px" }}
                    secondary={
                      <React.Fragment>
                        {
                          "Need cash for your next adventure, home improvements, or unexpected expenses? Loan Swift Pro has you covered with a hassle-free approach to lending."
                        }
                      </React.Fragment>
                    }
                  />
                </ListItem>
              </Grid>
              <Grid item xs={6}>
                <ListItem alignItems="flex-start">
                  <ListItemText
                    primaryTypographyProps={{ fontSize: "24px" }}
                    primary="✨ Trust and Security"
                    secondaryTypographyProps={{ fontSize: "18px" }}
                    secondary={
                      <React.Fragment>
                        {
                          "Your peace of mind is our priority. We've fortified Loan Swift Pro with the latest security measures, so your personal and financial information is always safe."
                        }
                      </React.Fragment>
                    }
                  />
                </ListItem>
              </Grid>
              <Grid item xs={6}>
                <ListItem alignItems="flex-start">
                  <ListItemText
                    primaryTypographyProps={{ fontSize: "24px" }}
                    primary="🎯 Your Goals, Our Mission"
                    secondaryTypographyProps={{ fontSize: "18px" }}
                    secondary={
                      <React.Fragment>
                        {
                          "Whether it's a new car, debt consolidation, or your dream vacation, Loan Swift Pro is here to make your aspirations a reality."
                        }
                      </React.Fragment>
                    }
                  />
                </ListItem>
              </Grid>
              <Grid item xs={6}>
                <ListItem alignItems="flex-start">
                  <ListItemText
                    primaryTypographyProps={{ fontSize: "24px" }}
                    primary="📈 Unlock Your Financial Potential:"
                    secondaryTypographyProps={{ fontSize: "18px" }}
                    secondary={
                      <React.Fragment>
                        {
                          "We're not just a lending platform; we're your partner in financial growth. Loan Swift Pro empowers you to seize opportunities and secure a brighter future."
                        }
                      </React.Fragment>
                    }
                  />
                </ListItem>
              </Grid>
            </Grid>
          </Box>
        </Box>
      </div>
    </div>
  );
}

export default AboutUs;
