import React from "react";
import { useNavigate, useLocation } from "react-router-dom";

const ResourceNotFound = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const data = location.state.stateData;

  const handleGoBack = () => {
    if (data && data.url) {
      navigate(data.url);
    } else {
      navigate("/contactUs");
    }
  };

  if (!data) {
    return (
      <div>
        <h1>Data not available.</h1>
      </div>
    );
  }

  return (
    <div className="resource-not-found">
      <br />
      <div className="content">
        <br />
        <h1 className="boxed-text">{data.heading}</h1>
        <br />
        <div className="col-md-4 mx-auto border mb-3 p-3 gradient-custom">
          <p>{data.content}</p>
        </div>
        <br />
        <button className="buttonField" onClick={handleGoBack}>
          Go Back
        </button>
      </div>
    </div>
  );
};

export default ResourceNotFound;
