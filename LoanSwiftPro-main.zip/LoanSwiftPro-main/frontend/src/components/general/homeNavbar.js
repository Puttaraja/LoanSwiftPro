import React from "react";
import { Link } from "react-router-dom";
import Applogo from "../../assets/lsp-logo-transparent.png";
import "./style.css";

export default function navbar() {
  return (
    <div className="custom-navbar">
      <nav class="navbar navbar-expand-lg navbar-light ">
        <div className="p-1 mb-1 ">
          <a class="navbar-brand" href="/">
            <img src={Applogo} width="80" height="70" alt="" />
          </a>
        </div>
        <a class="navbar-brand home-header" href="/">
          <h1>LoanSwiftPro</h1>
        </a>

        <button
          class="navbar-toggler"
          type="button"
          data-toggle="collapse"
          data-target="#navbarNavDropdown"
          aria-controls="navbarNavDropdown"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbarNavDropdown">
          {/* <div class="collapse navbar-collapse justify-content-end"> */}
            <ul class="navbar-nav">
              <div className="">
                <li class="nav-item active">
                  <a class="nav-link h4 text-dark" href="/aboutUs">
                    About Us
                  </a>
                  {/* <span class="sr-only">(current)</span> */}
                </li>
              </div>
              <div className="">
                <li class="nav-item ">
                  <a class="nav-link h4 text-dark" href="/contactUs">
                    Contact Us{" "}
                  </a>
                </li>
              </div>
              <div className="">
                <li class="nav-item dropdown">
                  <a
                    class="nav-link dropdown-toggle h4 text-dark"
                    href="/"
                    id="navbarDropdownMenuLink"
                    data-toggle="dropdown"
                    aria-haspopup="true"
                    aria-expanded="false"
                  >
                    Register
                  </a>
                  <div
                    class="dropdown-menu"
                    aria-labelledby="navbarDropdownMenuLink"
                  >
                    <Link class="dropdown-item" to={"/adminRegister"}>
                      Admin
                    </Link>
                    <Link class="dropdown-item" to={"/userRegister"}>
                      User
                    </Link>
                  </div>
                </li>
              </div>
              <div className="">
                <li class="nav-item dropdown ">
                  <a
                    class="nav-link dropdown-toggle h4 text-dark "
                    href="/"
                    id="navbarDropdownMenuLink"
                    data-toggle="dropdown"
                    aria-haspopup="true"
                    aria-expanded="false"
                  >
                    Login
                  </a>
                  <div
                    class="dropdown-menu"
                    aria-labelledby="navbarDropdownMenuLink"
                  >
                    <Link class="dropdown-item" to={"/adminLogin"}>
                      Admin
                    </Link>
                    <Link class="dropdown-item" to={"/userLogin"}>
                      User
                    </Link>
                  </div>
                </li>
              </div>
            </ul>
          </div>
        {/* </div> */}
      </nav>
    </div>
  );
}
