package com.training.loan_app.service_implementation;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.training.loan_app.exception.CustomException;
import com.training.loan_app.model.LoanCardMaster;
import com.training.loan_app.repository.LoanRepository;
import com.training.loan_app.service.LoanService;

@Service
public class LoanServiceImplementation implements LoanService {
	 
		@Autowired
		LoanRepository loanRepo;
				
		public String save_Loan(LoanCardMaster lcm)  throws CustomException{
			String result = "";
			Optional<LoanCardMaster> optional = loanRepo.findById(lcm.getLoan_id());
			if(optional.isEmpty()) {
				loanRepo.save(lcm);
				result = "Loan added successfully";
			}
			else {
				throw new CustomException( "Loan Already Exist", HttpStatus.BAD_REQUEST);
			
			}
			return result;
		}
		
		public List<LoanCardMaster> fetch_Loans() throws CustomException{
			List<LoanCardMaster> empl  = loanRepo.findAll();
			if(empl.size()==0) throw new CustomException("No Loans Available", HttpStatus.NOT_FOUND);
			else return empl;
		}
		
		public LoanCardMaster fetch_Loan(String lid) throws CustomException{
			
			Optional<LoanCardMaster> loan = loanRepo.findById(lid);
			if(loan.isEmpty())
			{
				throw new CustomException("Loan Not Found" ,HttpStatus.NOT_FOUND);
			}
			else
				return loan.get();
		}
		
		public String update_Loan(String id, LoanCardMaster loan) throws CustomException{
			String res = "";
			Optional<LoanCardMaster> opt = loanRepo.findById(id);
			LoanCardMaster lcm;
			if(opt.isPresent()) {
				lcm = opt.get();
				lcm.setLoan_type(loan.getLoan_type());
				lcm.setDuration_in_years(loan.getDuration_in_years());
				loanRepo.save(lcm);
				res =  "Loan Updated Successfully";
			}
			else throw new CustomException( "Loan Not found", HttpStatus.NOT_FOUND);
			return res;
		}
		
		public String delete_Loan(String id) throws CustomException{
			String res = "";
			Optional<LoanCardMaster> opt = loanRepo.findById(id);
			LoanCardMaster lcm;
			if(opt.isPresent()) {
				lcm = opt.get();
				loanRepo.delete(lcm);
				res =  "Loan Deleted Successfully";
			}
			else throw new CustomException( "Loan Not found", HttpStatus.NOT_FOUND);
			return res;
		}
		
}
