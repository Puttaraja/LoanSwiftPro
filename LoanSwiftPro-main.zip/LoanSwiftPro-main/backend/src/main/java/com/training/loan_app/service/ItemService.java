package com.training.loan_app.service;

import java.util.List;

import com.training.loan_app.model.ItemMaster;

public interface ItemService {
	
	public String save_Item(ItemMaster i);
	
	public ItemMaster fetch_Item(String itemId);
	
	public List<ItemMaster> fetch_Items();
	
	public List<String> fetch_Item_Make();
	
	public List<String> fetch_Item_Category();
	
	public List<String> fetch_Item_Descs();
	
	public List<String> fetch_Item_Make_By_Category(String item_category);
	
	public List<String> fetch_Item_Category_By_Make(String item_make);
	
	public List<String> fetch_Item_Descs_By_Category_Make(String category,String make);
	
	public String fetch_Item_Value_By_Category_Make_Desc(String category, String make, String desc);
	
	public String update_Item(String id, ItemMaster item);
	
	public String delete_Item(String id);
	
}
