package com.training.loan_app.service;


import com.training.loan_app.model.AdminMaster;
import com.training.loan_app.model.LoginMaster;

public interface AdminService {
	
 	public String save_Admin(AdminMaster e) ;
 	
	public String login_Admin(LoginMaster l);
	
	public AdminMaster fetch_ById(String aid);
		
}
