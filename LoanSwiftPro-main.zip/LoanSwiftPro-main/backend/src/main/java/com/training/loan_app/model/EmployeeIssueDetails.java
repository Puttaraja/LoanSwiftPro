package com.training.loan_app.model;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class EmployeeIssueDetails {
	
	    @Id
	    @Column(nullable=false)
	    private String issue_id;
	    @JsonBackReference
	    @ManyToOne
	    private EmployeeMaster employee;
	    @JsonBackReference
	    @ManyToOne
	    private ItemMaster item;
	    @JsonFormat(pattern="yyyy-MM-dd")
	    private LocalDate issue_date;
	    @JsonFormat(pattern="yyyy-MM-dd")
	    private LocalDate  return_Date;
	   
		public String getIssue_id() {
			return issue_id;
		}
		public void setIssue_id(String issue_id) {
			this.issue_id = issue_id;
		}
	
		public LocalDate getIssue_date() {
			return issue_date;
		}
		public void setIssue_date(LocalDate issue_date) {
			this.issue_date = issue_date;
		}
		public LocalDate getReturn_Date() {
			return return_Date;
		}
		public void setReturn_Date(LocalDate return_Date) {
			this.return_Date = return_Date;
		}
		public EmployeeMaster getEmployee() {
			return employee;
		}
		public void setEmployee(EmployeeMaster employee) {
			this.employee = employee;
		}
		public ItemMaster getItem() {
			return item;
		}
		public void setItem(ItemMaster item) {
			this.item = item;
		}
		
}
