package com.training.loan_app.service_implementation;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.training.loan_app.exception.CustomException;
import com.training.loan_app.model.AdminMaster;
import com.training.loan_app.model.LoginMaster;
import com.training.loan_app.repository.AdminRepository;
import com.training.loan_app.service.AdminService;


@Service
public class AdminServiceImplementation implements AdminService {
	    
	    @Autowired
	    AdminRepository adminRepo;
	     
	 	public String save_Admin(AdminMaster e) throws CustomException{
			String result = "";
			Optional<AdminMaster> optional = adminRepo.findById(e.getAdmin_id());
			if(optional.isEmpty()) {
			   adminRepo.save(e);
			   result = "Admin Registered Successfully";
			   return result;
			}
			else throw new CustomException(  "Admin Already Exist", HttpStatus.BAD_REQUEST);	
		}
		
		public String login_Admin(LoginMaster l) throws CustomException{
			String result = "";
			AdminMaster employee=null;
			Optional<AdminMaster> optional = adminRepo.findById(l.getEmployee_id());
			if(optional.isEmpty()){
				throw new CustomException("Admin Not Found",HttpStatus.NOT_FOUND);
			}
			else {
				employee=optional.get();
				if(employee.getPassword().equals(l.getPassword()))
					result = "Login Successful";
				else 
					throw new CustomException("Invalid Credentials", HttpStatus.BAD_REQUEST);
			}
			return result;
		}


		public AdminMaster fetch_ById(String aid) throws CustomException {
			Optional<AdminMaster> optional = adminRepo.findById(aid);
			if (optional.isEmpty()) {
				throw new CustomException("Admin Not Found - Id:" + aid, HttpStatus.NOT_FOUND);
			} else
				return optional.get();
		}
		
}
