package com.training.loan_app.model;

import java.time.LocalDate;

import org.hibernate.validator.constraints.Length;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class AdminMaster {
	
	    @Id
	    @Length(min=8,max=8,message="Only Capital Letters and Numbers are allowed")
	    private String admin_id;
	    
	    @Column(length=25, nullable=false)
	    @Length(min=5,max=25,message="Length must be in the range of 5 to 30")
	    private String admin_name;
	    
	    @Length(min=8,max=25,message="Follow the format")
	    @Column(length=25, nullable=false)
	    private String password;
	    
	    @Column(nullable=false)
	    private char gender;
	    
	    @JsonFormat(pattern="yyyy-MM-dd")
	    @Column(nullable=false)
	    private LocalDate date_of_birth;
	    
	    @JsonFormat(pattern="yyyy-MM-dd")
	    @Column(nullable=false)
	    private LocalDate date_of_join;
	    
	    @Column(nullable=false, length=15)
	    private String department;
	    
	    @Column(nullable=false, length=15)
	    private String designation;
		
	    public String getAdmin_id() {
			return admin_id;
		}
		public void setAdmin_id(String admin_id) {
			this.admin_id = admin_id;
		}
		public String getAdmin_name() {
			return admin_name;
		}
		public void setAdmin_name(String admin_name) {
			this.admin_name = admin_name;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public char getGender() {
			return gender;
		}
		public void setGender(char gender) {
			this.gender = gender;
		}
		public LocalDate getDate_of_birth() {
			return date_of_birth;
		}
		public void setDate_of_birth(LocalDate date_of_birth) {
			this.date_of_birth = date_of_birth;
		}
		public LocalDate getDate_of_join() {
			return date_of_join;
		}
		public void setDate_of_join(LocalDate date_of_join) {
			this.date_of_join = date_of_join;
		}
		public String getDepartment() {
			return department;
		}
		public void setDepartment(String department) {
			this.department = department;
		}
		public String getDesignation() {
			return designation;
		}
		public void setDesignation(String designation) {
			this.designation = designation;
		}
		
}
