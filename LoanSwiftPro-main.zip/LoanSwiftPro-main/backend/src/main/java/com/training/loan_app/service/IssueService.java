package com.training.loan_app.service;

import java.util.List;

import com.training.loan_app.model.ItemsPurchase;


public interface IssueService {
	
	public List<ItemsPurchase> findItemsPurchasedById(String emp_id);
	
}
