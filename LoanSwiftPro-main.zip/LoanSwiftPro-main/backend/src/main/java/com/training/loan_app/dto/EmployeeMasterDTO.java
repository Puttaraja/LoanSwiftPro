package com.training.loan_app.dto;

import java.time.LocalDate;

import org.hibernate.validator.constraints.Length;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.persistence.Column;

public class EmployeeMasterDTO {
 	
	    private String employee_id;
	    @Column(length=25, nullable=false)
	    @Length(min=5,max=30,message="must be inthe range")
	    private String employee_name;
	    @Column(length=25, nullable=false)
	    private String password;
	    @Column(nullable=false)
	    private char gender;
	    @JsonFormat(pattern="yyyy-MM-dd")
	    @Column(nullable=false)
	    private LocalDate date_of_birth;
	    @JsonFormat(pattern="yyyy-MM-dd")
	    @Column(nullable=false)
	    private LocalDate date_of_join;
	    @Column(nullable=false, length=15)
	    private String department;
	    @Column(nullable=false, length=15)
	    private String designation;
	   
		public String getEmployee_id() {
			return employee_id;
		}
		public void setEmployee_id(String employee_id) {
			this.employee_id = employee_id;
		}
		public String getEmployee_name() {
			return employee_name;
		}
		public void setEmployee_name(String employee_name) {
			this.employee_name = employee_name;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public char getGender() {
			return gender;
		}
		public void setGender(char gender) {
			this.gender = gender;
		}
		public LocalDate getDate_of_birth() {
			return date_of_birth;
		}
		public void setDate_of_birth(LocalDate date_of_birth) {
			this.date_of_birth = date_of_birth;
		}
		public LocalDate getDate_of_join() {
			return date_of_join;
		}
		public void setDate_of_join(LocalDate date_of_join) {
			this.date_of_join = date_of_join;
		}
		public String getDepartment() {
			return department;
		}
		public void setDepartment(String department) {
			this.department = department;
		}
		public String getDesignation() {
			return designation;
		}
		public void setDesignation(String designation) {
			this.designation = designation;
		}
		
}
