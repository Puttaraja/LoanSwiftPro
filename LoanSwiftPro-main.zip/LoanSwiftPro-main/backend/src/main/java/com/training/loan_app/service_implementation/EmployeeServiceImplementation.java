package com.training.loan_app.service_implementation;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.training.loan_app.exception.CustomException;
import com.training.loan_app.model.EmployeeCardDetails;
import com.training.loan_app.model.EmployeeIssueDetails;
import com.training.loan_app.model.EmployeeMaster;
import com.training.loan_app.model.ItemMaster;
import com.training.loan_app.model.LoanCardMaster;
import com.training.loan_app.model.LoanModel;
import com.training.loan_app.model.LoginMaster;
import com.training.loan_app.repository.EmployeeCardRepository;
import com.training.loan_app.repository.EmployeeIssueRepository;
import com.training.loan_app.repository.EmployeeRepository;
import com.training.loan_app.repository.ItemRepository;
import com.training.loan_app.repository.LoanRepository;
import com.training.loan_app.service.EmployeeService;

import jakarta.transaction.Transactional;

@Service
public class EmployeeServiceImplementation implements EmployeeService {

	@Autowired
	EmployeeRepository repo;

	@Autowired
	LoanRepository loanRepo;

	@Autowired
	EmployeeCardRepository cardRepo;

	@Autowired
	EmployeeIssueRepository issueRepo;

	@Autowired
	ItemRepository itemRepo;

	public String save_Employee(EmployeeMaster e) throws CustomException {

		Optional<EmployeeMaster> optional = repo.findById(e.getEmployee_id());
		if(optional.isEmpty()) {
		   repo.save(e);
		   return "User Registered Successfully";
		}
		else throw new CustomException( "User Already Exist", HttpStatus.BAD_REQUEST);
	}

	public String login_Employee(LoginMaster l) throws CustomException {
		String result = "";
		EmployeeMaster employee = null;
		Optional<EmployeeMaster> optional = repo.findById(l.getEmployee_id());
		if (optional.isEmpty()) {
			throw new CustomException("User Not Found", HttpStatus.NOT_FOUND);
		} else {
			employee = optional.get();
			if (employee.getPassword().equals(l.getPassword()))
				result = "Login Successful";
			else
				throw new CustomException("Invalid Credentials", HttpStatus.BAD_REQUEST);
		}
		return result;
	}

	public EmployeeMaster fetch_ById(String id) throws CustomException {
		Optional<EmployeeMaster> optional = repo.findById(id);
		if (optional.isEmpty()) {
			throw new CustomException("User Not Found - Id:" + id, HttpStatus.NOT_FOUND);
		} else
			return optional.get();
	}

	public List<EmployeeMaster> fetch_All() throws CustomException {
		List<EmployeeMaster> empl = repo.findAll();
		if (empl.size() == 0)
			throw new CustomException("No Users Available", HttpStatus.NOT_FOUND);
		else
			return empl;
	}

	@Transactional
	public String apply_Loans(LoanModel lm) throws CustomException{
		String res = "";
		EmployeeMaster emp = null;
		Optional<EmployeeMaster> opt = repo.findById(lm.getEmployee_id());
		if (opt.isPresent())
			emp = opt.get();
		String lid = loanRepo.findByCategory(lm.getItem_category());
		LoanCardMaster loan = loanRepo.findById(lid).get();
		LocalDate dt = LocalDate.now();
		LocalDateTime dtime_ = LocalDateTime.now();
		String dtime = dtime_.toString();
		dtime = dtime.replace(":", "");
		dtime = dtime.replace("-", "");
		dtime = dtime.replace("T", "");
		dtime = dtime.replace(".", "");
		EmployeeCardDetails ecd = new EmployeeCardDetails();
		ecd.setCard_id(dtime);
		ecd.setCard_issue_date(dt);
		ecd.setEmployee(emp);
		ecd.setLoan(loan);
		cardRepo.save(ecd);
	    res = "Employee Card Details and ";
		
		EmployeeIssueDetails eid = new EmployeeIssueDetails();
		LocalDate i_dt = LocalDate.now();
		int duration = loan.getDuration_in_years();
		LocalDate r_dt = LocalDate.now().plusYears(duration);
		ItemMaster itm = itemRepo.findByMakeCategoryDesc(lm.getItem_category(), lm.getItem_make(),lm.getItem_description());
		eid.setEmployee(emp);
		eid.setIssue_date(i_dt);
		eid.setReturn_Date(r_dt);
		eid.setIssue_id(dtime);
		eid.setItem(itm);
		issueRepo.save(eid);
		res = res + "Employee Issue Details added Successfully";

		
		//Updating issue_status as N
		itm.setIssue_status('N');
		
		return res;
	}

	public String updateEmployee(String eid, EmployeeMaster emp) throws CustomException {
		String res = "";
		EmployeeMaster emp1 = null;
		Optional<EmployeeMaster> opt = repo.findById(eid);
		if (opt.isPresent()) {
			emp1 = opt.get();
			emp1.setEmployee_name(emp.getEmployee_name());
			emp1.setPassword(emp.getPassword());
			emp1.setGender(emp.getGender());
			emp1.setDate_of_birth(emp.getDate_of_birth());
			emp1.setDate_of_join(emp.getDate_of_join());
			emp1.setDepartment(emp.getDepartment());
			emp1.setDesignation(emp.getDesignation());
			repo.save(emp1);
			res = "Employee updated Succefully";
		} else
			throw new CustomException("Employee Not found", HttpStatus.NOT_FOUND);
		return res;
	}

	public String delete_Employee(String eid) throws CustomException {
		String res = "";
		Optional<EmployeeMaster> opt = repo.findById(eid);
		if (opt.isPresent()) {
			repo.deleteById(eid);
			res = "Employee deleted Succefully";
		} else
			throw new CustomException("Employee Not found", HttpStatus.NOT_FOUND);
		return res;
	}

}
