package com.training.loan_app.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.training.loan_app.model.ItemMaster;

@Repository
public interface ItemRepository extends JpaRepository<ItemMaster, String>{
	
	@Query("SELECT item FROM ItemMaster item WHERE item.item_category=?1 AND item.item_make=?2")
	public ItemMaster findByMakeCategory(String itemCategory, String itemMake);
	
	@Query("SELECT distinct item.item_category FROM ItemMaster item WHERE item.issue_status='Y' ")
	public List<String> findDistinctCategory();
	
	@Query("SELECT distinct item.item_make FROM ItemMaster item WHERE item.issue_status='Y'")
	public List<String> findDistinctItems();
	
	@Query("SELECT distinct item.item_description FROM ItemMaster item WHERE item.issue_status='Y'")
	public List<String> findDistinctDescs();
	
	@Query("SELECT distinct item.item_make FROM ItemMaster item WHERE item.item_category=?1 AND  item.issue_status='Y'")
	public List<String> findItemsByCategory(String item_category);
	
	@Query("SELECT item.item_category FROM ItemMaster item WHERE item.item_make=?1")
	public List<String> findItemsByMake(String item_make);
	
	@Query("SELECT item FROM ItemMaster item WHERE item.item_category=?1 AND item.item_make=?2 AND item.item_description=?3")
	public ItemMaster findByMakeCategoryDesc(String category, String make, String desc);
	
	@Query("SELECT distinct item.item_description FROM ItemMaster item WHERE item.item_category=?1 AND item.item_make=?2  AND  item.issue_status='Y' ")
	public List<String> findDescsByCategoryAndMake(String category,String make);
	
	@Query("SELECT item.item_valuation FROM ItemMaster item WHERE item.item_category=?1 AND item.item_make=?2 AND item.item_description=?3  AND  item.issue_status='Y' ")
	public String findValueByCategoryAndMakeAndDesc(String category, String make, String desc);

}
