package com.training.loan_app.service;

import java.util.List;

import com.training.loan_app.model.LoanCardMaster;


public interface LoanService {
	
	public String save_Loan(LoanCardMaster lcm) ;
	
	public List<LoanCardMaster> fetch_Loans();
	
	public LoanCardMaster fetch_Loan(String lid);
	
	public String update_Loan(String id, LoanCardMaster loan);
	
	public String delete_Loan(String id);
	
}
