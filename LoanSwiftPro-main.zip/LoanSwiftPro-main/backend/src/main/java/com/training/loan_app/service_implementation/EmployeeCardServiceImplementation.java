package com.training.loan_app.service_implementation;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.training.loan_app.exception.CustomException;
import com.training.loan_app.model.EmployeeCardDetails;
import com.training.loan_app.model.LoansPurchased;
import com.training.loan_app.repository.EmployeeCardRepository;
import com.training.loan_app.service.EmployeeCardService;

@Service
public class EmployeeCardServiceImplementation implements EmployeeCardService{
	
	@Autowired 
	EmployeeCardRepository e_cardRepo;
	
	public List<LoansPurchased> findLoansById(String emp_id)throws CustomException{
		List<LoansPurchased> loans_purchased = new ArrayList<>();
        List<EmployeeCardDetails> ecm = e_cardRepo.findLoansByEmpId(emp_id);
        if(ecm.size() == 0) throw new CustomException("No Loans Available",HttpStatus.NOT_FOUND);
        else{
			for(EmployeeCardDetails x:ecm) {
				LoansPurchased lp = new LoansPurchased(x.getCard_issue_date(),x.getLoan());
				loans_purchased.add(lp);
			}
			return loans_purchased;
		}
	}
	
}
