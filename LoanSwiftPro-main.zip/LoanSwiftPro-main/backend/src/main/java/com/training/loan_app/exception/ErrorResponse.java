package com.training.loan_app.exception;

import org.springframework.http.HttpStatus;

public class ErrorResponse {
   
    private String message;
    private HttpStatus statusCode;
    
	public ErrorResponse(String mes, HttpStatus statusCode) {
    	this.message = mes;
    	this.statusCode = statusCode;
    }
    
    public HttpStatus getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(HttpStatus statusCode) {
		this.statusCode = statusCode;
	}

	public String getMessage() {
		return message;
	}   
    
}
