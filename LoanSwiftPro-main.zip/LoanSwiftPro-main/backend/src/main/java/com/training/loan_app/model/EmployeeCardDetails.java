package com.training.loan_app.model;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class EmployeeCardDetails {

		@Id
		@Column(nullable=false)
		private String card_id;
		@JsonBackReference
		@ManyToOne
	    private EmployeeMaster employee;
		@JsonBackReference
		@ManyToOne
	    private LoanCardMaster loan;
		@JsonFormat(pattern="yyyy-MM-dd")
	    @Column(nullable=false)
	    private LocalDate card_issue_date;
		
		public String getCard_id() {
			return card_id;
		}
		public void setCard_id(String card_id) {
			this.card_id = card_id;
		}
		public LocalDate getCard_issue_date() {
			return card_issue_date;
		}
		public void setCard_issue_date(LocalDate card_issue_date) {
			this.card_issue_date = card_issue_date;
		}
		public EmployeeMaster getEmployee() {
			return employee;
		}
		public void setEmployee(EmployeeMaster employee) {
			this.employee = employee;
		}
		public LoanCardMaster getLoan() {
			return loan;
		}
		public void setLoan(LoanCardMaster loan) {
			this.loan = loan;
		}
		
}
