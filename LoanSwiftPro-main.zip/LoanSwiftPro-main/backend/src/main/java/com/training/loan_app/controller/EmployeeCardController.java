package com.training.loan_app.controller;


import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.training.loan_app.exception.CustomException;
import com.training.loan_app.service.EmployeeCardService;

@RestController
@CrossOrigin("http://localhost:3000")
public class EmployeeCardController {

	@Autowired
	EmployeeCardService empCardServ;
	
	@Autowired
	ModelMapper modelMapper;
	
	@GetMapping("/fetchLoansById/{employee}")
	public ResponseEntity<?> fetchLoansById(@PathVariable("employee") String employee) throws CustomException{
		try {
			return new ResponseEntity<>(empCardServ.findLoansById(employee), HttpStatus.ACCEPTED);
		}
		catch(CustomException ex){
			return new ResponseEntity<>(ex.getMessage(), ex.getStatusCode());
		}
	}
	
}
