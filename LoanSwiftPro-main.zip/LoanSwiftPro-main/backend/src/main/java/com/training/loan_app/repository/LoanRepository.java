package com.training.loan_app.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.training.loan_app.model.LoanCardMaster;

@Repository
public interface LoanRepository extends JpaRepository<LoanCardMaster, String> {
	
	@Query("SELECT l.loan_id FROM LoanCardMaster l WHERE l.loan_type=?1")
    public String findByCategory(String category);
	
	@Query("SELECT ecd.loan FROM EmployeeCardDetails ecd WHERE ecd.employee.employee_id=?1")
	public List<LoanCardMaster> findLoansByEmpId(String empId);
	
	@Query("SELECT lm.card_issue_date FROM EmployeeCardDetails lm WHERE lm.employee.employee_id=?1")
	public List<LocalDate> findIssueDateById(String emp_id);
	
}
