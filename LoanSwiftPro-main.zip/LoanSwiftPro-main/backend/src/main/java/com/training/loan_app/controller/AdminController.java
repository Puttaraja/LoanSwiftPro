package com.training.loan_app.controller;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.training.loan_app.dto.AdminMasterDTO;
import com.training.loan_app.dto.LoginMasterDTO;
import com.training.loan_app.exception.CustomException;
import com.training.loan_app.model.AdminMaster;
import com.training.loan_app.model.LoginMaster;
import com.training.loan_app.service.AdminService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import jakarta.validation.Valid;

@RestController
@CrossOrigin("http://localhost:3000")
public class AdminController {
	
	@Autowired
	AdminService serv;
	
	@Autowired
	ModelMapper modelMapper;

	@PostMapping("/saveAdmin")
	public ResponseEntity<?> saveEmployee(@Valid @RequestBody AdminMasterDTO ad) throws CustomException {
		try {
			AdminMaster a = modelMapper.map(ad, AdminMaster.class);
			return new ResponseEntity<>(serv.save_Admin(a),HttpStatus.CREATED);
		}
		catch(CustomException ex){
			return new ResponseEntity<>(ex.getMessage(), ex.getStatusCode());
		}
	}
	
	@PostMapping("/loginAdmin")
	public ResponseEntity<?> loginEmployee(@Valid @RequestBody LoginMasterDTO ld) throws CustomException {
		try {
			LoginMaster l = modelMapper.map(ld, LoginMaster.class);
			return new ResponseEntity<>(serv.login_Admin(l),HttpStatus.OK);
		}
		catch(CustomException ex){
			return new ResponseEntity<>(ex.getMessage(), ex.getStatusCode());
		}
	}
	
	@GetMapping("/fetchAdmin/{admin_id}")
	public ResponseEntity<?> fetchById(@PathVariable("admin_id") String admin_id) throws CustomException {
		try {
			return new ResponseEntity<>( modelMapper.map(serv.fetch_ById(admin_id), AdminMasterDTO.class),HttpStatus.OK);
		}
		catch(CustomException ex) {
			return new ResponseEntity<>(ex.getMessage(),ex.getStatusCode());
		}
	}
	
	
}
