package com.training.loan_app.service_implementation;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.training.loan_app.exception.CustomException;
import com.training.loan_app.model.ItemMaster;
import com.training.loan_app.repository.ItemRepository;
import com.training.loan_app.service.ItemService;

@Service
public class ItemServiceImplementation implements ItemService{
	
	@Autowired
	ItemRepository itemRepo;
	
	public String save_Item(ItemMaster i) throws CustomException{
		Optional<ItemMaster> obj = itemRepo.findById(i.getItem_id());
		String res = "";
		if(obj.isEmpty()) {
			 itemRepo.save(i);
			res = "Item added successfully";
		}
		else throw new CustomException( "Item Already Exist", HttpStatus.BAD_REQUEST);
		return res;
	}
	
	public ItemMaster fetch_Item(String itemId) throws CustomException{
		Optional<ItemMaster> optional = itemRepo.findById(itemId);
		if(optional.isEmpty())
		{
			throw new CustomException("Item Not Present",HttpStatus.NOT_FOUND);
		}
		else
		return optional.get();
	}
	
	public List<ItemMaster> fetch_Items()throws CustomException {
		 List<ItemMaster> items= itemRepo.findAll();
		if(items.size()==0) throw new CustomException("Items are not Available", HttpStatus.NOT_FOUND);
		else return items;
	}
	
	public List<String> fetch_Item_Make() throws CustomException{
		List<String>items= itemRepo.findDistinctItems();
		if(items.size()==0) throw new CustomException("Item Makes are not Available", HttpStatus.NOT_FOUND);
		else return items;
	}
	
	public List<String> fetch_Item_Category()throws CustomException{
		List<String>items= itemRepo.findDistinctCategory();
		if(items.size()==0) throw new CustomException("Item Categories are not Available", HttpStatus.NOT_FOUND);
		else return items;
	}
	
	public List<String> fetch_Item_Descs()throws CustomException{
		List<String> items= itemRepo.findDistinctDescs();
		if(items.size()==0) throw new CustomException("Item Descriptions are not Available", HttpStatus.NOT_FOUND);
		else return items;
	}
	
	public List<String> fetch_Item_Make_By_Category(String item_category)throws CustomException{
		List<String>items= itemRepo.findItemsByCategory(item_category);
		if(items.size()==0) throw new CustomException("Item Makes are not Available for this Category", HttpStatus.NOT_FOUND);
		else return items;
	}
	
	public List<String> fetch_Item_Category_By_Make(String item_make){
		List<String> items = itemRepo.findItemsByMake(item_make);
		if(items.size()==0) throw new CustomException("Item Categories are not Available for this Make", HttpStatus.NOT_FOUND);
		else return items;
	}
	
	
	public List<String> fetch_Item_Descs_By_Category_Make(String category,String make)throws CustomException{
		List<String>items= itemRepo.findDescsByCategoryAndMake(category, make);
		if(items.size()==0) throw new CustomException("Item Descriptions are not Available for this category and Make", HttpStatus.NOT_FOUND);
		else return items;
	}
	
	public String fetch_Item_Value_By_Category_Make_Desc(String category, String make, String desc) throws CustomException{
		String item_val = "";
		item_val = itemRepo.findValueByCategoryAndMakeAndDesc(category, make, desc);
		if(item_val == null)
			throw new CustomException("Item value is not Present for these Item Details",HttpStatus.NOT_FOUND);
		return item_val;
	}
	
	public String update_Item(String id, ItemMaster item) throws CustomException{
		String res = "";
		Optional<ItemMaster> opt = itemRepo.findById(id);
		ItemMaster im;
		if(opt.isPresent()) {
			im = opt.get();
			im.setItem_category(item.getItem_category());
			im.setIssue_status(item.getIssue_status());
			im.setItem_description(item.getItem_description());
			im.setItem_make(item.getItem_make());
			im.setItem_valuation(item.getItem_valuation());
			itemRepo.save(im);
			res =  "Item Updated Successfully";
		}
		else throw new CustomException( "Item Not Present", HttpStatus.NOT_FOUND);
		return res;
	}
	
	public String delete_Item(String id) throws CustomException{
		String res = "";
		Optional<ItemMaster> opt = itemRepo.findById(id);
		ItemMaster im;
		if(opt.isPresent()) {
			im = opt.get();
			itemRepo.delete(im);
			res =  "Item deleted Successfully";
		}
		else throw new CustomException( "Item Not present", HttpStatus.NOT_FOUND);
		return res;
	}

}
