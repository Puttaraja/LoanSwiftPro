package com.training.loan_app.service_implementation;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.training.loan_app.exception.CustomException;
import com.training.loan_app.model.ItemMaster;
import com.training.loan_app.model.ItemsPurchase;
import com.training.loan_app.repository.EmployeeIssueRepository;
import com.training.loan_app.service.IssueService;

@Service
public class IssueServiceImplementation implements IssueService {
	
	@Autowired
	EmployeeIssueRepository issueRepo;
	
	public List<ItemsPurchase> findItemsPurchasedById(String emp_id) throws CustomException{
		
		List<String> issue_ids = issueRepo.findItemsPurchasedById(emp_id);
		if(issue_ids.size() == 0)
			throw new CustomException("No Items issued ",HttpStatus.NOT_FOUND);
		
		List<ItemMaster> items = issueRepo.findItemsPurchasedById1(emp_id);
		if(items.size() == 0)
			throw new CustomException("No Items issued ",HttpStatus.NOT_FOUND);
		
		List<ItemsPurchase> items_purchased = new ArrayList<ItemsPurchase>();
		
		for(int i=0;i<items.size();i++) {
			items_purchased.add(new ItemsPurchase(issue_ids.get(i),items.get(i)));
		}	
		
		return items_purchased;	
		
	}
	
}
