package com.training.loan_app.controller;

import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.training.loan_app.dto.ItemsPurchaseDTO;
import com.training.loan_app.exception.CustomException;
import com.training.loan_app.service.IssueService;

@RestController
@CrossOrigin("http://localhost:3000")
public class ItemsPurchasedController {
	
	@Autowired
	IssueService issueServ;
	
	@Autowired
	ModelMapper modelMapper;
	
	@GetMapping("/fetchItemsById/{employee}")
	public ResponseEntity<?> fetchItemsById(@PathVariable("employee") String employee) throws CustomException{
		try {
			return new ResponseEntity<>( issueServ.findItemsPurchasedById(employee).stream().map(i->modelMapper.map(i, ItemsPurchaseDTO.class)).collect(Collectors.toList()), HttpStatus.OK);
		}
		catch(CustomException ex){
			return new ResponseEntity<>(ex.getMessage(), ex.getStatusCode());
		}
	}
}
