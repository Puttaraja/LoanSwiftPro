package com.training.loan_app.dto;

import com.training.loan_app.model.ItemMaster;

public class ItemsPurchaseDTO {
	
	private String issue_id;
    private ItemMaster item;
    
	public String getIssue_id() {
		return issue_id;
	}
	public void setIssue_id(String issue_id) {
		this.issue_id = issue_id;
	}
	public ItemMaster getItem() {
		return item;
	}
	public void setItem(ItemMaster item) {
		this.item = item;
	}
	
}
