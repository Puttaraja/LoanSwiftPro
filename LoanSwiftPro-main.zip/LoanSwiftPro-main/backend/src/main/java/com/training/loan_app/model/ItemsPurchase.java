package com.training.loan_app.model;

public class ItemsPurchase {
	
    private String issue_id;
    private ItemMaster item;
    
	public ItemsPurchase(String str, ItemMaster itemMaster) {
		this.issue_id=str;
		this.item = itemMaster;
	}
	public String getIssue_id() {
		return issue_id;
	}
	public void setIssue_id(String issue_id) {
		this.issue_id = issue_id;
	}
	public ItemMaster getItem() {
		return item;
	}
	public void setItem(ItemMaster item) {
		this.item = item;
	}
     
}
