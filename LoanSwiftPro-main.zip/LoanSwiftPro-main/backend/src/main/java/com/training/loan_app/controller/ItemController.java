package com.training.loan_app.controller;

import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.training.loan_app.dto.ItemMasterDTO;
import com.training.loan_app.exception.CustomException;
import com.training.loan_app.model.ItemMaster;
import com.training.loan_app.service.ItemService;


import jakarta.validation.Valid;

@RestController
@CrossOrigin("http://localhost:3000")
public class ItemController {  
	
	@Autowired
	ItemService itemServ;
	
	@Autowired
	ModelMapper modelMapper;
	
	@PostMapping("/saveItem")
	public ResponseEntity<?> saveItem(@RequestBody @Valid ItemMasterDTO id)throws CustomException {
		try {
			ItemMaster i = modelMapper.map(id, ItemMaster.class);
			return new ResponseEntity<>(itemServ.save_Item(i),HttpStatus.CREATED);
		}
		catch(CustomException ex){
			return new ResponseEntity<>(ex.getMessage(), ex.getStatusCode());
		}
	}
	
	@GetMapping("/fetchItem/{id}")
	public ResponseEntity<?> fetchItem(@PathVariable String id)throws CustomException {
		try {
			return new ResponseEntity<>(modelMapper.map(itemServ.fetch_Item(id), ItemMasterDTO.class), HttpStatus.OK);
		}
		catch(CustomException ex){
			return new ResponseEntity<>(ex.getMessage(), ex.getStatusCode());
		}
	}
	
	@GetMapping("/fetchItems")
	public ResponseEntity<?> fetchItems()throws CustomException{
		try {
			return new ResponseEntity<>( itemServ.fetch_Items().stream().map(i->modelMapper.map(i, ItemMasterDTO.class)).collect(Collectors.toList()), HttpStatus.OK);
		}
		catch(CustomException ex){
			return new ResponseEntity<>(ex.getMessage(), ex.getStatusCode());
		}
	}
	
	@GetMapping("/fetchItemCategory")
	public ResponseEntity<?> fetchItemCategory()throws CustomException{
		try {
			return new ResponseEntity<>(itemServ.fetch_Item_Category(), HttpStatus.OK);
		}
		catch(CustomException ex){
			return new ResponseEntity<>(ex.getMessage(), ex.getStatusCode());
		}
	}
	
	@GetMapping("/fetchItemMake")
	public ResponseEntity<?> fetchItemMake()throws CustomException{
		try {
			return new ResponseEntity<>( itemServ.fetch_Item_Make(), HttpStatus.OK);
		}
		catch(CustomException ex){
			return new ResponseEntity<>(ex.getMessage(), ex.getStatusCode());
		}
	}
	
	@GetMapping("/fetchItemDescs")
	public ResponseEntity<?> fetchItemDescs() throws CustomException{
		try {
			return new ResponseEntity<>( itemServ.fetch_Item_Descs(), HttpStatus.OK);
		}
		catch(CustomException ex){
			return new ResponseEntity<>(ex.getMessage(), ex.getStatusCode());
		}
	}
	
	@GetMapping("/fetchItemMakesByCategory/{item_category}")
	public ResponseEntity<?> fetchItemMakeByCategory(@PathVariable("item_category") String item_category)throws CustomException{
		try{
			return new ResponseEntity<>( itemServ.fetch_Item_Make_By_Category(item_category), HttpStatus.OK);
		}
		catch(CustomException ex){
			return new ResponseEntity<>(ex.getMessage(), ex.getStatusCode());
		}
	}
	
	@GetMapping("/fetchItemCategoryByMake/{item_make}")
	public ResponseEntity<?> fetchItemCategoryByMake(@PathVariable("item_make") String item_make)throws CustomException{
		try {
			return new ResponseEntity<>(itemServ.fetch_Item_Category_By_Make(item_make), HttpStatus.OK);
		}
		catch(CustomException ex){
			return new ResponseEntity<>(ex.getMessage(), ex.getStatusCode());
		}
	}

	
	@GetMapping("/fetchItemDescsByCategoryMake/{item_path}")
	public ResponseEntity<?> fetchItemDescsByCategoryMake(@PathVariable("item_path") String item_path)throws CustomException{
	    try {
			String[] str = item_path.split("&");
	  		String make = str[1];
			String category = str[0];
			return new ResponseEntity<>( itemServ.fetch_Item_Descs_By_Category_Make(category, make), HttpStatus.OK);
	    }
		catch(CustomException ex){
			return new ResponseEntity<>(ex.getMessage(), ex.getStatusCode());
		}
	}
	
	@GetMapping("/fetchItemValueByCategoryMakeDesc/{item_path}")
	public ResponseEntity<?> fetchItemValueByCategoryMakeDesc(@PathVariable("item_path") String item_path) throws CustomException{
		try{
			String[] str = item_path.split("&");
			String category = str[0];
			String make = str[1];
			String desc = str[2];
			return new ResponseEntity<> (itemServ.fetch_Item_Value_By_Category_Make_Desc(category, make, desc), HttpStatus.OK);
		}
		catch(CustomException ex){
			return new ResponseEntity<>(ex.getMessage(), ex.getStatusCode());
		}
	}
	
	@PutMapping("/editItem/{id}")
	public ResponseEntity<?> updateItem(@PathVariable  String id, @RequestBody ItemMaster item) throws CustomException{
		try {
			return new ResponseEntity<>( itemServ.update_Item(id, item), HttpStatus.OK);
		}
	    catch(CustomException ex){
			return new ResponseEntity<>(ex.getMessage(), ex.getStatusCode());
		}
	}
	
	@DeleteMapping("/deleteItem/{id}")
	public ResponseEntity<?> deleteItem(@PathVariable  String id) throws CustomException {
		try {
			return new ResponseEntity<>( itemServ.delete_Item(id), HttpStatus.OK);
		}
	    catch(CustomException ex){
			return new ResponseEntity<>(ex.getMessage(), ex.getStatusCode());
		}
	}

	
}

