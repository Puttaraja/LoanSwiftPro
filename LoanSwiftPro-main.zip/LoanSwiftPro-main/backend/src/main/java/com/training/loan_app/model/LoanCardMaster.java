package com.training.loan_app.model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import java.util.List;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import jakarta.persistence.OneToMany;

@Entity
public class LoanCardMaster {

	  @Id
      @Column(nullable=false)
	  private String loan_id;
	  @Column(length=15)
	  private String loan_type;
	  @Column(nullable=false)
	  private int duration_in_years;
	  @OnDelete(action=OnDeleteAction.CASCADE)
	  @OneToMany(mappedBy="loan", orphanRemoval=true, fetch=FetchType.EAGER, cascade= CascadeType.ALL)
	  private List<EmployeeCardDetails> loan_emp_card_details;
	  
	  public String getLoan_id() {
		  return loan_id;
      }
	  public void setLoan_id(String loan_id) {
		  this.loan_id = loan_id;
	  }
	  public String getLoan_type() {
		  return loan_type;
	  }
	  public void setLoan_type(String loan_type) {
		  this.loan_type = loan_type;
	  } 
	  public int getDuration_in_years() {
		  return duration_in_years;
	  }
	  public void setDuration_in_years(int duration_in_years) {
		  this.duration_in_years = duration_in_years;
 	  }
	  
}
