package com.training.loan_app.service;

import java.util.List;

import com.training.loan_app.model.LoansPurchased;

public interface EmployeeCardService {
     
	public List<LoansPurchased> findLoansById(String emp_id);
	
}
