package com.training.loan_app.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.training.loan_app.model.EmployeeIssueDetails;
import com.training.loan_app.model.ItemMaster;

import java.util.List;

@Repository
public interface EmployeeIssueRepository extends JpaRepository<EmployeeIssueDetails,String>{
	
	@Query("SELECT eid.issue_id FROM EmployeeIssueDetails eid WHERE eid.employee.employee_id=?1")
	public List<String> findItemsPurchasedById(String emp_id);
	
	@Query("SELECT eid.item FROM EmployeeIssueDetails eid WHERE eid.employee.employee_id=?1")
	public List<ItemMaster> findItemsPurchasedById1(String emp_id);
	
}
