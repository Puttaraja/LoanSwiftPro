package com.training.loan_app.controller;

import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.training.loan_app.dto.EmployeeMasterDTO;
import com.training.loan_app.dto.LoanModelDTO;
import com.training.loan_app.exception.CustomException;
import com.training.loan_app.model.EmployeeMaster;
import com.training.loan_app.model.LoanModel;
import com.training.loan_app.model.LoginMaster;
import com.training.loan_app.service.EmployeeService;

import jakarta.validation.Valid;

@RestController
@CrossOrigin("http://localhost:3000")
public class EmployeeController {
	
	@Autowired
	EmployeeService serv;
	
	@Autowired
    private ModelMapper modelMapper;
	
	@GetMapping("/displaymes")
	public String displayMes() {
		return "Welcome";
	}
	
	@PostMapping("/saveEmployee")
	public ResponseEntity<?> saveEmployee(@Valid @RequestBody EmployeeMasterDTO ed) throws CustomException {
		try {
			EmployeeMaster e = modelMapper.map(ed, EmployeeMaster.class);
			ResponseEntity<?> res = new ResponseEntity<>(serv.save_Employee(e),HttpStatus.CREATED);
			return res;
		}
		catch(CustomException ex){
			return new ResponseEntity<>(ex.getMessage(), ex.getStatusCode());
		}  
	}
	
	@PostMapping("/loginEmployee")
	public ResponseEntity<?> loginEmployee(@Valid @RequestBody LoginMaster l) throws CustomException{
		try {
			ResponseEntity<?> res = new ResponseEntity<>(serv.login_Employee(l),HttpStatus.OK);
			return res;
		}
		catch(CustomException ex) {
			return new ResponseEntity<>(ex.getMessage(),ex.getStatusCode());
		}
    }
	
	@GetMapping("/fetchEmployee/{employee_id}")
	public ResponseEntity<?> fetchById(@PathVariable("employee_id") String eid) throws CustomException {
		try {
			ResponseEntity<?> empd = new ResponseEntity<>( modelMapper.map(serv.fetch_ById(eid), EmployeeMasterDTO.class),HttpStatus.OK);
		    return empd;
		}
		catch(CustomException ex) {
			return new ResponseEntity<>(ex.getMessage(),ex.getStatusCode());
		}
	}
	
	@GetMapping("/fetchEmployees")
	public ResponseEntity<?> fetchAll() throws CustomException{
		try {
			ResponseEntity<?> empdl = new ResponseEntity<>(serv.fetch_All().stream().map(e->modelMapper.map(e, EmployeeMasterDTO.class)).collect(Collectors.toList()), HttpStatus.OK);
			return empdl;
		}
		catch(CustomException ex) {
			return new ResponseEntity<>(ex.getMessage(),ex.getStatusCode());
		}
	}
	
	@PostMapping("/applyLoans")
	public ResponseEntity<?> applyLoans(@RequestBody LoanModelDTO lmd) throws CustomException {
		try {
			LoanModel lm = modelMapper.map(lmd, LoanModel.class);
			return new ResponseEntity<>(serv.apply_Loans(lm), HttpStatus.OK);
		}
		catch(CustomException ex) {
			return new ResponseEntity<>(ex.getMessage(),ex.getStatusCode());
		}
	}
	
    @PutMapping("/editEmployee/{id}")
    public  ResponseEntity<?> updateEmployee(@PathVariable String id, @RequestBody EmployeeMasterDTO empd)throws CustomException {
    	try {
	    	EmployeeMaster emp = modelMapper.map(empd,EmployeeMaster.class);
	        return new ResponseEntity<>(serv.updateEmployee(id, emp), HttpStatus.OK);
    	}
    	catch(CustomException ex) {
    		return new ResponseEntity<>(ex.getMessage(),ex.getStatusCode());
    	}
    }
    
    @DeleteMapping("/deleteEmployee/{id}")
    public ResponseEntity<?> deleteEmployee(@PathVariable("id") String id)throws CustomException {
    	try {
    		return new ResponseEntity<>(serv.delete_Employee(id),HttpStatus.OK);
    	}
    	catch(CustomException ex) {
    		return new ResponseEntity<>(ex.getMessage(),ex.getStatusCode());
    	}
    }
    
}
