package com.training.loan_app.service;

import java.util.List;

import com.training.loan_app.model.EmployeeMaster;
import com.training.loan_app.model.LoanModel;
import com.training.loan_app.model.LoginMaster;

public interface EmployeeService {
    
	public String save_Employee(EmployeeMaster e);
	
	public String login_Employee(LoginMaster l);
	
	public EmployeeMaster fetch_ById(String id);
	
	public List<EmployeeMaster> fetch_All();
	
	public String apply_Loans(LoanModel lm);
	
	public String updateEmployee(String eid, EmployeeMaster emp);
	
	public String delete_Employee(String eid);
	
}