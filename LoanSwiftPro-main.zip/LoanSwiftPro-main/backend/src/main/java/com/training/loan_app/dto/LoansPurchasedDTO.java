package com.training.loan_app.dto;

import java.time.LocalDate;

import com.training.loan_app.model.LoanCardMaster;

public class LoansPurchasedDTO {
	
	private LocalDate issue_date;
    private LoanCardMaster loans;
    
	public LoansPurchasedDTO(LocalDate str, LoanCardMaster loanMaster) {
		this.issue_date=str;
		this.loans = loanMaster;
	}

	public LocalDate getIssue_date() {
		return issue_date;
	}
	public void setIssue_date(LocalDate issue_date) {
		this.issue_date = issue_date;
	}
	public LoanCardMaster getLoans() {
		return loans;
	}
	public void setLoans(LoanCardMaster loans) {
		this.loans = loans;
	}
	
}
