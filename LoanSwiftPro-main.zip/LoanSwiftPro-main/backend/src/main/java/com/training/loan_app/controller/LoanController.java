package com.training.loan_app.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.training.loan_app.dto.LoanCardMasterDTO;
import com.training.loan_app.exception.CustomException;
import com.training.loan_app.model.LoanCardMaster;
import com.training.loan_app.service.LoanService;

import jakarta.validation.Valid;

@RestController
@CrossOrigin("http://localhost:3000")
public class LoanController {
	
	@Autowired
	LoanService loanServ;
	
	@Autowired
	ModelMapper modelMapper;
	
	@PostMapping("/saveLoan")
	public ResponseEntity<?> saveLoan(@RequestBody @Valid LoanCardMasterDTO ld)throws CustomException {
		try {
			LoanCardMaster l = modelMapper.map(ld, LoanCardMaster.class);
			return new ResponseEntity<String>(loanServ.save_Loan(l),HttpStatus.CREATED);
		}
		catch(CustomException ex){
			return new ResponseEntity<>(ex.getMessage(), ex.getStatusCode());
		}
	}
	
	@GetMapping("/fetchLoans")
	public ResponseEntity<?> fetchLoans()  throws CustomException{
		try {
			List<LoanCardMaster> lcml = loanServ.fetch_Loans();
			return new ResponseEntity<>(lcml.stream().map(l->modelMapper.map(l, LoanCardMasterDTO.class)).collect(Collectors.toList()), HttpStatus.OK);
		}
		catch(CustomException ex){
			return new ResponseEntity<>(ex.getMessage(), ex.getStatusCode());
		}
	}
	
	@GetMapping("/fetchLoan/{loan_id}")
	public ResponseEntity<?> fetch_Loan(@PathVariable("loan_id") String lid) {
		try {
			return new ResponseEntity<>(modelMapper.map(loanServ.fetch_Loan(lid), LoanCardMasterDTO.class), HttpStatus.OK);
		}
		catch(CustomException ex){
			return new ResponseEntity<>(ex.getMessage(), ex.getStatusCode());
		}
	}
	
	@PutMapping("/editLoan/{id}")
	public ResponseEntity<?> updateLoan(@PathVariable  String id, @RequestBody LoanCardMasterDTO loand)  throws CustomException{
		try{
			LoanCardMaster loan = modelMapper.map(loand,  LoanCardMaster.class);
	    	return new ResponseEntity<> (loanServ.update_Loan(id, loan), HttpStatus.ACCEPTED);
		}
	    catch(CustomException ex){
			return new ResponseEntity<>(ex.getMessage(), ex.getStatusCode());
		}
	}

	@DeleteMapping("/deleteLoan/{id}")
	public ResponseEntity<?> deleteLoan(@PathVariable String id) throws CustomException {
		try {
			return new ResponseEntity<>(loanServ.delete_Loan(id), HttpStatus.OK);
		}
		catch(CustomException ex){
			return new ResponseEntity<>(ex.getMessage(), ex.getStatusCode());
		}
	}
}
