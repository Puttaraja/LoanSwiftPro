package com.training.loan_app;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.training.loan_app.controller.ItemController;
import com.training.loan_app.dto.ItemMasterDTO;
import com.training.loan_app.exception.CustomException;
import com.training.loan_app.model.EmployeeMaster;
import com.training.loan_app.model.ItemMaster;
import com.training.loan_app.repository.EmployeeIssueRepository;
import com.training.loan_app.repository.EmployeeRepository;
import com.training.loan_app.repository.ItemRepository;
import com.training.loan_app.repository.LoanRepository;
import com.training.loan_app.service.*;
import com.training.loan_app.service_implementation.ItemServiceImplementation;

//import org.junit.jupiter.api.Test;
import org.hamcrest.Matchers;
//import org.junit.Test;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import static org.junit.Assert.fail;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.modelmapper.ModelMapper;
import org.springframework.web.bind.annotation.CrossOrigin;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@RunWith(SpringRunner.class)
@WebMvcTest
@CrossOrigin("http://localhost:3000")
public class ItemControllerTest {

    @Autowired
    private MockMvc mvc;

    @MockBean
    private EmployeeService Empserv;
    @MockBean
    private EmployeeCardService EmpservCard;
    @MockBean
    private AdminService adminService;
    @MockBean
    private IssueService issueService;
    @MockBean
    private ItemService itemService;
    @MockBean
    private LoanService loanService;

    @MockBean
    private EmployeeRepository employeeRepository;
    @MockBean
    private ItemRepository itemRepository;
    @MockBean
    private LoanRepository loanRepository;
    @MockBean
    private EmployeeIssueRepository employeeIssueRepository;

    private static ObjectMapper mapper = new ObjectMapper();
    static {
        mapper.registerModule(new JavaTimeModule());
    }

    @Test
    public void testSaveItem() throws Exception {
        ItemMaster item = new ItemMaster();
        item.setIssue_status('Y');
        item.setItem_category("FURNITURE");
        item.setItem_description("CHAIR");
        item.setItem_id("ITEM234");
        item.setItem_make("WOODEN");
        item.setItem_valuation(550);

        String success = "Item added successfully";
        String failure = "Item Already Exist";

        String json = mapper.writeValueAsString(item);

        // success testing
        Mockito.when(itemService.save_Item(any(ItemMaster.class))).thenReturn(success);

        mvc.perform(post("/saveItem")
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("utf-8")
                        .content(json)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated())
                .andExpect(content().string(success));

        Mockito.doThrow(new CustomException(failure, HttpStatus.ALREADY_REPORTED))
                .when(itemService)
                .save_Item(any(ItemMaster.class));
        mvc.perform(post("/saveItem")
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("utf-8")
                        .content(json)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isAlreadyReported())
                .andExpect(content().string(failure));
    }
    
    @Test
    public void testFetchItemById() throws Exception {
        ItemMaster item = new ItemMaster();
        item.setIssue_status('Y');
        item.setItem_category("FURNITURE");
        item.setItem_description("CHAIR");
        item.setItem_id("ITEM234");
        item.setItem_make("WOODEN");
        item.setItem_valuation(550);

        String failure = "Item Not Present";

        String json = mapper.writeValueAsString(item);

        // success testing
        Mockito.when(itemService.fetch_Item(any(String.class))).thenReturn(item);

        mvc.perform(get("/fetchItem/" + item.getItem_id())
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("utf-8")
                        .content(json)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.item_id", Matchers.equalTo(item.getItem_id())));

        Mockito.doThrow(new CustomException(failure, HttpStatus.NOT_FOUND))
                .when(itemService)
                .fetch_Item(any(String.class));
        mvc.perform(get("/fetchItem/" + item.getItem_id())
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("utf-8")
                        .content(json)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andExpect(content().string(failure));
    }

    @Test
    public void testFetchAllItems() throws Exception {
        ItemMaster item = new ItemMaster();
        item.setIssue_status('Y');
        item.setItem_category("FURNITURE");
        item.setItem_description("CHAIR");
        item.setItem_id("ITEM234");
        item.setItem_make("WOODEN");
        item.setItem_valuation(550);

        List<ItemMaster> items = new ArrayList<>();
        items.add(item);

        String failure = "Items are not Available";

        String json = mapper.writeValueAsString(item);

        // success testing
        Mockito.when(itemService.fetch_Items()).thenReturn(items);

        mvc.perform(get("/fetchItems")
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("utf-8")
                        .content(json)
                        .accept(MediaType.APPLICATION_JSON))
                        .andExpect(status().isOk())
                        .andExpect(jsonPath("$", Matchers.hasSize(1)))
                        .andExpect(jsonPath("$[0].item_id", Matchers.equalTo(item.getItem_id())));

        Mockito.doThrow(new CustomException(failure, HttpStatus.NOT_FOUND))
                .when(itemService)
                .fetch_Items();
        mvc.perform(get("/fetchItems")
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("utf-8")
                        .content(json)
                        .accept(MediaType.APPLICATION_JSON))
                        .andExpect(status().isNotFound())
                        .andExpect(content().string(failure));
    }

    @Test
    public void testFetchItemCategory() throws Exception {
        String str = "Cat1";
        String str2 = "Cat2";

        List<String> categories = new ArrayList<>();
        categories.add(str);
        categories.add(str2);

        String failure = "Item Categories are not Available";

        // success testing
        Mockito.when(itemService.fetch_Item_Category()).thenReturn(categories);

        mvc.perform(get("/fetchItemCategory")
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("utf-8")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", Matchers.hasSize(2)))
                .andExpect(jsonPath("$[0]", Matchers.equalTo(str)))
                .andExpect(jsonPath("$[1]", Matchers.equalTo(str2)));

        Mockito.doThrow(new CustomException(failure, HttpStatus.NOT_FOUND))
                .when(itemService)
                .fetch_Item_Category();
        mvc.perform(get("/fetchItemCategory")
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("utf-8")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andExpect(content().string(failure));
    }

    @Test
    public void testFetchItemMake() throws Exception {
        String str = "Cat1";
        String str2 = "Cat2";

        List<String> categories = new ArrayList<>();
        categories.add(str);
        categories.add(str2);

        String failure = "Item Makes are not Available";

        // success testing
        Mockito.when(itemService.fetch_Item_Make()).thenReturn(categories);

        mvc.perform(get("/fetchItemMake")
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("utf-8")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", Matchers.hasSize(2)))
                .andExpect(jsonPath("$[0]", Matchers.equalTo(str)))
                .andExpect(jsonPath("$[1]", Matchers.equalTo(str2)));

        Mockito.doThrow(new CustomException(failure, HttpStatus.NOT_FOUND))
                .when(itemService)
                .fetch_Item_Make();
        mvc.perform(get("/fetchItemMake")
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("utf-8")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andExpect(content().string(failure));
    }

    @Test
    public void testFetchItemDescription() throws Exception {
        String str = "Cat1";
        String str2 = "Cat2";

        List<String> categories = new ArrayList<>();
        categories.add(str);
        categories.add(str2);

        String failure = "Item Descriptions are not Available";

        // success testing
        Mockito.when(itemService.fetch_Item_Descs()).thenReturn(categories);

        mvc.perform(get("/fetchItemDescs")
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("utf-8")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", Matchers.hasSize(2)))
                .andExpect(jsonPath("$[0]", Matchers.equalTo(str)))
                .andExpect(jsonPath("$[1]", Matchers.equalTo(str2)));

        Mockito.doThrow(new CustomException(failure, HttpStatus.NOT_FOUND))
                .when(itemService)
                .fetch_Item_Descs();
        mvc.perform(get("/fetchItemDescs")
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("utf-8")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andExpect(content().string(failure));
    }

    @Test
    public void testFetchItemMakesByCategory() throws Exception {
        String str = "Cat1";
        String str2 = "Cat2";

        List<String> categories = new ArrayList<>();
        categories.add(str);
        categories.add(str2);

        String failure = "Item Makes are not Available for this Category";

        // success testing
        Mockito.when(itemService.fetch_Item_Make_By_Category(any(String.class))).thenReturn(categories);

        mvc.perform(get("/fetchItemMakesByCategory/{item_category}", str)
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("utf-8")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", Matchers.hasSize(2)))
                .andExpect(jsonPath("$[0]", Matchers.equalTo(str)))
                .andExpect(jsonPath("$[1]", Matchers.equalTo(str2)));

        Mockito.doThrow(new CustomException(failure, HttpStatus.NOT_FOUND))
                .when(itemService)
                .fetch_Item_Make_By_Category(any(String.class));
        mvc.perform(get("/fetchItemMakesByCategory/{item_category}", str)
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("utf-8")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andExpect(content().string(failure));
    }

    @Test
    public void testFetchItemCategoryByMake() throws Exception {
        String str = "Cat1";
        String str2 = "Cat2";

        List<String> categories = new ArrayList<>();
        categories.add(str);
        categories.add(str2);

        String failure = "Item Categories are not Available for this Make";

        // success testing
        Mockito.when(itemService.fetch_Item_Category_By_Make(any(String.class))).thenReturn(categories);

        mvc.perform(get("/fetchItemCategoryByMake/{item_make}", str)
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("utf-8")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", Matchers.hasSize(2)))
                .andExpect(jsonPath("$[0]", Matchers.equalTo(str)))
                .andExpect(jsonPath("$[1]", Matchers.equalTo(str2)));

        Mockito.doThrow(new CustomException(failure, HttpStatus.NOT_FOUND))
                .when(itemService)
                .fetch_Item_Category_By_Make(any(String.class));
        mvc.perform(get("/fetchItemCategoryByMake/{item_make}", str)
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("utf-8")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andExpect(content().string(failure));
    }

    @Test
    public void testFetchItemDescsByCategoryMake() throws Exception {
        String str = "Cat1";
        String str2 = "Cat2";

        String itemPath = "Make&Cat";

        List<String> categories = new ArrayList<>();
        categories.add(str);
        categories.add(str2);

        String failure = "Item Descriptions are not Available for this category and Make";

        // success testing
        Mockito.when(itemService.fetch_Item_Descs_By_Category_Make(any(String.class), any(String.class))).thenReturn(categories);

        mvc.perform(get("/fetchItemDescsByCategoryMake/{item_path}", itemPath)
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("utf-8")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", Matchers.hasSize(2)))
                .andExpect(jsonPath("$[0]", Matchers.equalTo(str)))
                .andExpect(jsonPath("$[1]", Matchers.equalTo(str2)));

        Mockito.doThrow(new CustomException(failure, HttpStatus.NOT_FOUND))
                .when(itemService)
                .fetch_Item_Descs_By_Category_Make(any(String.class), any(String.class));
        mvc.perform(get("/fetchItemDescsByCategoryMake/{item_path}", itemPath)
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("utf-8")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andExpect(content().string(failure));
    }

    @Test
    public void testFetchItemValueByCategoryMakeDesc() throws Exception {
        String str = "value";


        String itemPath = "Make&Cat&Desc";

        String failure = "Item value is not Present for these Item Details";

        // success testing
        Mockito.when(itemService.fetch_Item_Value_By_Category_Make_Desc(any(String.class), any(String.class), any(String.class))).thenReturn(str);

        mvc.perform(get("/fetchItemValueByCategoryMakeDesc/{item_path}", itemPath)
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("utf-8")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", Matchers.equalTo(str)));

        Mockito.doThrow(new CustomException(failure, HttpStatus.NOT_FOUND))
                .when(itemService)
                .fetch_Item_Value_By_Category_Make_Desc(any(String.class), any(String.class), any(String.class));
        mvc.perform(get("/fetchItemValueByCategoryMakeDesc/{item_path}", itemPath)
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("utf-8")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andExpect(content().string(failure));
    }


    @Test
    public void testEditItem() throws Exception {
        ItemMaster item = new ItemMaster();
        item.setIssue_status('Y');
        item.setItem_category("FURNITURE");
        item.setItem_description("CHAIR");
        item.setItem_id("ITEM234");
        item.setItem_make("WOODEN");
        item.setItem_valuation(550);

        String json = mapper.writeValueAsString(item);

        String success = "Item Updated Successfully";
        String failure = "Item Not Present";

        // success testing
        Mockito.when(itemService.update_Item(any(String.class), any(ItemMaster.class))).thenReturn(success);

        mvc.perform(put("/editItem/" + item.getItem_id())
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("utf-8")
                        .content(json)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().string(success));

        Mockito.doThrow(new CustomException(failure, HttpStatus.NOT_FOUND))
                .when(itemService)
                .update_Item(any(String.class), any(ItemMaster.class));
        mvc.perform(put("/editItem/" + item.getItem_id())
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("utf-8")
                        .content(json)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andExpect(content().string(failure));
    }

    @Test
    public void testDeleteItem() throws Exception {
        ItemMaster item = new ItemMaster();
        item.setIssue_status('Y');
        item.setItem_category("FURNITURE");
        item.setItem_description("CHAIR");
        item.setItem_id("ITEM234");
        item.setItem_make("WOODEN");
        item.setItem_valuation(550);

        String json = mapper.writeValueAsString(item);

        String success = "Item deleted Successfully";
        String failure = "Item Not present";

        // success testing
        Mockito.when(itemService.delete_Item(any(String.class))).thenReturn(success);

        mvc.perform(delete("/deleteItem/" + item.getItem_id())
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("utf-8")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().string(success));

        Mockito.doThrow(new CustomException(failure, HttpStatus.NOT_FOUND))
                .when(itemService)
                .delete_Item(any(String.class));
        mvc.perform(delete("/deleteItem/" + item.getItem_id())
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("utf-8")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andExpect(content().string(failure));
    }
    
    
}
