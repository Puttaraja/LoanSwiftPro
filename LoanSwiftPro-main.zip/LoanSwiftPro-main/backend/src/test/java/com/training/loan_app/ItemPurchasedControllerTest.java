package com.training.loan_app;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
//import static org.junit.Assert.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.training.loan_app.exception.CustomException;
import com.training.loan_app.model.*;
import org.hamcrest.Matchers;
import org.junit.Ignore;
import org.junit.jupiter.api.Test;
//import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import com.training.loan_app.repository.EmployeeIssueRepository;
import com.training.loan_app.repository.EmployeeRepository;
import com.training.loan_app.repository.ItemRepository;
import com.training.loan_app.repository.LoanRepository;
//import com.training.loan_app.repository.UserRepository;
import com.training.loan_app.service.AdminService;
import com.training.loan_app.service.EmployeeCardService;
import com.training.loan_app.service.EmployeeService;
import com.training.loan_app.service.IssueService;
import com.training.loan_app.service.ItemService;
import com.training.loan_app.service.LoanService;

@RunWith(SpringRunner.class)
@WebMvcTest
@CrossOrigin("http://localhost:3000")
public class ItemPurchasedControllerTest {

    @Autowired
    private MockMvc mvc;

    @MockBean
    private EmployeeService Empserv;
    @MockBean
    private EmployeeCardService EmpservCard;
    @MockBean
    private AdminService adminService;
    @MockBean
    private IssueService issueService;
    @MockBean
    private ItemService itemService;
    @MockBean
    private LoanService loanService;

    @MockBean
    private EmployeeRepository employeeRepository;
    @MockBean
    private ItemRepository itemRepository;
    @MockBean
    private LoanRepository loanRepository;
    @MockBean
    private EmployeeIssueRepository employeeIssueRepository;

    private static ObjectMapper mapper = new ObjectMapper();
    static {
        mapper.registerModule(new JavaTimeModule());
    }

    @Test
    public void testFetchItemsById() throws Exception {
        ItemMaster item = new ItemMaster();
        item.setIssue_status('Y');
        item.setItem_category("FURNITURE");
        item.setItem_description("CHAIR");
        item.setItem_id("ITEM234");
        item.setItem_make("WOODEN");
        item.setItem_valuation(550);

        String issue_id = "id11";
        ItemsPurchase itemsPurchase = new ItemsPurchase(issue_id, item);

        List<ItemsPurchase> resList = new ArrayList<>();
        resList.add(itemsPurchase);

        String emp_id = "fte999";
        String failure = "No Items issued ";

        String json = mapper.writeValueAsString(item);

        // success testing
        Mockito.when(issueService.findItemsPurchasedById(any(String.class))).thenReturn(resList);

        mvc.perform(get("/fetchItemsById/{employee}", emp_id)
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("utf-8")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", Matchers.hasSize(1)))
                .andExpect(jsonPath("$[0].issue_id", Matchers.equalTo(issue_id)));

        Mockito.doThrow(new CustomException(failure, HttpStatus.NOT_FOUND))
                .when(issueService)
                .findItemsPurchasedById(any(String.class));
        mvc.perform(get("/fetchItemsById/{employee}", emp_id)
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("utf-8")
                        .content(json)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andExpect(content().string(failure));
    }
}