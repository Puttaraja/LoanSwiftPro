package com.training.loan_app;

import com.training.loan_app.dto.LoanCardMasterDTO;
import com.training.loan_app.exception.CustomException;
import com.training.loan_app.model.EmployeeMaster;
import com.training.loan_app.model.LoanCardMaster;
import com.training.loan_app.repository.*;
import com.training.loan_app.service.*;
import com.training.loan_app.service_implementation.EmployeeServiceImplementation;
import com.training.loan_app.service_implementation.LoanServiceImplementation;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.bind.annotation.CrossOrigin;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@RunWith(SpringRunner.class)
@WebMvcTest
@CrossOrigin("http://localhost:3000")
public class LoanServiceTest {
    @Mock
    EmployeeRepository employeeRepository;
    @MockBean
    LoanRepository loanRepo;
    @MockBean
    EmployeeCardRepository cardRepo;
    @MockBean
    EmployeeIssueRepository issueRepo;
    @MockBean
    ItemRepository itemRepo;


    @MockBean
    AdminService adminService;
    @MockBean
    private EmployeeCardService EmpservCard;
    @MockBean
    private IssueService issueService;
    @MockBean
    private ItemService itemService;
    @MockBean
    private LoanService loanService;
    @MockBean
    EmployeeServiceImplementation employeeService;

    @InjectMocks
    LoanServiceImplementation loanServiceImplementation;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testSaveLoan() throws Exception {
        LoanCardMaster loanCardMaster= new LoanCardMaster();
        loanCardMaster.setLoan_id("loan");
        loanCardMaster.setLoan_type("banking");
        loanCardMaster.setDuration_in_years(5);

        String res = "";
        HttpStatus status = HttpStatus.GONE;

        String success = "Loan added successfully";
        String failure = "Loan Already Exist";

        // Success Test
        Mockito.when(loanRepo.findById(any(String.class))).thenReturn(Optional.empty());
        Mockito.when(loanRepo.save(any(LoanCardMaster.class))).thenReturn(loanCardMaster);

        try {
            res = loanServiceImplementation.save_Loan(loanCardMaster);
        } catch (CustomException e) {
            res = e.getMessage();
            status = e.getStatusCode();
        }

        assertEquals(res, success);

        // Fail Test
        Mockito.when(loanRepo.findById(any(String.class))).thenReturn(Optional.of(loanCardMaster));

        res = "";
        try {
            res = loanServiceImplementation.save_Loan(loanCardMaster);
        } catch (CustomException e) {
            res = e.getMessage();
            status = e.getStatusCode();
        }

        assertEquals(res, failure);
        assertEquals(HttpStatus.BAD_REQUEST, status);

        // all calls
        verify(loanRepo, times(2)).findById(any(String.class));
        verify(loanRepo, times(1)).save(any(LoanCardMaster.class));
    }

    @Test
    public void testFetchLoans() throws Exception {
        LoanCardMaster loanCardMaster= new LoanCardMaster();
        loanCardMaster.setLoan_id("loan");
        loanCardMaster.setLoan_type("banking");
        loanCardMaster.setDuration_in_years(5);

        String res = "";
        HttpStatus status = HttpStatus.GONE;

//        String success = "Loan added successfully";
        String failure = "No Loans Available";

        List<LoanCardMaster> loans = new ArrayList<>();
        List<LoanCardMaster> ans = new ArrayList<>();

        // Fail Test
        Mockito.when(loanRepo.findAll()).thenReturn(loans);

        res = "";
        try {
            ans = loanServiceImplementation.fetch_Loans();
        } catch (CustomException e) {
            res = e.getMessage();
            status = e.getStatusCode();
        }

        assertEquals(res, failure);
        assertEquals(HttpStatus.NOT_FOUND, status);

        // Success Test
        loans.add(loanCardMaster);
        Mockito.when(loanRepo.findAll()).thenReturn(loans);

        res = "";
        try {
            ans = loanServiceImplementation.fetch_Loans();
        } catch (CustomException e) {
            res = e.getMessage();
            status = e.getStatusCode();
        }

        assertEquals(ans.size(), 1);
        assertEquals(ans.get(0).getLoan_id(), loanCardMaster.getLoan_id());


        // all calls
        verify(loanRepo, times(2)).findAll();
    }

    @Test
    public void testFetchLoanById() throws Exception {
        LoanCardMaster loanCardMaster= new LoanCardMaster();
        loanCardMaster.setLoan_id("loan");
        loanCardMaster.setLoan_type("banking");
        loanCardMaster.setDuration_in_years(5);

        LoanCardMaster ans = new LoanCardMaster();

        String res = "";
        HttpStatus status = HttpStatus.GONE;

        String failure = "Loan Not Found";


        // Fail Test
        Mockito.when(loanRepo.findById(any(String.class))).thenReturn(Optional.empty());

        res = "";
        try {
            ans = loanServiceImplementation.fetch_Loan(loanCardMaster.getLoan_id());
        } catch (CustomException e) {
            res = e.getMessage();
            status = e.getStatusCode();
        }

        assertEquals(res, failure);
        assertEquals(HttpStatus.NOT_FOUND, status);

        // Success Test

        Mockito.when(loanRepo.findById(any(String.class))).thenReturn(Optional.of(loanCardMaster));

        res = "";
        try {
            ans = loanServiceImplementation.fetch_Loan(loanCardMaster.getLoan_id());
        } catch (CustomException e) {
            res = e.getMessage();
            status = e.getStatusCode();
        }

        assertEquals(ans.getLoan_id(), loanCardMaster.getLoan_id());


        // all calls
        verify(loanRepo, times(2)).findById(any(String.class));
    }

    @Test
    public void testUpdateLoan() throws Exception {
        LoanCardMaster loanCardMaster= new LoanCardMaster();
        loanCardMaster.setLoan_id("loan");
        loanCardMaster.setLoan_type("banking");
        loanCardMaster.setDuration_in_years(5);

        String res = "";
        HttpStatus status = HttpStatus.GONE;
//		EmployeeMaster emp = new EmployeeMaster();

        String success = "Loan Updated Successfully";
        String failure = "Loan Not found";

        // Success Test
        Mockito.when(loanRepo.findById(any(String.class))).thenReturn(Optional.of(loanCardMaster));
        Mockito.when(loanRepo.save(any(LoanCardMaster.class))).thenReturn(loanCardMaster);

        try {
            res = loanServiceImplementation.update_Loan(loanCardMaster.getLoan_id(), loanCardMaster);
        } catch (CustomException e) {
            res = e.getMessage();
            status = e.getStatusCode();
        }

        assertEquals(res, success);

        // Failure Test
        Mockito.when(loanRepo.findById(any(String.class))).thenReturn(Optional.empty());

        try {
            res = loanServiceImplementation.update_Loan(loanCardMaster.getLoan_id(), loanCardMaster);
        } catch (CustomException e) {
            res = e.getMessage();
            status = e.getStatusCode();
        }

        assertEquals(res, failure);
        assertEquals(status, HttpStatus.NOT_FOUND);

        // All calls
        verify(loanRepo, times(2)).findById(loanCardMaster.getLoan_id());
        verify(loanRepo, times(1)).save(loanCardMaster);
    }

    @Test
    public void testDeleteLoan() throws Exception {
        LoanCardMaster loanCardMaster= new LoanCardMaster();
        loanCardMaster.setLoan_id("loan");
        loanCardMaster.setLoan_type("banking");
        loanCardMaster.setDuration_in_years(5);

        String res = "";
        HttpStatus status = HttpStatus.GONE;
//		EmployeeMaster emp = new EmployeeMaster();

        String success = "Loan Deleted Successfully";
        String failure = "Loan Not found";

        // Success Test
        Mockito.when(loanRepo.findById(any(String.class))).thenReturn(Optional.of(loanCardMaster));
        Mockito.when(loanRepo.save(any(LoanCardMaster.class))).thenReturn(loanCardMaster);

        try {
            res = loanServiceImplementation.delete_Loan(loanCardMaster.getLoan_id());
        } catch (CustomException e) {
            res = e.getMessage();
            status = e.getStatusCode();
        }

        assertEquals(res, success);

        // Failure Test
        Mockito.when(loanRepo.findById(any(String.class))).thenReturn(Optional.empty());

        try {
            res = loanServiceImplementation.delete_Loan(loanCardMaster.getLoan_id());
        } catch (CustomException e) {
            res = e.getMessage();
            status = e.getStatusCode();
        }

        assertEquals(res, failure);
        assertEquals(status, HttpStatus.NOT_FOUND);

        // All calls
        verify(loanRepo, times(2)).findById(loanCardMaster.getLoan_id());
        verify(loanRepo, times(1)).delete(loanCardMaster);
    }




}
