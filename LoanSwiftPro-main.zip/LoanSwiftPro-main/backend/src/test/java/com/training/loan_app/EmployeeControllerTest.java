package com.training.loan_app;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
//import static org.junit.Assert.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.training.loan_app.exception.CustomException;
import org.hamcrest.Matchers;
import org.junit.Ignore;
import org.junit.jupiter.api.Test;
//import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import com.training.loan_app.repository.EmployeeIssueRepository;
import com.training.loan_app.repository.EmployeeRepository;
import com.training.loan_app.repository.ItemRepository;
import com.training.loan_app.repository.LoanRepository;
//import com.training.loan_app.repository.UserRepository;
import com.training.loan_app.model.EmployeeMaster;
import com.training.loan_app.model.LoanModel;
import com.training.loan_app.model.LoginMaster;
import com.training.loan_app.service.AdminService;
import com.training.loan_app.service.EmployeeCardService;
import com.training.loan_app.service.EmployeeService;
import com.training.loan_app.service.IssueService;
import com.training.loan_app.service.ItemService;
import com.training.loan_app.service.LoanService;

@RunWith(SpringRunner.class)
@WebMvcTest
@CrossOrigin("http://localhost:3000")
public class EmployeeControllerTest {

	@Autowired
	private MockMvc mvc;

	@MockBean
	private EmployeeService Empserv;
	@MockBean
	private EmployeeCardService EmpservCard;
	@MockBean
	private AdminService adminService;
	@MockBean
	private IssueService issueService;
	@MockBean
	private ItemService itemService;
	@MockBean
	private LoanService loanService;

	@MockBean
	private EmployeeRepository employeeRepository;
	@MockBean
	private ItemRepository itemRepository;
	@MockBean
	private LoanRepository loanRepository;
	@MockBean
	private EmployeeIssueRepository employeeIssueRepository;

	// @MockBean
	// private UserRepository userRepository;

	private static ObjectMapper mapper = new ObjectMapper();
	static {
		mapper.registerModule(new JavaTimeModule());
	}

	@Test
	public void testGetEmployees() throws Exception {

		EmployeeMaster employee = new EmployeeMaster();
		employee.setEmployee_id("FTE567");
		employee.setEmployee_name("ENAME567");
		employee.setPassword("Welcome@567");
		employee.setGender('M');

		LocalDate dob = LocalDate.of(2009, 03, 13);

		employee.setDate_of_birth(dob);
		LocalDate doj = LocalDate.of(2029, 03, 16);
		employee.setDate_of_join(doj);
		employee.setDepartment("TECHNOLOGY");
		employee.setDesignation("TESTOR");

		List<EmployeeMaster> allEmployees = new ArrayList<>();
		allEmployees.add(employee);

		String failure = "No Users Available";
		Mockito.when(Empserv.fetch_All()).thenReturn(allEmployees);

		mvc.perform(get("/fetchEmployees").contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk())
				.andExpect(jsonPath("$", Matchers.hasSize(1)))
				.andExpect(jsonPath("$[0].employee_name", Matchers.equalTo(employee.getEmployee_name())));

		Mockito.doThrow(new CustomException(failure, HttpStatus.NO_CONTENT))
				.when(Empserv)
				.fetch_All();
		mvc.perform(get("/fetchEmployees")
						.contentType(MediaType.APPLICATION_JSON)
						.characterEncoding("utf-8")
						.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isNoContent())
				.andExpect(content().string(failure));
	}

	@Test
	public void testSaveEmployee() throws Exception {
		EmployeeMaster employee = new EmployeeMaster();
		employee.setEmployee_id("FTE999");
		employee.setEmployee_name("Bahubali");
		employee.setPassword("Katappa");
		employee.setGender('M');
		LocalDate dob = LocalDate.of(2019, 03, 13);
		employee.setDate_of_birth(dob);
		LocalDate doj = LocalDate.of(2029, 03, 13);
		employee.setDate_of_join(doj);
		employee.setDepartment("Finance");
		employee.setDesignation("Hecker");

		String success = "User registration successful";
		String failure = "User Already Exist";
		// Mockito.when(Empserv.save_Employee(any(EmployeeMaster.class))).thenReturn(success);

		System.out.println("hello");
		String json = mapper.writeValueAsString(employee);

		// success testing
		Mockito.when(Empserv.save_Employee(any(EmployeeMaster.class))).thenReturn(success);

		mvc.perform(post("/saveEmployee")
				.contentType(MediaType.APPLICATION_JSON)
				.characterEncoding("utf-8")
				.content(json)
				.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isCreated())
				.andExpect(content().string("User registration successful"));

		Mockito.doThrow(new CustomException(failure, HttpStatus.BAD_REQUEST))
				.when(Empserv)
				.save_Employee(any(EmployeeMaster.class));
		mvc.perform(post("/saveEmployee")
				.contentType(MediaType.APPLICATION_JSON)
				.characterEncoding("utf-8")
				.content(json)
				.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isBadRequest())
				.andExpect(content().string("User Already Exist"));

	}

	@Test
	public void testLoginEmployee() throws Exception {
		LoginMaster test = new LoginMaster();
		test.setEmployee_id("12345678");
		test.setPassword("admin");

		String invalid = "User Not Found";
		String success = "Login Successful";
		String failure = "Invalid Credentials";

		String json = mapper.writeValueAsString(test);

//		Mockito.when(Empserv.login_Employee(any(LoginMaster.class))).thenReturn(invalid);
		Mockito.doThrow(new CustomException(invalid, HttpStatus.NOT_FOUND)).when(Empserv).login_Employee(any(LoginMaster.class));
		mvc.perform(post("/loginEmployee")
				.contentType(MediaType.APPLICATION_JSON)
				.characterEncoding("utf-8")
				.content(json)
				.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isNotFound())
				.andExpect(content().string(invalid));

		Mockito.when(Empserv.login_Employee(any(LoginMaster.class))).thenReturn(success);
		mvc.perform(post("/loginEmployee")
				.contentType(MediaType.APPLICATION_JSON)
				.characterEncoding("utf-8")
				.content(json)
				.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk())
				.andExpect(content().string(success));

//		Mockito.when(Empserv.login_Employee(any(LoginMaster.class))).thenReturn(failure);
		Mockito.doThrow(new CustomException(failure, HttpStatus.BAD_REQUEST)).when(Empserv).login_Employee(any(LoginMaster.class));
		mvc.perform(post("/loginEmployee")
				.contentType(MediaType.APPLICATION_JSON)
				.characterEncoding("utf-8")
				.content(json)
				.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isBadRequest())
				.andExpect(content().string(failure));

	}

	@Test
	public void testApplyLoans() throws Exception {
		LoanModel loanModel = new LoanModel();
		loanModel.setEmployee_id("123");
		loanModel.setItem_category("Electronics");
		loanModel.setItem_description("Laptop");
		loanModel.setItem_valuation(1000);
		loanModel.setItem_make("HP");

		String success = "Employee Card Details added Successfully";
		String failure = "Card Already Exists";

		String json = mapper.writeValueAsString(loanModel);

		Mockito.when(Empserv.apply_Loans(any(LoanModel.class))).thenReturn(success);
		mvc.perform(post("/applyLoans")
				.contentType(MediaType.APPLICATION_JSON)
				.characterEncoding("utf-8")
				.content(json)
				.accept(MediaType.TEXT_PLAIN))
				.andExpect(content().string(success));

		Mockito.when(Empserv.apply_Loans(any(LoanModel.class))).thenReturn(failure);
		mvc.perform(post("/applyLoans")
				.contentType(MediaType.APPLICATION_JSON)
				.characterEncoding("utf-8")
				.content(json)
				.accept(MediaType.TEXT_PLAIN))
				.andExpect(content().string(failure));
	}

	@Test
	public void testFetchEmployee() throws Exception {
		EmployeeMaster employee = new EmployeeMaster();
		employee.setEmployee_id("FTE999");
		employee.setEmployee_name("Bahubali");
		employee.setPassword("Katappa");
		employee.setGender('M');
		LocalDate dob = LocalDate.of(2019, 03, 13);
		employee.setDate_of_birth(dob);
		LocalDate doj = LocalDate.of(2029, 03, 16);
		employee.setDate_of_join(doj);
		employee.setDepartment("Finance");
		employee.setDesignation("Hecker");

		String failure = "User Not Found - Id:" + employee.getEmployee_id();
		Mockito.when(Empserv.fetch_ById(any(String.class))).thenReturn(employee);

		mvc.perform(get("/fetchEmployee/{employee_id}", employee.getEmployee_id()))
				.andExpect(jsonPath("$.employee_id", Matchers.equalTo(employee.getEmployee_id())));

		Mockito.doThrow(new CustomException(failure, HttpStatus.NOT_FOUND))
				.when(Empserv)
				.fetch_ById(any(String.class));
		mvc.perform(get("/fetchEmployee/{employee_id}", employee.getEmployee_id())
						.contentType(MediaType.APPLICATION_JSON)
						.characterEncoding("utf-8")
						.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isNotFound())
				.andExpect(content().string(failure));


	}

	@Test
	public void testEditEmployee() throws Exception {
		EmployeeMaster employee = new EmployeeMaster();
		employee.setEmployee_id("FTE999");
		employee.setEmployee_name("Bahubali");
		employee.setPassword("Katappa");
		employee.setGender('M');
		LocalDate dob = LocalDate.of(2019, 03, 13);
		employee.setDate_of_birth(dob);
		LocalDate doj = LocalDate.of(2029, 03, 13);
		employee.setDate_of_join(doj);
		employee.setDepartment("Finance");
		employee.setDesignation("Hecker");

		System.out.println("hello");
		String json = mapper.writeValueAsString(employee);

		String success = "Employee updated Succefully";
		String failure = "Employee Not found";

		// success testing
		Mockito.when(Empserv.updateEmployee(any(String.class), any(EmployeeMaster.class))).thenReturn(success);

		mvc.perform(put("/editEmployee/" + employee.getEmployee_id())
						.contentType(MediaType.APPLICATION_JSON)
						.characterEncoding("utf-8")
						.content(json)
						.accept(MediaType.APPLICATION_JSON))
						.andExpect(status().isOk())
						.andExpect(content().string("Employee updated Succefully"));

		Mockito.doThrow(new CustomException(failure, HttpStatus.NOT_FOUND))
				.when(Empserv)
				.updateEmployee(any(String.class), any(EmployeeMaster.class));
		mvc.perform(put("/editEmployee/" + employee.getEmployee_id())
						.contentType(MediaType.APPLICATION_JSON)
						.characterEncoding("utf-8")
						.content(json)
						.accept(MediaType.APPLICATION_JSON))
						.andExpect(status().isNotFound())
						.andExpect(content().string("Employee Not found"));
	}

	@Test
	public void testDeleteEmployee() throws Exception {
		EmployeeMaster employee = new EmployeeMaster();
		employee.setEmployee_id("FTE999");
		employee.setEmployee_name("Bahubali");
		employee.setPassword("Katappa");
		employee.setGender('M');
		LocalDate dob = LocalDate.of(2019, 03, 13);
		employee.setDate_of_birth(dob);
		LocalDate doj = LocalDate.of(2029, 03, 13);
		employee.setDate_of_join(doj);
		employee.setDepartment("Finance");
		employee.setDesignation("Hecker");

		System.out.println("hello");
		String json = mapper.writeValueAsString(employee);

		String success = "Employee deleted Succefully";
		String failure = "Employee Not found";

		// success testing
		Mockito.when(Empserv.delete_Employee(any(String.class))).thenReturn(success);

		mvc.perform(delete("/deleteEmployee/" + employee.getEmployee_id())
						.contentType(MediaType.APPLICATION_JSON)
						.characterEncoding("utf-8")
						.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isOk())
				.andExpect(content().string(success));

		Mockito.doThrow(new CustomException(failure, HttpStatus.NOT_FOUND))
				.when(Empserv)
				.delete_Employee(any(String.class));
		mvc.perform(delete("/deleteEmployee/" + employee.getEmployee_id())
						.contentType(MediaType.APPLICATION_JSON)
						.characterEncoding("utf-8")
						.accept(MediaType.APPLICATION_JSON))
				.andExpect(status().isNotFound())
				.andExpect(content().string(failure));
	}
}