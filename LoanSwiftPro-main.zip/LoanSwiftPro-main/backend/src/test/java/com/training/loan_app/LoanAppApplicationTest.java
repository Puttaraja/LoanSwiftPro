package com.training.loan_app;

import org.apache.catalina.connector.Response;
import org.junit.Assert;
import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.SecurityProperties.User;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringRunner.class)
@SpringBootTest
class LoanAppApplicationTest {

	private MockMvc mockMvc;
	
	@Autowired
	private WebApplicationContext context;
	
	ObjectMapper objectMapper = new ObjectMapper();
	
	@Before
	public void setUp() {
		mockMvc = MockMvcBuilders.webAppContextSetup(context).build();
	}
	
//	@Test
//	public void addUser() throws Exception {
//		User user = new User();
//		user.setName("ADMIN");
//		user.setRole("ADM");
//		
//		String JsonRequest= objectMapper.writeValueAsString(user);
//		
//		MvcResult result = mockMvc.perform(post("/user/addUsers")).content(JsonRequest)
//				.contentType(MediaType.APPLICATION_JSON_VALUE)
//				.andExpect(status().isOk())
//				.andReturn();
//		
//		String resultContext = result.getResponse().getContentAsString();
//		
//		Response response = objectMapper.readValue(resultContext, Response.class);
//		
//		Assert.assertTrue(response.isStatus() == Boolean.TRUE);
//				
//				
//	}
	
	@Test
	void contextLoads() {
	}

}
