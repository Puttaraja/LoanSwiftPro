package com.training.loan_app;

import com.training.loan_app.exception.CustomException;
import com.training.loan_app.model.EmployeeCardDetails;
import com.training.loan_app.model.EmployeeMaster;
import com.training.loan_app.model.LoanCardMaster;
import com.training.loan_app.model.LoansPurchased;
import com.training.loan_app.repository.*;
import com.training.loan_app.service.*;
import com.training.loan_app.service_implementation.EmployeeCardServiceImplementation;
import com.training.loan_app.service_implementation.EmployeeServiceImplementation;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.bind.annotation.CrossOrigin;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@RunWith(SpringRunner.class)
@WebMvcTest
@CrossOrigin("http://localhost:3000")
public class EmployeeCardServiceTest {

    @Mock
    EmployeeRepository employeeRepository;
    @MockBean
    LoanRepository loanRepo;
    @MockBean
    EmployeeCardRepository cardRepo;
    @MockBean
    EmployeeIssueRepository issueRepo;
    @MockBean
    ItemRepository itemRepo;


    @MockBean
    AdminService adminService;
    @MockBean
    private EmployeeCardService EmpservCard;
    @MockBean
    private IssueService issueService;
    @MockBean
    private ItemService itemService;
    @MockBean
    private LoanService loanService;
    @MockBean
    EmployeeServiceImplementation employeeService;

    @InjectMocks
    EmployeeCardServiceImplementation employeeCardServiceImplementation;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testFindLoandById() throws Exception {
        EmployeeMaster employee = new EmployeeMaster();
        employee.setEmployee_id("FTE999");
        employee.setEmployee_name("Bahubali");
        employee.setPassword("Katappa");
        employee.setGender('M');
        LocalDate dob = LocalDate.of(2019, 03, 13);
        employee.setDate_of_birth(dob);
        LocalDate doj = LocalDate.of(2029, 03, 13);
        employee.setDate_of_join(doj);
        employee.setDepartment("Finance");
        employee.setDesignation("Hecker");

        LoanCardMaster loanCardMaster = new LoanCardMaster();
        loanCardMaster.setLoan_id("loan");
        loanCardMaster.setLoan_type("banking");
        loanCardMaster.setDuration_in_years(5);

        EmployeeCardDetails employeeCardDetails = new EmployeeCardDetails();
        employeeCardDetails.setCard_id("card");
        employeeCardDetails.setEmployee(employee);
        employeeCardDetails.setLoan(loanCardMaster);

        LocalDate date = LocalDate.of(2019, 03, 13);
        employeeCardDetails.setCard_issue_date(date);

        List<EmployeeCardDetails> employeeCardDetailsList = new ArrayList<>();
        String failure = "No Loans Available";
        String emp_id = "testid";

        List<LoansPurchased> loansPurchasedList = new ArrayList<>();
        String res = "";
        HttpStatus status = HttpStatus.GONE;

        // failure test
        Mockito.when(cardRepo.findLoansByEmpId(any(String.class))).thenReturn(employeeCardDetailsList);
        try {
            loansPurchasedList = employeeCardServiceImplementation.findLoansById(emp_id);
        } catch (CustomException e) {
            res = e.getMessage();
            status = e.getStatusCode();
        }

//        assertEquals(res, failure);
//        assertEquals(status, HttpStatus.NOT_FOUND);

        // success
        employeeCardDetailsList.add(employeeCardDetails);
        Mockito.when(cardRepo.findLoansByEmpId(any(String.class))).thenReturn(employeeCardDetailsList);

        try {
            loansPurchasedList = employeeCardServiceImplementation.findLoansById(emp_id);
        } catch (CustomException e) {
            res = e.getMessage();
            status = e.getStatusCode();
        }

//        assertEquals(loansPurchasedList.size(), 1);
//        assertEquals(loansPurchasedList.get(0).getLoans().getLoan_id(), loanCardMaster.getLoan_id());


        // all calls
//        verify(cardRepo, times(2)).findLoansByEmpId(any(String.class));

    }
}
