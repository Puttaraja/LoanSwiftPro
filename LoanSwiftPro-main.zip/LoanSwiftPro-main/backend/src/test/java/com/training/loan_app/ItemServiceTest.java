package com.training.loan_app;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import com.training.loan_app.exception.CustomException;
import com.training.loan_app.model.EmployeeIssueDetails;
import com.training.loan_app.model.EmployeeMaster;
import com.training.loan_app.repository.*;
import com.training.loan_app.service.*;
import com.training.loan_app.service_implementation.EmployeeServiceImplementation;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import com.training.loan_app.model.ItemMaster;
import com.training.loan_app.service_implementation.ItemServiceImplementation;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.bind.annotation.CrossOrigin;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RunWith(SpringRunner.class)
@WebMvcTest
@CrossOrigin("http://localhost:3000")
public class ItemServiceTest {

	@Mock
	EmployeeRepository employeeRepository;
	@MockBean
	LoanRepository loanRepo;
	@MockBean
	EmployeeCardRepository cardRepo;
	@MockBean
	EmployeeIssueRepository issueRepo;
	@MockBean
	ItemRepository itemRepo;


	@MockBean
	AdminService adminService;
	@MockBean
	private EmployeeCardService EmpservCard;
	@MockBean
	private IssueService issueService;
	@MockBean
	private ItemService itemService;
	@MockBean
	private LoanService loanService;
	@MockBean
	EmployeeServiceImplementation employeeService;

	@InjectMocks
	ItemServiceImplementation itemServiceImplementation;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testSaveItem() throws Exception {
		ItemMaster item = new ItemMaster();
		item.setIssue_status('Y');
		item.setItem_category("FURNITURE");
		item.setItem_description("CHAIR");
		item.setItem_id("ITEM234");
		item.setItem_make("WOODEN");
		item.setItem_valuation(550);

		String success = "Item added successfully";
		String failure = "Item Already Exist";

		String res = "";
		HttpStatus status = HttpStatus.GONE;

		// Success Test
		Mockito.when(itemRepo.findById(any(String.class))).thenReturn(Optional.empty());
		Mockito.when(itemRepo.save(any(ItemMaster.class))).thenReturn(item);

		try {
			res = itemServiceImplementation.save_Item(item);
		} catch (CustomException e) {
			res = e.getMessage();
			status = e.getStatusCode();
		}

		assertEquals(res, success);

		// Fail Test
		Mockito.when(itemRepo.findById(any(String.class))).thenReturn(Optional.of(item));

		res = "";
		status = HttpStatus.GONE;
		try {
			res = itemServiceImplementation.save_Item(item);
		} catch (CustomException e) {
			res = e.getMessage();
			status = e.getStatusCode();
		}

		assertEquals(res, failure);
		assertEquals(HttpStatus.BAD_REQUEST, status);

		// all calls
		verify(itemRepo, times(2)).findById(any(String.class));
		verify(itemRepo, times(1)).save(any(ItemMaster.class));
	}

	@Test
	public void testFetchItemById() throws Exception {
		ItemMaster item = new ItemMaster();
		item.setIssue_status('Y');
		item.setItem_category("FURNITURE");
		item.setItem_description("CHAIR");
		item.setItem_id("ITEM234");
		item.setItem_make("WOODEN");
		item.setItem_valuation(550);

//		String success = "Item added successfully";
		String failure = "Item Not Present";

		String res = "";
		HttpStatus status = HttpStatus.GONE;
		ItemMaster ans = new ItemMaster();

		// Success Test
		Mockito.when(itemRepo.findById(any(String.class))).thenReturn(Optional.of(item));

		try {
			ans = itemServiceImplementation.fetch_Item(item.getItem_id());
		} catch (CustomException e) {
			res = e.getMessage();
			status = e.getStatusCode();
		}

		assertEquals(ans.getItem_id(), item.getItem_id());

		// Fail Test
		Mockito.when(itemRepo.findById(any(String.class))).thenReturn(Optional.empty());

		res = "";
		status = HttpStatus.GONE;
		try {
			ans = itemServiceImplementation.fetch_Item(item.getItem_id());
		} catch (CustomException e) {
			res = e.getMessage();
			status = e.getStatusCode();
		}

		assertEquals(res, failure);
		assertEquals(HttpStatus.NOT_FOUND, status);

		// all calls
		verify(itemRepo, times(2)).findById(any(String.class));
	}

	@Test
	public void testFetchItems() throws Exception {
		ItemMaster item = new ItemMaster();
		item.setIssue_status('Y');
		item.setItem_category("FURNITURE");
		item.setItem_description("CHAIR");
		item.setItem_id("ITEM234");
		item.setItem_make("WOODEN");
		item.setItem_valuation(550);

		List<ItemMaster> items = new ArrayList<>();
		List<ItemMaster> rec = new ArrayList<>();

//		String success = "Item added successfully";
		String failure = "Items are not Available";

		String res = "";
		HttpStatus status = HttpStatus.GONE;

		// Failure Test
		Mockito.when(itemRepo.findAll()).thenReturn(items);

		try {
			rec = itemServiceImplementation.fetch_Items();
		} catch (CustomException e) {
			res = e.getMessage();
			status = e.getStatusCode();
		}

		assertEquals(res, failure);
		assertEquals(HttpStatus.NOT_FOUND, status);

		// Success Test
		items.add(item);
		Mockito.when(itemRepo.findAll()).thenReturn(items);

		res = "";
		status = HttpStatus.GONE;

		try {
			rec = itemServiceImplementation.fetch_Items();
		} catch (CustomException e) {
			res = e.getMessage();
			status = e.getStatusCode();
		}

		assertEquals(rec.size(), 1);
		assertEquals(rec.get(0).getItem_id(), item.getItem_id());

		// all calls
		verify(itemRepo, times(2)).findAll();
	}

	@Test
	public void testFetchItemMake() throws Exception {
		List<String> items = new ArrayList<>();
		List<String> rec = new ArrayList<>();

		String failure = "Item Makes are not Available";

		String res = "";
		HttpStatus status = HttpStatus.GONE;

		// Failure Test
		Mockito.when(itemRepo.findDistinctItems()).thenReturn(items);

		try {
			rec = itemServiceImplementation.fetch_Item_Make();
		} catch (CustomException e) {
			res = e.getMessage();
			status = e.getStatusCode();
		}

		assertEquals(res, failure);
		assertEquals(HttpStatus.NOT_FOUND, status);

		// Success Test
		items.add("item");
		Mockito.when(itemRepo.findDistinctItems()).thenReturn(items);

		res = "";
		status = HttpStatus.GONE;

		try {
			rec = itemServiceImplementation.fetch_Item_Make();
		} catch (CustomException e) {
			res = e.getMessage();
			status = e.getStatusCode();
		}

		assertEquals(rec.size(), 1);
		assertEquals(rec.get(0), "item");

		// all calls
		verify(itemRepo, times(2)).findDistinctItems();
	}

	@Test
	public void testFetchItemCategory() throws Exception {
		List<String> items = new ArrayList<>();
		List<String> rec = new ArrayList<>();

		String failure = "Item Categories are not Available";

		String res = "";
		HttpStatus status = HttpStatus.GONE;

		// Failure Test
		Mockito.when(itemRepo.findDistinctCategory()).thenReturn(items);

		try {
			rec = itemServiceImplementation.fetch_Item_Category();
		} catch (CustomException e) {
			res = e.getMessage();
			status = e.getStatusCode();
		}

		assertEquals(res, failure);
		assertEquals(HttpStatus.NOT_FOUND, status);

		// Success Test
		items.add("item");
		Mockito.when(itemRepo.findDistinctCategory()).thenReturn(items);

		res = "";
		status = HttpStatus.GONE;

		try {
			rec = itemServiceImplementation.fetch_Item_Category();
		} catch (CustomException e) {
			res = e.getMessage();
			status = e.getStatusCode();
		}

		assertEquals(rec.size(), 1);
		assertEquals(rec.get(0), "item");

		// all calls
		verify(itemRepo, times(2)).findDistinctCategory();
	}

	@Test
	public void testFetchItemDesc() throws Exception {
		List<String> items = new ArrayList<>();
		List<String> rec = new ArrayList<>();

		String failure = "Item Descriptions are not Available";

		String res = "";
		HttpStatus status = HttpStatus.GONE;

		// Failure Test
		Mockito.when(itemRepo.findDistinctDescs()).thenReturn(items);

		try {
			rec = itemServiceImplementation.fetch_Item_Descs();
		} catch (CustomException e) {
			res = e.getMessage();
			status = e.getStatusCode();
		}

		assertEquals(res, failure);
		assertEquals(HttpStatus.NOT_FOUND, status);

		// Success Test
		items.add("item");
		Mockito.when(itemRepo.findDistinctDescs()).thenReturn(items);

		res = "";
		status = HttpStatus.GONE;

		try {
			rec = itemServiceImplementation.fetch_Item_Descs();
		} catch (CustomException e) {
			res = e.getMessage();
			status = e.getStatusCode();
		}

		assertEquals(rec.size(), 1);
		assertEquals(rec.get(0), "item");

		// all calls
		verify(itemRepo, times(2)).findDistinctDescs();
	}

	@Test
	public void testFetchItemMakeByCategory() throws Exception {
		List<String> items = new ArrayList<>();
		List<String> rec = new ArrayList<>();

		String failure = "Item Makes are not Available for this Category";

		String res = "";
		HttpStatus status = HttpStatus.GONE;

		String eid = "eid";

		// Failure Test
		Mockito.when(itemRepo.findItemsByCategory(any(String.class))).thenReturn(items);

		try {
			rec = itemServiceImplementation.fetch_Item_Make_By_Category(eid);
		} catch (CustomException e) {
			res = e.getMessage();
			status = e.getStatusCode();
		}

		assertEquals(res, failure);
		assertEquals(HttpStatus.NOT_FOUND, status);

		// Success Test
		items.add("item");
		Mockito.when(itemRepo.findItemsByCategory(any(String.class))).thenReturn(items);

		res = "";
		status = HttpStatus.GONE;

		try {
			rec = itemServiceImplementation.fetch_Item_Make_By_Category(eid);
		} catch (CustomException e) {
			res = e.getMessage();
			status = e.getStatusCode();
		}

		assertEquals(rec.size(), 1);
		assertEquals(rec.get(0), "item");

		// all calls
		verify(itemRepo, times(2)).findItemsByCategory(any(String.class));
	}

	@Test
	public void testFetchItemCategoryByMake() throws Exception {
		List<String> items = new ArrayList<>();
		List<String> rec = new ArrayList<>();

		String failure = "Item Categories are not Available for this Make";

		String res = "";
		HttpStatus status = HttpStatus.GONE;

		String eid = "eid";

		// Failure Test
		Mockito.when(itemRepo.findItemsByMake(any(String.class))).thenReturn(items);

		try {
			rec = itemServiceImplementation.fetch_Item_Category_By_Make(eid);
		} catch (CustomException e) {
			res = e.getMessage();
			status = e.getStatusCode();
		}

		assertEquals(res, failure);
		assertEquals(HttpStatus.NOT_FOUND, status);

		// Success Test
		items.add("item");
		Mockito.when(itemRepo.findItemsByMake(any(String.class))).thenReturn(items);

		res = "";
		status = HttpStatus.GONE;

		try {
			rec = itemServiceImplementation.fetch_Item_Category_By_Make(eid);
		} catch (CustomException e) {
			res = e.getMessage();
			status = e.getStatusCode();
		}

		assertEquals(rec.size(), 1);
		assertEquals(rec.get(0), "item");

		// all calls
		verify(itemRepo, times(2)).findItemsByMake(any(String.class));
	}

	@Test
	public void testFetchItemDescByCategoryMake() throws Exception {
		List<String> items = new ArrayList<>();
		List<String> rec = new ArrayList<>();

		String failure = "Item Descriptions are not Available for this category and Make";

		String res = "";
		HttpStatus status = HttpStatus.GONE;

		String eid = "eid";
		String fid = "fid";

		// Failure Test
		Mockito.when(itemRepo.findDescsByCategoryAndMake(any(String.class), any(String.class))).thenReturn(items);

		try {
			rec = itemServiceImplementation.fetch_Item_Descs_By_Category_Make(eid, fid);
		} catch (CustomException e) {
			res = e.getMessage();
			status = e.getStatusCode();
		}

		assertEquals(res, failure);
		assertEquals(HttpStatus.NOT_FOUND, status);

		// Success Test
		items.add("item");
		Mockito.when(itemRepo.findDescsByCategoryAndMake(any(String.class), any(String.class))).thenReturn(items);

		res = "";
		status = HttpStatus.GONE;

		try {
			rec = itemServiceImplementation.fetch_Item_Descs_By_Category_Make(eid, fid);
		} catch (CustomException e) {
			res = e.getMessage();
			status = e.getStatusCode();
		}

		assertEquals(rec.size(), 1);
		assertEquals(rec.get(0), "item");

		// all calls
		verify(itemRepo, times(2)).findDescsByCategoryAndMake(any(String.class), any(String.class));
	}

	@Test
	public void testFetchItemValueByCategoryMakeDesc() throws Exception {
		String rec = "";
		String failure = "Item value is not Present for these Item Details";

		String res = "";
		HttpStatus status = HttpStatus.GONE;

		String eid = "eid";
		String fid = "fid";
		String gid = "gid";

		// Failure Test
		Mockito.when(itemRepo.findValueByCategoryAndMakeAndDesc(any(String.class), any(String.class), any(String.class))).thenReturn(null);

		try {
			rec = itemServiceImplementation.fetch_Item_Value_By_Category_Make_Desc(eid, fid, gid);
		} catch (CustomException e) {
			res = e.getMessage();
			status = e.getStatusCode();
		}

		assertEquals(res, failure);
		assertEquals(HttpStatus.NOT_FOUND, status);

		// Success Test
		String items = "items";
		Mockito.when(itemRepo.findValueByCategoryAndMakeAndDesc(any(String.class), any(String.class), any(String.class))).thenReturn(items);

		res = "";
		status = HttpStatus.GONE;

		try {
			rec = itemServiceImplementation.fetch_Item_Value_By_Category_Make_Desc(eid, fid, gid);
		} catch (CustomException e) {
			res = e.getMessage();
			status = e.getStatusCode();
		}

		assertEquals(rec, "items");

		// all calls
		verify(itemRepo, times(2)).findValueByCategoryAndMakeAndDesc(any(String.class), any(String.class), any(String.class));
	}

	@Test
	public void testUpdateItem() throws Exception {
		ItemMaster item = new ItemMaster();
		item.setIssue_status('Y');
		item.setItem_category("FURNITURE");
		item.setItem_description("CHAIR");
		item.setItem_id("ITEM234");
		item.setItem_make("WOODEN");
		item.setItem_valuation(550);

		String success = "Item Updated Successfully";
		String failure = "Item Not Present";

		String res = "";
		HttpStatus status;
		ItemMaster ans = new ItemMaster();

		// Success Test
		Mockito.when(itemRepo.findById(any(String.class))).thenReturn(Optional.of(item));
		Mockito.when(itemRepo.save(any(ItemMaster.class))).thenReturn(item);

		try {
			res = itemServiceImplementation.update_Item(item.getItem_id(), item);
		} catch (CustomException e) {
			res = e.getMessage();
			status = e.getStatusCode();
		}

		assertEquals(res, success);

		// Fail Test
		Mockito.when(itemRepo.findById(any(String.class))).thenReturn(Optional.empty());

		res = "";
		status = HttpStatus.GONE;
		try {
			res = itemServiceImplementation.update_Item(item.getItem_id(), item);
		} catch (CustomException e) {
			res = e.getMessage();
			status = e.getStatusCode();
		}

		assertEquals(res, failure);
		assertEquals(HttpStatus.NOT_FOUND, status);

		// all calls
		verify(itemRepo, times(2)).findById(any(String.class));
		verify(itemRepo, times(1)).save(any(ItemMaster.class));

	}

	@Test
	public void testDeleteItem() throws Exception {
		ItemMaster item = new ItemMaster();
		item.setIssue_status('Y');
		item.setItem_category("FURNITURE");
		item.setItem_description("CHAIR");
		item.setItem_id("ITEM234");
		item.setItem_make("WOODEN");
		item.setItem_valuation(550);

		String success = "Item deleted Successfully";
		String failure = "Item Not present";

		String res = "";
		HttpStatus status;

		// Success Test
		Mockito.when(itemRepo.findById(any(String.class))).thenReturn(Optional.of(item));
		Mockito.doNothing().when(itemRepo).delete(any(ItemMaster.class));

		try {
			res = itemServiceImplementation.delete_Item(item.getItem_id());
		} catch (CustomException e) {
			res = e.getMessage();
			status = e.getStatusCode();
		}

		assertEquals(res, success);

		// Fail Test
		Mockito.when(itemRepo.findById(any(String.class))).thenReturn(Optional.empty());

		res = "";
		status = HttpStatus.GONE;
		try {
			res = itemServiceImplementation.delete_Item(item.getItem_id());
		} catch (CustomException e) {
			res = e.getMessage();
			status = e.getStatusCode();
		}

		assertEquals(res, failure);
		assertEquals(HttpStatus.NOT_FOUND, status);

		// all calls
		verify(itemRepo, times(2)).findById(any(String.class));
		verify(itemRepo, times(1)).delete(any(ItemMaster.class));

	}




}
