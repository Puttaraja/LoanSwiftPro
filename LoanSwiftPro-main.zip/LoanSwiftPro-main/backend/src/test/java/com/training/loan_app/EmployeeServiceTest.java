package com.training.loan_app;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.training.loan_app.exception.CustomException;
import com.training.loan_app.model.*;
import com.training.loan_app.repository.*;
import com.training.loan_app.service_implementation.EmployeeServiceImplementation;
import org.junit.Before;
import org.junit.Test;
//import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.bind.annotation.CrossOrigin;

//import com.training.loan_app.repository.UserRepository;
import com.training.loan_app.service.AdminService;
import com.training.loan_app.service.EmployeeCardService;
import com.training.loan_app.service.IssueService;
import com.training.loan_app.service.ItemService;
import com.training.loan_app.service.LoanService;

@RunWith(SpringRunner.class)
@WebMvcTest
@CrossOrigin("http://localhost:3000")
public class EmployeeServiceTest {

	@Mock
	EmployeeRepository employeeRepository;
	@MockBean
	LoanRepository loanRepo;
	@MockBean
	EmployeeCardRepository cardRepo;
	@MockBean
	EmployeeIssueRepository issueRepo;
	@MockBean
	ItemRepository itemRepo;


	@MockBean
	AdminService adminService;
	@MockBean
	private EmployeeCardService EmpservCard;
	@MockBean
	private IssueService issueService;
	@MockBean
	private ItemService itemService;
	@MockBean
	private LoanService loanService;
	@MockBean
	EmployeeServiceImplementation employeeService;

	@InjectMocks
	EmployeeServiceImplementation empService;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testSaveEmployee() throws Exception {
		EmployeeMaster employee = new EmployeeMaster();
		employee.setEmployee_id("FTE999");
		employee.setEmployee_name("Bahubali");
		employee.setPassword("Katappa");
		employee.setGender('M');
		LocalDate dob = LocalDate.of(2019, 03, 13);
		employee.setDate_of_birth(dob);
		LocalDate doj = LocalDate.of(2029, 03, 13);
		employee.setDate_of_join(doj);
		employee.setDepartment("Finance");
		employee.setDesignation("Hecker");

		// Success Test
		Mockito.when(employeeRepository.findById(any(String.class))).thenReturn(Optional.empty());
		Mockito.when(employeeRepository.save(any(EmployeeMaster.class))).thenReturn(employee);

		try {
			empService.save_Employee(employee);
		} catch (CustomException e) {
			fail("User Already Exist");
		}

		verify(employeeRepository, times(1)).findById(employee.getEmployee_id());
		verify(employeeRepository, times(1)).save(employee);

		// Fail Test
		Mockito.when(employeeRepository.findById(any(String.class))).thenReturn(Optional.of(employee));

		CustomException e = assertThrows(CustomException.class, () -> {
			empService.save_Employee(employee);
		});

		assertEquals("User Already Exist", e.getMessage());
		assertEquals(HttpStatus.BAD_REQUEST, e.getStatusCode());
		verify(employeeRepository, times(1)).save(any(EmployeeMaster.class));
	}

	@Test
	public void testLoginEmployee() throws Exception {
		LoginMaster test = new LoginMaster();
		test.setEmployee_id("FTE999");
		test.setPassword("admin");

		EmployeeMaster employee = new EmployeeMaster();
		employee.setEmployee_id("FTE999");
		employee.setEmployee_name("Bahubali");
		employee.setPassword("admin");
		employee.setGender('M');
		LocalDate dob = LocalDate.of(2019, 03, 13);
		employee.setDate_of_birth(dob);
		LocalDate doj = LocalDate.of(2029, 03, 13);
		employee.setDate_of_join(doj);
		employee.setDepartment("Finance");
		employee.setDesignation("Hecker");

		String res = "";
		HttpStatus status = HttpStatus.GONE;

		// Success test
		Mockito.when(employeeRepository.findById(any(String.class))).thenReturn(Optional.of(employee));
		try {
			res = empService.login_Employee(test);
		} catch (CustomException e) {
			fail("User Already Exist");
		}

		assertEquals(test.getPassword(), employee.getPassword());
		assertEquals("Login Successful", res);

		// invalid test
		employee.setPassword("not_so_admin");

		try {
			res = empService.login_Employee(test);
		} catch (CustomException e) {
			res = e.getMessage();
			status = e.getStatusCode();
		}

		assertEquals("Invalid Credentials", res);
		assertEquals(HttpStatus.BAD_REQUEST, status);

		// failure test
		Mockito.when(employeeRepository.findById(any(String.class))).thenReturn(Optional.empty());

		try {
			res = empService.login_Employee(test);
		} catch (CustomException e) {
			res = e.getMessage();
			status = e.getStatusCode();
		}

		assertEquals("User Not Found", res);
		assertEquals(HttpStatus.NOT_FOUND, status);

		// All calls verification
		verify(employeeRepository, times(3)).findById(employee.getEmployee_id());
	}

	@Test
	public void testFetchById() throws Exception {
		EmployeeMaster employee = new EmployeeMaster();
		employee.setEmployee_id("FTE999");
		employee.setEmployee_name("Bahubali");
		employee.setPassword("admin");
		employee.setGender('M');
		LocalDate dob = LocalDate.of(2019, 03, 13);
		employee.setDate_of_birth(dob);
		LocalDate doj = LocalDate.of(2029, 03, 13);
		employee.setDate_of_join(doj);
		employee.setDepartment("Finance");
		employee.setDesignation("Hecker");

		String res = "";
		HttpStatus status = HttpStatus.GONE;
		EmployeeMaster emp = new EmployeeMaster();
		// Success Test
		Mockito.when(employeeRepository.findById(any(String.class))).thenReturn(Optional.of(employee));

		try {
			emp = empService.fetch_ById(employee.getEmployee_id());
		} catch (CustomException e) {
			res = e.getMessage();
			status = e.getStatusCode();
		}

		assertEquals(employee.getEmployee_id(), emp.getEmployee_id());
		assertEquals(employee.getEmployee_name(), emp.getEmployee_name());

		// Failure Test
		Mockito.when(employeeRepository.findById(any(String.class))).thenReturn(Optional.empty());

		try {
			emp = empService.fetch_ById(employee.getEmployee_id());
		} catch (CustomException e) {
			res = e.getMessage();
			status = e.getStatusCode();
		}

		assertEquals("User Not Found - Id:" + employee.getEmployee_id(), res);
		assertEquals(HttpStatus.NOT_FOUND, status);

		// All calls
		verify(employeeRepository, times(2)).findById(employee.getEmployee_id());

	}

	@Test
	public void testFetchAll() throws Exception {
		EmployeeMaster employee = new EmployeeMaster();
		employee.setEmployee_id("FTE999");
		employee.setEmployee_name("Bahubali");
		employee.setPassword("Katappa");
		employee.setGender('M');
		LocalDate dob = LocalDate.of(2019, 03, 13);
		employee.setDate_of_birth(dob);
		LocalDate doj = LocalDate.of(2029, 03, 13);
		employee.setDate_of_join(doj);
		employee.setDepartment("Finance");
		employee.setDesignation("Hecker");

		String res = "";
		HttpStatus status = HttpStatus.GONE;

		List<EmployeeMaster> allEmployees = new ArrayList<>();
		List<EmployeeMaster> allRes = new ArrayList<>();

		// Failure Test
		Mockito.when(employeeRepository.findAll()).thenReturn(allEmployees);

		try {
			allRes = empService.fetch_All();
		} catch (CustomException e) {
			res = e.getMessage();
			status = e.getStatusCode();
		}

		assertEquals(0, allRes.size());
		assertEquals("No Users Available", res);
		assertEquals(status, HttpStatus.NOT_FOUND);

		// Success Test
		allEmployees.add(employee);
		Mockito.when(employeeRepository.findAll()).thenReturn(allEmployees);

		try {
			allRes = empService.fetch_All();
		} catch (CustomException e) {
			res = e.getMessage();
			status = e.getStatusCode();
		}

		assertEquals(1, allRes.size());

		// All calls
		verify(employeeRepository, times(2)).findAll();
	}

	@Test
	public void testApplyLoans() throws Exception {
		EmployeeMaster employee = new EmployeeMaster();
		employee.setEmployee_id("FTE999");
		employee.setEmployee_name("Bahubali");
		employee.setPassword("Katappa");
		employee.setGender('M');
		LocalDate dob = LocalDate.of(2019, 03, 13);
		employee.setDate_of_birth(dob);
		LocalDate doj = LocalDate.of(2029, 03, 13);
		employee.setDate_of_join(doj);
		employee.setDepartment("Finance");
		employee.setDesignation("Hecker");

		Mockito.when(employeeRepository.findById(any(String.class))).thenReturn(Optional.of(employee));

		String loanId = "loan";
		Mockito.when(loanRepo.findByCategory(any(String.class))).thenReturn(loanId);

		LoanCardMaster loanCardMaster = new LoanCardMaster();
		loanCardMaster.setLoan_id("loan");
		loanCardMaster.setLoan_type("banking");
		loanCardMaster.setDuration_in_years(5);

		Mockito.when(loanRepo.findById(any(String.class))).thenReturn(Optional.of(loanCardMaster));

		doReturn(null).when(cardRepo).save(any(EmployeeCardDetails.class));

		ItemMaster item = new ItemMaster();
		item.setIssue_status('Y');
		item.setItem_category("FURNITURE");
		item.setItem_description("CHAIR");
		item.setItem_id("ITEM234");
		item.setItem_make("WOODEN");
		item.setItem_valuation(550);

		Mockito.when(itemRepo.findByMakeCategoryDesc(any(String.class), any(String.class), any(String.class))).thenReturn(item);

		doReturn(null).when(issueRepo).save(any(EmployeeIssueDetails.class));

		LoanModel loanModel = new LoanModel();
		loanModel.setEmployee_id("fte999");
		loanModel.setItem_category("furniture");
		loanModel.setItem_description("desc");
		loanModel.setItem_valuation(5000);
		loanModel.setItem_make("abc");

		String res = "";
		String success = "Employee Card Details and Employee Issue Details added Successfully";
		try {
			res = empService.apply_Loans(loanModel);
		} catch (CustomException ignored) {

		}

		assertEquals(res, success);

		// all calls
		verify(employeeRepository).findById(loanModel.getEmployee_id());
		verify(loanRepo).findByCategory(loanModel.getItem_category());
		verify(loanRepo).findById(any(String.class));
		verify(cardRepo).save(any(EmployeeCardDetails.class));
		verify(itemRepo).findByMakeCategoryDesc(any(String.class), any(String.class), any(String.class));
		verify(issueRepo).save(any(EmployeeIssueDetails.class));

	}

	@Test
	public void testUpdateEmployee() throws Exception {
		EmployeeMaster employee = new EmployeeMaster();
		employee.setEmployee_id("FTE999");
		employee.setEmployee_name("Bahubali");
		employee.setPassword("admin");
		employee.setGender('M');
		LocalDate dob = LocalDate.of(2019, 03, 13);
		employee.setDate_of_birth(dob);
		LocalDate doj = LocalDate.of(2029, 03, 13);
		employee.setDate_of_join(doj);
		employee.setDepartment("Finance");
		employee.setDesignation("Hecker");

		String res = "";
		HttpStatus status = HttpStatus.GONE;
//		EmployeeMaster emp = new EmployeeMaster();

		String success = "Employee updated Succefully";
		String failure = "Employee Not found";

		// Success Test
		Mockito.when(employeeRepository.findById(any(String.class))).thenReturn(Optional.of(employee));
		Mockito.when(employeeRepository.save(any(EmployeeMaster.class))).thenReturn(employee);

		try {
			res = empService.updateEmployee(employee.getEmployee_id(), employee);
		} catch (CustomException e) {
			res = e.getMessage();
			status = e.getStatusCode();
		}

		assertEquals(res, success);

		// Failure Test
		Mockito.when(employeeRepository.findById(any(String.class))).thenReturn(Optional.empty());

		try {
			res = empService.updateEmployee(employee.getEmployee_id(), employee);
		} catch (CustomException e) {
			res = e.getMessage();
			status = e.getStatusCode();
		}

		assertEquals(res, failure);
		assertEquals(status, HttpStatus.NOT_FOUND);

		// All calls
		verify(employeeRepository, times(2)).findById(employee.getEmployee_id());
		verify(employeeRepository, times(1)).save(employee);
	}

	@Test
	public void testDeleteEmployee() throws Exception {
		EmployeeMaster employee = new EmployeeMaster();
		employee.setEmployee_id("FTE999");
		employee.setEmployee_name("Bahubali");
		employee.setPassword("admin");
		employee.setGender('M');
		LocalDate dob = LocalDate.of(2019, 03, 13);
		employee.setDate_of_birth(dob);
		LocalDate doj = LocalDate.of(2029, 03, 13);
		employee.setDate_of_join(doj);
		employee.setDepartment("Finance");
		employee.setDesignation("Hecker");

		String res = "";
		HttpStatus status = HttpStatus.GONE;
//		EmployeeMaster emp = new EmployeeMaster();

		String success = "Employee deleted Succefully";
		String failure = "Employee Not found";

		// Success Test
		Mockito.when(employeeRepository.findById(any(String.class))).thenReturn(Optional.of(employee));
		Mockito.doNothing().when(employeeRepository).deleteById(any(String.class));

		try {
			res = empService.delete_Employee((employee.getEmployee_id()));
		} catch (CustomException e) {
			res = e.getMessage();
			status = e.getStatusCode();
		}

		assertEquals(res, success);

		// Failure Test
		Mockito.when(employeeRepository.findById(any(String.class))).thenReturn(Optional.empty());

		try {
			res = empService.delete_Employee((employee.getEmployee_id()));
		} catch (CustomException e) {
			res = e.getMessage();
			status = e.getStatusCode();
		}

		assertEquals(res, failure);
		assertEquals(status, HttpStatus.NOT_FOUND);

		// All calls
		verify(employeeRepository, times(2)).findById(employee.getEmployee_id());
		verify(employeeRepository, times(1)).deleteById(employee.getEmployee_id());
	}


}