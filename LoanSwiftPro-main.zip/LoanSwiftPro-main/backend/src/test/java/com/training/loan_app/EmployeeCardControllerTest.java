package com.training.loan_app;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.training.loan_app.exception.CustomException;
import com.training.loan_app.model.LoanCardMaster;
import com.training.loan_app.model.LoansPurchased;
import com.training.loan_app.repository.*;
import com.training.loan_app.service.*;
import org.hamcrest.Matchers;
//import org.junit.Test;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.bind.annotation.CrossOrigin;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@RunWith(SpringRunner.class)
@WebMvcTest
@CrossOrigin("http://localhost:3000")
public class EmployeeCardControllerTest {
    @Autowired
    private MockMvc mvc;

    @MockBean
    private EmployeeService Empserv;
    @MockBean
    private EmployeeCardService employeeCardService;
    @MockBean
    private AdminService adminService;
    @MockBean
    private IssueService issueService;
    @MockBean
    private ItemService itemService;
    @MockBean
    private LoanService loanService;

    @MockBean
    private EmployeeRepository employeeRepository;
    @MockBean
    private ItemRepository itemRepository;
    @MockBean
    private LoanRepository loanRepository;
    @MockBean
    private EmployeeIssueRepository employeeIssueRepository;


    private static ObjectMapper mapper = new ObjectMapper();
    static {
        mapper.registerModule(new JavaTimeModule());
    }

    @Test
    public void testFetchLoansById() throws Exception {

        LoanCardMaster loanCardMaster = new LoanCardMaster();
        loanCardMaster.setLoan_type("big");
        loanCardMaster.setLoan_id("123");
        loanCardMaster.setDuration_in_years(5);

        LocalDate date = LocalDate.of(2020, 03, 13);

        LoansPurchased loansPurchased = new LoansPurchased(date, loanCardMaster);


        List<LoansPurchased> allLoansPurchased = new ArrayList<>();
        allLoansPurchased.add(loansPurchased);

        Mockito.when(employeeCardService.findLoansById(any(String.class))).thenReturn(allLoansPurchased);

        mvc.perform(get("/fetchLoansById/" + "123")
                        .contentType(MediaType.APPLICATION_JSON))
                        .andExpect(status().isAccepted())
                        .andExpect(jsonPath("$", Matchers.hasSize(1)))
                        .andExpect(jsonPath("$[0].loans.loan_id", Matchers.equalTo(loanCardMaster.getLoan_id())));

        Mockito.doThrow(new CustomException("No Loans Available", HttpStatus.NOT_FOUND))
                .when(employeeCardService)
                .findLoansById(any(String.class));

        mvc.perform(get("/fetchLoansById/" + "123")
                        .contentType(MediaType.APPLICATION_JSON))
                        .andExpect(status().isNotFound())
                        .andExpect(content().string("No Loans Available"));

    }
}
