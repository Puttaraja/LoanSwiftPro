package com.training.loan_app;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.training.loan_app.exception.CustomException;
import com.training.loan_app.model.AdminMaster;
import com.training.loan_app.model.LoginMaster;
import com.training.loan_app.repository.EmployeeIssueRepository;
import com.training.loan_app.repository.EmployeeRepository;
import com.training.loan_app.repository.ItemRepository;
import com.training.loan_app.repository.LoanRepository;
import com.training.loan_app.service.*;
//import org.junit.Test;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.bind.annotation.CrossOrigin;

import java.time.LocalDate;

import static org.mockito.ArgumentMatchers.any;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@WebMvcTest
@CrossOrigin("http://localhost:3000")
public class AdminControllerTest {

    @Autowired
    private MockMvc mvc;

    @MockBean
    private EmployeeService Empserv;
    @MockBean
    private EmployeeCardService EmpservCard;
    @MockBean
    private AdminService adminService;
    @MockBean
    private IssueService issueService;
    @MockBean
    private ItemService itemService;
    @MockBean
    private LoanService loanService;

    @MockBean
    private EmployeeRepository employeeRepository;
    @MockBean
    private ItemRepository itemRepository;
    @MockBean
    private LoanRepository loanRepository;
    @MockBean
    private EmployeeIssueRepository employeeIssueRepository;

    private static ObjectMapper mapper = new ObjectMapper();
    static {
        mapper.registerModule(new JavaTimeModule());
    }

    @Test
    public void testSaveEmployee() throws Exception {

        AdminMaster adminMaster = new AdminMaster();
        adminMaster.setAdmin_id("Admin");
        adminMaster.setDepartment("Finance");
        adminMaster.setDesignation("Manager");
        adminMaster.setAdmin_name("Not Bhagya");
        adminMaster.setGender('M');
        adminMaster.setPassword("notAdmin");
        LocalDate dob = LocalDate.of(2019, 03, 13);
        LocalDate doj = LocalDate.of(2019, 03, 13);
        adminMaster.setDate_of_birth(dob);
        adminMaster.setDate_of_join(doj);

        String success = "Admin Registered Successfully";
        String failure = "Admin Already Exist";
        // Mockito.when(Empserv.save_Employee(any(EmployeeMaster.class))).thenReturn(success);

        System.out.println("hello");
        String json = mapper.writeValueAsString(adminMaster);

        // success testing
        Mockito.when(adminService.save_Admin(any(AdminMaster.class))).thenReturn(success);

        mvc.perform(post("/saveAdmin")
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("utf-8")
                        .content(json)
                        .accept(MediaType.APPLICATION_JSON))
                        .andExpect(status().isCreated())
                        .andExpect(content().string(success));

        Mockito.doThrow(new CustomException(failure, HttpStatus.ALREADY_REPORTED))
                .when(adminService)
                .save_Admin(any(AdminMaster.class));
        mvc.perform(post("/saveAdmin")
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("utf-8")
                        .content(json)
                        .accept(MediaType.APPLICATION_JSON))
                        .andExpect(status().isAlreadyReported())
                        .andExpect(content().string(failure));

    }

    @Test
    public void testLoginEmployee() throws Exception {
        LoginMaster test = new LoginMaster();
        test.setEmployee_id("12345678");
        test.setPassword("admin");

        String invalid = "Admin Not Found";
        String success = "Login Successful";
        String failure = "Invalid Credentials";

        String json = mapper.writeValueAsString(test);

        Mockito.doThrow(new CustomException(invalid, HttpStatus.NOT_FOUND))
                .when(adminService).login_Admin(any(LoginMaster.class));

        mvc.perform(post("/loginAdmin")
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("utf-8")
                        .content(json)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andExpect(content().string(invalid));

        Mockito.when(adminService.login_Admin(any(LoginMaster.class))).thenReturn(success);
        mvc.perform(post("/loginAdmin")
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("utf-8")
                        .content(json)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().string(success));

        Mockito.doThrow(new CustomException(failure, HttpStatus.BAD_REQUEST))
                .when(adminService).login_Admin(any(LoginMaster.class));
        mvc.perform(post("/loginAdmin")
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("utf-8")
                        .content(json)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest())
                .andExpect(content().string(failure));

    }


}
