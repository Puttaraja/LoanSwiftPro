package com.training.loan_app;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.training.loan_app.controller.LoanController;
import com.training.loan_app.dto.LoanCardMasterDTO;
import com.training.loan_app.exception.CustomException;
import com.training.loan_app.model.EmployeeMaster;
import com.training.loan_app.model.ItemMaster;
import com.training.loan_app.model.LoanCardMaster;
import com.training.loan_app.repository.EmployeeIssueRepository;
import com.training.loan_app.repository.EmployeeRepository;
import com.training.loan_app.repository.ItemRepository;
import com.training.loan_app.repository.LoanRepository;
import com.training.loan_app.service.*;
import org.hamcrest.Matchers;
//import org.junit.Test;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.bind.annotation.CrossOrigin;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@RunWith(SpringRunner.class)
@WebMvcTest
@CrossOrigin("http://localhost:3000")
public class LoanControllerTest {

    @Autowired
    private MockMvc mvc;

    @MockBean
    private EmployeeService Empserv;
    @MockBean
    private EmployeeCardService EmpservCard;
    @MockBean
    private AdminService adminService;
    @MockBean
    private IssueService issueService;
    @MockBean
    private ItemService itemService;
    @MockBean
    private LoanService loanService;

    @MockBean
    private EmployeeRepository employeeRepository;
    @MockBean
    private ItemRepository itemRepository;
    @MockBean
    private LoanRepository loanRepository;
    @MockBean
    private EmployeeIssueRepository employeeIssueRepository;

    private static ObjectMapper mapper = new ObjectMapper();
    static {
        mapper.registerModule(new JavaTimeModule());
    }

    @Test
    public void testSaveEmployee() throws Exception {
        LoanCardMasterDTO loanCardMasterDTO = new LoanCardMasterDTO();
        loanCardMasterDTO.setLoan_id("loan");
        loanCardMasterDTO.setLoan_type("banking");
        loanCardMasterDTO.setDuration_in_years(5);

        String success = "Loan added successfully";
        String failure = "Loan Already Exist";

        String json = mapper.writeValueAsString(loanCardMasterDTO);

        // success testing
        when(loanService.save_Loan(any(LoanCardMaster.class))).thenReturn(success);

        mvc.perform(post("/saveLoan")
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("utf-8")
                        .content(json)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated())
                .andExpect(content().string(success));

        Mockito.doThrow(new CustomException(failure, HttpStatus.ALREADY_REPORTED))
                .when(loanService)
                .save_Loan(any(LoanCardMaster.class));
        mvc.perform(post("/saveLoan")
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("utf-8")
                        .content(json)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isAlreadyReported())
                .andExpect(content().string(failure));

    }

    @Test
    public void testFetchLoans() throws Exception {
        LoanCardMaster loanCardMaster = new LoanCardMaster();
        loanCardMaster.setLoan_id("loan");
        loanCardMaster.setLoan_type("banking");
        loanCardMaster.setDuration_in_years(5);

        List<LoanCardMaster> loanCardMasterList = new ArrayList<>();
        loanCardMasterList.add(loanCardMaster);

//        String success = "Loan added successfully";
        String failure = "No Loans Available";

//        String json = mapper.writeValueAsString(loanCardMaster);

        // success testing
        when(loanService.fetch_Loans()).thenReturn(loanCardMasterList);

        mvc.perform(get("/fetchLoans")
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("utf-8")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", Matchers.hasSize(1)))
                .andExpect(jsonPath("$[0].loan_id", Matchers.equalTo("loan")));

        Mockito.doThrow(new CustomException(failure, HttpStatus.NO_CONTENT))
                .when(loanService)
                .fetch_Loans();
        mvc.perform(get("/fetchLoans")
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("utf-8")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent())
                .andExpect(content().string(failure));

    }

    @Test
    public void testFetchLoanById() throws Exception {
        LoanCardMaster loanCardMaster = new LoanCardMaster();
        loanCardMaster.setLoan_id("loan");
        loanCardMaster.setLoan_type("banking");
        loanCardMaster.setDuration_in_years(5);

//        String success = "Loan added successfully";
        String failure = "Loan Not Found";

//        String json = mapper.writeValueAsString(loanCardMaster);

        // success testing
        when(loanService.fetch_Loan(any(String.class))).thenReturn(loanCardMaster);

        mvc.perform(get("/fetchLoan/{lid}", loanCardMaster.getLoan_id())
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("utf-8")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.loan_id", Matchers.equalTo("loan")));

        Mockito.doThrow(new CustomException(failure, HttpStatus.NO_CONTENT))
                .when(loanService)
                .fetch_Loan(any(String.class));
        mvc.perform(get("/fetchLoan/{lid}", loanCardMaster.getLoan_id())
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("utf-8")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent())
                .andExpect(content().string(failure));

    }

    @Test
    public void testEditLoan() throws Exception {
        LoanCardMaster loanCardMaster = new LoanCardMaster();
        loanCardMaster.setLoan_id("loan");
        loanCardMaster.setLoan_type("banking");
        loanCardMaster.setDuration_in_years(5);

        String json = mapper.writeValueAsString(loanCardMaster);

        String success = "Loan Updated Successfully";
        String failure = "Loan Not found";

        // success testing
        Mockito.when(loanService.update_Loan(any(String.class), any(LoanCardMaster.class))).thenReturn(success);

        mvc.perform(put("/editLoan/" + loanCardMaster.getLoan_id())
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("utf-8")
                        .content(json)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isAccepted())
                .andExpect(content().string(success));

        Mockito.doThrow(new CustomException(failure, HttpStatus.NOT_FOUND))
                .when(loanService)
                .update_Loan(any(String.class), any(LoanCardMaster.class));
        mvc.perform(put("/editLoan/" + loanCardMaster.getLoan_id())
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("utf-8")
                        .content(json)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andExpect(content().string(failure));
    }

    @Test
    public void testDeleteLoan() throws Exception {
        LoanCardMaster loanCardMaster = new LoanCardMaster();
        loanCardMaster.setLoan_id("loan");
        loanCardMaster.setLoan_type("banking");
        loanCardMaster.setDuration_in_years(5);

        String success = "Loan Deleted Successfully";
        String failure = "Loan Not found";

        // success testing
        Mockito.when(loanService.delete_Loan(any(String.class))).thenReturn(success);

        mvc.perform(delete("/deleteLoan/" + loanCardMaster.getLoan_id())
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("utf-8")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().string(success));

        Mockito.doThrow(new CustomException(failure, HttpStatus.NOT_FOUND))
                .when(loanService)
                .delete_Loan(any(String.class));
        mvc.perform(delete("/deleteLoan/" + loanCardMaster.getLoan_id())
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("utf-8")
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andExpect(content().string(failure));
    }








}
