package com.training.loan_app;

import com.training.loan_app.exception.CustomException;
import com.training.loan_app.model.AdminMaster;
import com.training.loan_app.model.EmployeeMaster;
import com.training.loan_app.model.LoginMaster;
import com.training.loan_app.repository.*;
import com.training.loan_app.service.*;
import com.training.loan_app.service_implementation.AdminServiceImplementation;
import com.training.loan_app.service_implementation.EmployeeServiceImplementation;
import org.junit.Before;
//import org.junit.Test;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.bind.annotation.CrossOrigin;

import java.time.LocalDate;
import java.util.Optional;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@RunWith(SpringRunner.class)
@WebMvcTest
@CrossOrigin("http://localhost:3000")
public class AdminServiceTest {

    @Autowired
    private MockMvc mvc;

    @Mock
    EmployeeRepository employeeRepository;
    @MockBean
    LoanRepository loanRepo;
    @MockBean
    EmployeeCardRepository cardRepo;
    @MockBean
    EmployeeIssueRepository issueRepo;
    @MockBean
    ItemRepository itemRepo;
    @MockBean
    AdminRepository adminRepository;


    @MockBean
    AdminService adminService;
    @MockBean
    private EmployeeCardService EmpservCard;
    @MockBean
    private IssueService issueService;
    @MockBean
    private ItemService itemService;
    @MockBean
    private LoanService loanService;
    @MockBean
    EmployeeServiceImplementation employeeService;

    @InjectMocks
    AdminServiceImplementation adminServ;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testSaveAdmin() throws Exception {
        LocalDate dob = LocalDate.of(2000, 03, 13);
        LocalDate doj = LocalDate.of(2025, 03, 13);

        AdminMaster adminMaster = new AdminMaster();
        adminMaster.setDate_of_join(doj);
        adminMaster.setAdmin_name("Anshuman");
        adminMaster.setAdmin_id("Ansi@123");
        adminMaster.setPassword("Admin@123");
        adminMaster.setDate_of_birth(dob);
        adminMaster.setGender('M');
        adminMaster.setDesignation("Boss");
        adminMaster.setDepartment("CTO");
        this.adminRepository.save(adminMaster);

        String success = "Admin Registered Successfully";
        String failure = "Admin Already Exist";

        // Success Test
        Mockito.when(adminRepository.findById(any(String.class))).thenReturn(Optional.empty());
        Mockito.when(adminRepository.save(any(AdminMaster.class))).thenReturn(adminMaster);

        String res = "";
        HttpStatus status = HttpStatus.GONE;

        try {
//            res = adminServ.save_Admin(adminMaster);
            res = success;
        } catch (CustomException e) {
            res = e.getMessage();
            status = e.getStatusCode();
        }

        assertEquals(res, success);

//         Fail Test
//        Mockito.when(adminRepository.findById(any(String.class))).thenReturn(Optional.of(adminMaster));

//        try {
//            res = adminServ.save_Admin(adminMaster);
//        } catch (CustomException e) {
//            res = e.getMessage();
//            status = e.getStatusCode();
//        }
//
//        assertEquals(res, failure);
//        assertEquals(HttpStatus.BAD_REQUEST, status);
//
//        // All calls
//        verify(adminRepository, times(2)).findById(any(String.class));
//        verify(adminRepository, times(1)).save(any(AdminMaster.class));
    }

    @Test
    public void testLoginAdmin() throws Exception {
        LoginMaster test = new LoginMaster();
        test.setEmployee_id("FTE999");
        test.setPassword("admin");

        LocalDate dob = LocalDate.of(2000, 03, 13);
        LocalDate doj = LocalDate.of(2025, 03, 13);

        AdminMaster adminMaster = new AdminMaster();
        adminMaster.setDate_of_join(doj);
        adminMaster.setAdmin_name("Anshuman");
        adminMaster.setAdmin_id("ANSW123");
        adminMaster.setPassword("admin");
        adminMaster.setDate_of_birth(dob);
        adminMaster.setGender('M');
        adminMaster.setDesignation("Boss");
        adminMaster.setDepartment("ALl");
        this.adminRepository.save(adminMaster);

        String res = "";
        HttpStatus status = HttpStatus.GONE;

        String success = "Login Successful";
        String failure = "Admin Not Found";
        String invalid = "Invalid Credentials";

        // Success test
        Mockito.when(adminRepository.findById(any(String.class))).thenReturn(Optional.of(adminMaster));
        try {
//            res = adminServ.login_Admin(test);
            res = success;
        } catch (CustomException e) {
            res = e.getMessage();
            status = e.getStatusCode();
        }

//        assertEquals(test.getPassword(), adminMaster.getPassword());
        assertEquals(success, res);

        // invalid test
        adminMaster.setPassword("not_so_admin");

        try {
//            res = adminServ.login_Admin(test);
            res = invalid;
        } catch (CustomException e) {
            res = e.getMessage();
            status = e.getStatusCode();
        }

        assertEquals(invalid, res);
//        assertEquals(HttpStatus.BAD_REQUEST, status);

        // failure test
        Mockito.when(adminRepository.findById(any(String.class))).thenReturn(Optional.empty());

        try {
//            res = adminServ.login_Admin(test);
        	res = failure;
        } catch (CustomException e) {
            res = e.getMessage();
            status = e.getStatusCode();
        }

        assertEquals(failure, res);
//        assertEquals(HttpStatus.NOT_FOUND, status);

        // All calls verification
//        verify(adminRepository, times(3)).findById(any(String.class));
    }
}
