package com.training.loan_app;

import com.training.loan_app.exception.CustomException;
import com.training.loan_app.model.ItemMaster;
import com.training.loan_app.model.ItemsPurchase;
import com.training.loan_app.repository.*;
import com.training.loan_app.service.*;
import com.training.loan_app.service_implementation.EmployeeServiceImplementation;
import com.training.loan_app.service_implementation.IssueServiceImplementation;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.bind.annotation.CrossOrigin;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@RunWith(SpringRunner.class)
@WebMvcTest
@CrossOrigin("http://localhost:3000")
public class IssueServiceTest {

    @Mock
    EmployeeRepository employeeRepository;
    @MockBean
    LoanRepository loanRepo;
    @MockBean
    EmployeeCardRepository cardRepo;
    @MockBean
    EmployeeIssueRepository issueRepo;
    @MockBean
    ItemRepository itemRepo;


    @MockBean
    AdminService adminService;
    @MockBean
    private EmployeeCardService EmpservCard;
    @MockBean
    private IssueService issueService;
    @MockBean
    private ItemService itemService;
    @MockBean
    private LoanService loanService;
    @MockBean
    private EmployeeService employeeService;

    @InjectMocks
    IssueServiceImplementation issueServiceImplementation;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testFindItemsPurchasedById() throws Exception {
        List<String> ids = new ArrayList<>();
        List<ItemMaster> items = new ArrayList<>();
        List<ItemsPurchase> purchaseList = new ArrayList<>();

        String res = "";
        HttpStatus status = HttpStatus.GONE;
        String failure = "No Items issued ";

        // First Fail
        Mockito.when(issueRepo.findItemsPurchasedById(any(String.class))).thenReturn(ids);

        try {
            purchaseList = issueServiceImplementation.findItemsPurchasedById("1");
        } catch (CustomException e) {
            res = e.getMessage();
            status = e.getStatusCode();
        }

        assertEquals(failure, res);
        assertEquals(status, HttpStatus.NOT_FOUND);

        // Second Fail
        ids.add("id");
        Mockito.when(issueRepo.findItemsPurchasedById(any(String.class))).thenReturn(ids);
        Mockito.when(issueRepo.findItemsPurchasedById1(any(String.class))).thenReturn(items);

        res = "";
        status = HttpStatus.GONE;
        try {
            purchaseList = issueServiceImplementation.findItemsPurchasedById("1");
        } catch (CustomException e) {
            res = e.getMessage();
            status = e.getStatusCode();
        }

        assertEquals(failure, res);
        assertEquals(status, HttpStatus.NOT_FOUND);

        // Success
        ItemMaster item = new ItemMaster();
        item.setIssue_status('Y');
        item.setItem_category("FURNITURE");
        item.setItem_description("CHAIR");
        item.setItem_id("ITEM234");
        item.setItem_make("WOODEN");
        item.setItem_valuation(550);

        items.add(item);

        Mockito.when(issueRepo.findItemsPurchasedById(any(String.class))).thenReturn(ids);
        Mockito.when(issueRepo.findItemsPurchasedById1(any(String.class))).thenReturn(items);

        res = "";
        status = HttpStatus.GONE;
        try {
            purchaseList = issueServiceImplementation.findItemsPurchasedById("1");
        } catch (CustomException e) {
            res = e.getMessage();
            status = e.getStatusCode();
        }

        assertEquals(purchaseList.size(), 1);
        assertEquals(purchaseList.get(0).getItem().getItem_id(), item.getItem_id());

        // ALL CALLS
        verify(issueRepo, times(3)).findItemsPurchasedById(any(String.class));
        verify(issueRepo, times(2)).findItemsPurchasedById1(any(String.class));

     }
}
